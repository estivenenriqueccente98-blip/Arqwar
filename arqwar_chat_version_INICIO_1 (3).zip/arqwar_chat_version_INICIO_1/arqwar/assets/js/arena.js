const A=window.ARQWAR||{};
const esc=s=>String(s??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
let state=null,lastDiceId=null;
const diceFaces=['⚀','⚁','⚂','⚃','⚄','⚅'];
const shortLabels={security:'SEC',availability:'AVL',scalability:'SCL',performance:'PER',reliability:'REL',devops:'DEV'};
const layerOf=c=>({Edge:'EDGE',Network:'NETWORK',Security:'SECURITY',Identity:'SECURITY',Compute:'COMPUTE',Container:'COMPUTE',Orchestration:'COMPUTE',Serverless:'COMPUTE','App Platform':'COMPUTE',Database:'DATA',Cache:'DATA',Storage:'DATA',Messaging:'DATA','Vector DB':'DATA',Search:'DATA',Analytics:'DATA & ANALYTICS','Data Integration':'DATA & ANALYTICS','Data Quality':'DATA & ANALYTICS','CI/CD':'DEVOPS',IaC:'DEVOPS',Artifact:'DEVOPS',Observability:'OBSERVABILITY',AI:'AI / MLOPS',MLOps:'AI / MLOPS',RPA:'AUTOMATION',Integration:'AUTOMATION',FinOps:'FINOPS'}[c.category]||'OTHER');
function metric(name,v){return `<div class="arena-metric"><span>${name}</span><div><i style="width:${Math.max(0,Math.min(100,v))}%"></i></div><b>${v}</b></div>`}
function architecture(cards){
 const order=['EDGE','NETWORK','SECURITY','COMPUTE','DATA','DATA & ANALYTICS','DEVOPS','OBSERVABILITY','AI / MLOPS','AUTOMATION','FINOPS'];const groups={};cards.forEach(c=>(groups[layerOf(c)]??=[]).push(c));
 return `<div class="architecture">${order.filter(k=>groups[k]?.length).map(k=>`<div class="arch-layer"><span class="layer-name">${k}</span><div class="arch-cards">${groups[k].map(c=>`<span class="arch-card"><b>${esc(c.name)}</b><small>${esc(c.provider)}</small></span>`).join('')}</div></div>`).join('')||'<div class="empty-architecture">Esperando las primeras cartas...</div>'}</div>`;
}
function teamView(t){
 const s=t.stats,team=t.team;const pass=t.contract_ok;const dice=t.dice_roll;const members=(t.members||[]).map(m=>esc(m.name)).join(' · ');const rank=Number(t.current_rank)||'-';
 return `<section class="arena-team ${rank===1?'leading':''}" data-slot="${team.slot_no}"><header><div class="arena-team-id"><div class="arena-rank">#${rank}</div><div><div class="team-name">${esc(team.name)}</div><div class="team-status">POSICIÓN FIJA ${team.slot_no} · ${pass?'CONTRATO OK':'CONTRATO EN RIESGO'}</div></div></div><div class="team-score-wrap"><span>PUNTOS ACUMULADOS</span><div class="team-score">${t.score}<small>/1000</small></div></div></header><div class="arena-members">${members||'Sin participantes registrados'}</div><div class="team-kpis"><span>REP <b>${team.reputation}</b></span><span>SLA <b>${Number(team.sla).toFixed(3)}%</b></span><span>COST <b>$${Number(t.cost).toLocaleString()}</b></span><span>FINOPS <b>${t.finops}</b></span><span>CARTAS R${state?.game?.current_round||0} <b>${t.plays_this_round}/${t.deployment_limit}</b></span><span>DADO <b>${dice?dice.result:'—'}${dice&&Number(dice.won_extra_card)===1?' ★':''}</b></span></div><div class="arena-metrics">${metric('SEC',s.security)}${metric('AVL',s.availability)}${metric('SCL',s.scalability)}${metric('PER',s.performance)}${metric('REL',s.reliability)}${metric('DEV',s.devops)}</div>${architecture(t.cards)}<div class="arena-combos">${t.combos.map(c=>`<span>⚡ ${esc(c.name)}</span>`).join('')||'<span class="muted">Sin combos</span>'}</div></section>`
}
function renderFeedback(d){
 const el=document.getElementById('playFeedback');
 if(!d.last_feedback?.feedback){el.classList.add('d-none');el.innerHTML='';return;}
 const f=d.last_feedback.feedback;const deltas=Object.entries(f.metric_deltas||{}).filter(([,v])=>Number(v)>0).map(([k,v])=>`${shortLabels[k]||k.toUpperCase()} +${v}`).join(' · ');
 el.className=`arena-feedback feedback-${esc(f.level||'neutral')}`;
 el.innerHTML=`<div><small>ÚLTIMA ELECCIÓN · ${esc(d.last_feedback.team_name)}</small><strong>${esc(f.card?.name||'Carta')} · ${esc(f.rating)}</strong><p>${esc(f.reason)}</p><div class="arena-feedback-sub">Relevancia ${Number(f.relevance_score||0)}/100 · Ajuste decisión ${Number(f.decision_adjustment||0)>=0?'+':''}${Number(f.decision_adjustment||0)}</div></div><div class="arena-feedback-score"><span>IMPACTO</span><b>${Number(f.score_delta)>=0?'+':''}${f.score_delta}</b><small>${f.score_after}/1000</small></div><div class="arena-feedback-metrics">${deltas||'Sin mejora directa en métricas prioritarias'}</div>`;
}
function renderDice(d){
 const el=document.getElementById('diceBanner');const r=d.latest_dice;
 if(!r){el.classList.add('d-none');el.innerHTML='';return;}
 const isNew=String(r.id)!==String(lastDiceId); if(isNew)lastDiceId=r.id;
 el.className=`arena-event-strip ${Number(r.won_extra_card)===1?'won':''} ${isNew?'dice-arrival':''}`;
 el.innerHTML=`<span class="arena-die ${isNew?'spin-in':''}">${diceFaces[Number(r.result)-1]||'🎲'}</span><div><small>ÚLTIMO DADO · ${esc(r.team_name)}</small><strong>Salió ${r.result} · suerte elegida ${r.lucky_number}</strong></div><b>${Number(r.won_extra_card)===1?'BONUS +1 CARTA':'SIN BONUS'}</b>`;
}
function incidentMarkup(i){
 if(!i)return '';
 return `<div class="incident-left"><span class="danger-dot"></span><div><small>INCIDENTE ACTIVO · ${esc((i.incident_type||'').toUpperCase())}</small><strong>${esc(i.name)}</strong><p>${esc(i.description)}</p><div class="incident-tv-detail"><span><b>QUÉ PASA</b>${esc(i.technical_detail||'')}</span><span class="incident-tv-example"><b>EJEMPLO NO TÉCNICO</b>${esc(i.nontechnical_example||'')}</span>${i.business_impact?`<span><b>IMPACTO</b>${esc(i.business_impact)}</span>`:''}</div></div></div><div class="incident-needs">${Object.entries(i.requirements||{}).map(([k,v])=>`<span>${k.toUpperCase()} ≥ ${v}</span>`).join('')}</div>`;
}
function render(d){
 state=d;const g=d.game;document.getElementById('arenaScenario').textContent=`${g.scenario_area} · ${g.client_name} · ${g.scenario_name}`;document.getElementById('arenaRound').textContent=`${g.current_round}/${g.max_rounds}`;
 document.getElementById('missionBar').innerHTML=`<div><span>BUDGET</span><b>$${Number(g.scenario_budget).toLocaleString()}</b></div><div><span>SLA</span><b>${g.sla_target}%</b></div><div><span>CARGA</span><b>${esc(g.user_load)}</b></div><div><span>🎲 DADO</span><b>Suerte por lanzamiento</b></div>`;
 renderDice(d);renderFeedback(d);const teams=document.getElementById('arenaTeams');teams.dataset.count=String(d.teams.length);teams.innerHTML=d.teams.map(teamView).join('');document.getElementById('arenaLogs').innerHTML=d.logs.slice(0,3).map(l=>`<span>${esc(l.message)}</span>`).join(' · ');
 if(d.incident){document.getElementById('incidentBanner').innerHTML=incidentMarkup(d.incident)}else{document.getElementById('incidentBanner').innerHTML=`<div><div><small>ESTADO</small><strong>${g.status==='finished'?'PARTIDA FINALIZADA':'ESPERANDO INCIDENTE'}</strong></div></div>`}
}
async function load(){if(!A.gameId){document.getElementById('arenaTeams').innerHTML='<div class="display-6 text-center">No hay partida seleccionada.</div>';return}try{const r=await fetch(`api/state.php?game_id=${A.gameId}&t=${Date.now()}`);const j=await r.json();if(j.ok)render(j.data)}catch(e){console.error(e)}}
function tick(){if(!state?.incident){document.getElementById('arenaClock').textContent='--:--';return}const start=new Date(state.incident.active_incident_started_at.replace(' ','T'));const end=start.getTime()+Number(state.incident.duration_sec)*1000;const left=Math.max(0,Math.floor((end-Date.now())/1000));document.getElementById('arenaClock').textContent=`${String(Math.floor(left/60)).padStart(2,'0')}:${String(left%60).padStart(2,'0')}`}
load();setInterval(load,2500);setInterval(tick,500);
