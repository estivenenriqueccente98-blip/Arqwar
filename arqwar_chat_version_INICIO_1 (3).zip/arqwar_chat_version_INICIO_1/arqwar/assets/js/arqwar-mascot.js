/* Mascota ARQWAR 2D · animacion en Inicio y partida. No toca los datos de juego. */
(()=>{
  'use strict';
  const root=document.querySelector('[data-arq-bot]');
  if(!root)return;
  const home=root.dataset.context==='home';
  const mascot=document.getElementById('arqBotMascot');
  const image=document.getElementById('arqBotImage');
  const trigger=document.getElementById('arqBotOpenChat');
  const speech=document.getElementById('arqBotSpeech');
  const panel=document.getElementById(home?'arqBotChatPanel':'gameChat');
  const close=document.getElementById(home?'arqBotCloseChat':'arqBotCloseGameChat');
  const focusTarget=document.getElementById(home?'arqBotQuestion':'chatInput');
  if(!mascot||!image||!panel)return;
  const frames=['idle','joy','wave','guide'];
  const messages=[
    '¡Qué alegría verte! ✨',
    '¡Estoy emocionado de jugar contigo! 💙',
    '¡Hola, estratega! 👋',
    '¡Vamos a resolver grandes desafíos! 🚀',
    '¡Eres increíble! 🌟',
    '¡Un reto más, una victoria más! 🏆'
  ];
  const path='assets/img/mascota/';
  ['idle','joy','wave','guide','blink'].forEach(n=>{const i=new Image();i.src=path+n+'.webp';});
  const reduced=window.matchMedia?.('(prefers-reduced-motion: reduce)').matches||false;
  let mood=0, frame='idle', blinkTimer, blinkEndTimer, celebrateTimer, speechTimer, clickTimer, lastClick=0, lastOpen=0;
  const setFrame=n=>{image.src=path+n+'.webp';};
  const say=(message,duration=3400)=>{
    if(!speech)return;
    speech.textContent=message;
    speech.classList.add('is-visible');
    clearTimeout(speechTimer);
    speechTimer=setTimeout(()=>speech.classList.remove('is-visible'),duration);
  };
  const doBlink=()=>{
    if(document.hidden||reduced||root.classList.contains('is-excited')||frame!=='idle')return;
    setFrame('blink');
    clearTimeout(blinkEndTimer);
    blinkEndTimer=setTimeout(()=>setFrame(frame),145);
  };
  if(!reduced){
    blinkTimer=setInterval(()=>{if(Math.random()>.31)doBlink();},3100);
  }
  function react(){
    mood=(mood+1)%messages.length;
    const next=frames[mood%frames.length];
    frame=next;
    setFrame(next);
    root.classList.remove('is-excited');
    // Reset CSS animation so every click produces a new reaction.
    void root.offsetWidth;
    root.classList.add('is-excited');
    say(messages[mood]);
    clearTimeout(celebrateTimer);
    celebrateTimer=setTimeout(()=>{root.classList.remove('is-excited');frame='idle';setFrame('idle');},1700);
  }
  function showChat(open){
    panel.hidden=!open;
    panel.classList.toggle('is-open',open);
    root.classList.toggle('has-chat-open',open);
    mascot.setAttribute('aria-expanded',String(open));
    trigger?.setAttribute('aria-expanded',String(open));
    if(open){
      frame='wave';setFrame('wave');
      say(home?'¡Te escucho! ¿Qué deseas aprender?':'¡Abrimos el chat de la partida! 💬',2600);
      if(!home && typeof window.loadChat==='function')window.loadChat();
      setTimeout(()=>focusTarget?.focus(),75);
    }else{
      frame='idle';setFrame('idle');
    }
  }
  const toggleChat=()=>{lastOpen=Date.now();showChat(panel.hidden);};
  mascot.addEventListener('click',()=>{
    const now=Date.now();
    if(lastClick && now-lastClick<345){
      clearTimeout(clickTimer);lastClick=0;
      if(now-lastOpen>390)toggleChat();
    }else{
      lastClick=now;
      clearTimeout(clickTimer);
      clickTimer=setTimeout(()=>{lastClick=0;react();},350);
    }
  });
  mascot.addEventListener('dblclick',e=>{
    e.preventDefault();clearTimeout(clickTimer);lastClick=0;
    if(Date.now()-lastOpen>390)toggleChat();
  });
  trigger?.addEventListener('click',toggleChat);
  close?.addEventListener('click',()=>{showChat(false);mascot.focus();});
  document.addEventListener('keydown',e=>{
    if(e.key==='Escape' && !panel.hidden){showChat(false);mascot.focus();}
  });
  // Chat inicial: guia contextual con respuestas locales basadas en reglas del juego.
  if(home){
    const log=document.getElementById('arqBotChatLog');
    const form=document.getElementById('arqBotQuestionForm');
    const question=document.getElementById('arqBotQuestion');
    const topics=[
      {re:/\b(dad[oa]s?|lanzar|suerte|bono|tirad[ao])\b/,text:'Cada jugador o equipo puede lanzar el dado una vez por ronda. Antes de lanzar elige un número del 1 al 6; si coincide, obtienes un despliegue adicional durante esa ronda. En las salas, solo el jugador correspondiente puede manejar su dado.',href:'game-master.php?new=1',label:'Crear partida'},
      {re:/\b(carta|cartas|despliegue|registrar|servici[oa]|herramienta)\b/,text:'Las cartas representan servicios y herramientas de arquitectura TI. Desde el Game Master se registra la carta física utilizada, quién la respondió y su impacto. Según el problema, presupuesto e incidente, una carta puede sumar, restar o dar cero puntos.',href:'cards.php',label:'Abrir catálogo'},
      {re:/\b(incident|ddos|ataque|resolver|crisis|problema)\w*/,text:'Los incidentes son desafíos técnicos que debes resolver con tus decisiones de arquitectura. El Game Master puede activarlos, y al avanzar la ronda se evalúan las métricas de cada jugador o equipo. El resultado puede afectar reputación y SLA.',href:'game-master.php',label:'Abrir Game Master'},
      {re:/\b(casuistica|escenario|especialidad|area tecnologica)\b/,text:'Una casuística es un problema realista de Arquitectura TI que se debe resolver durante la batalla. Al crear la partida eliges el área tecnológica y la casuística, y cada carta se evalúa según la pertinencia para ese escenario.',href:'game-master.php?new=1',label:'Elegir una casuística'},
      {re:/\b(equipo|equipos|integrante|grupo|aliados|miembros)\b/,text:'Puedes formar equipos desde el módulo Equipos y asignarles participantes registrados. En una batalla por equipos se seleccionan entre 2 y 8 equipos; también existe la modalidad individual donde cada usuario tiene su propia casilla.',href:'teams.php',label:'Ver equipos'},
      {re:/\b(participante|jugador|alias|perfil|nivel|xp)\b/,text:'Los participantes tienen alias, historial y experiencia individual. Puedes registrarlos en Participantes. Las decisiones de cartas y los bonos de pronunciación alimentan el ranking individual.',href:'participants.php',label:'Ver participantes'},
      {re:/\b(sala|salas|unirme|entrar|privad|conectad|en vivo)\w*/,text:'En Salas ARQWAR puedes buscar una partida, entrar y jugar en tiempo real. Algunas salas son privadas y requieren contraseña. En el modo individual cada usuario recibe su propia casilla al ingresar.',href:'rooms.php',label:'Ver salas'},
      {re:/\b(arena|televisor|tv|proyectar|pantalla grande)\b/,text:'Arena TV muestra el desarrollo de una partida en una pantalla grande o televisor. Es una vista de seguimiento; el Game Master controla la partida desde su módulo.',href:'arena.php',label:'Abrir Arena TV'},
      {re:/\b(ranking|ganador|ganadores|campeon|clasificaci|puesto|posicion)\w*/,text:'Puedes consultar el ranking individual por XP y niveles, el ranking general de equipos y el historial de ganadores por partida. Los resultados se guardan al finalizar la batalla.',href:'ranking.php',label:'Ver ranking general'},
      {re:/\b(puntaje|puntuaci|score|metrica|security|availability|scalability|sla|presupuesto|finops)\w*/,text:'El puntaje refleja qué tan bien tu arquitectura resuelve la casuística. Se valoran Security, Availability, Scalability, Performance, Reliability, DevOps, presupuesto, FinOps y calidad de la decisión. Más cartas no significa necesariamente más puntos.',href:'game-master.php',label:'Revisar partida'},
      {re:/\b(chat|mensaje|hablar|conversar)\b/,text:'En una partida, haz doble clic sobre la mascota ARQWAR para abrir el chat que ya existe. Puedes usar el canal General y, cuando corresponda, el canal de tu equipo. Los mensajes siguen guardándose en el sistema.',href:'rooms.php',label:'Entrar a una sala'},
      {re:/\b(crear|nueva|inicio|empezar|comenzar|partida|jugar|modo individual|modo equipos|ronda)\w*/,text:'Para comenzar, abre Nueva partida. Elige modalidad individual o por equipos, área, casuística y rondas; en modo equipos selecciona de 2 a 8 equipos. Al crearla se abre el Game Master y la mesa virtual de batalla.',href:'game-master.php?new=1',label:'Crear nueva partida'},
      {re:/\b(hola|buenas|quien eres|que haces|ayuda|ayudame)\b/,text:'¡Hola! Soy ARQ, la mascota de tu juego de arquitectura TI. Puedo orientarte sobre partidas, cartas, dados, equipos, salas, ranking e incidentes. ¿Qué te gustaría saber?',href:null,label:null}
    ];
    function normalize(s){return String(s).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9\s]/g,' ').replace(/\s+/g,' ').trim();}
    function answer(q){const n=normalize(q);return topics.find(t=>t.re.test(n))||{text:'No tengo una respuesta específica para eso. Puedes preguntarme cómo crear una partida, lanzar el dado, registrar cartas, resolver incidentes o entrar a una sala. Soy una guía del juego, no una IA conectada a Internet.',href:null};}
    function addMessage(kind,message,href,label){
      const bubble=document.createElement('div');
      bubble.className='arq-bot__message arq-bot__message--'+kind;
      const txt=document.createElement('span');txt.textContent=message;bubble.appendChild(txt);
      if(href&&label){const a=document.createElement('a');a.href=href;a.textContent=label;bubble.appendChild(a);}
      log?.appendChild(bubble);
      if(log)log.scrollTop=log.scrollHeight;
    }
    addMessage('bot','¡Hola! 💙 Soy ARQ, tu asistente de ARQWAR. Pregúntame cómo crear partidas, usar tus cartas, lanzar dados o resolver incidentes.');
    function ask(value){
      const text=String(value||'').trim().slice(0,300);if(!text)return;
      addMessage('user',text);
      const a=answer(text);
      setTimeout(()=>addMessage('bot',a.text,a.href,a.label),180);
      react();
    }
    form?.addEventListener('submit',e=>{e.preventDefault();const value=question?.value||'';if(question)question.value='';ask(value);question?.focus();});
    document.querySelectorAll('[data-arq-question]').forEach(btn=>btn.addEventListener('click',()=>ask(btn.dataset.arqQuestion)));
  }
  setTimeout(()=>say(home?'¡Hola! Un clic me emociona; doble clic abre mi chat.':'¡Hola! Doble clic para abrir los chats de esta partida.',5400),700);
})();
