/* ARQWAR - Animacion 2D con poses reales extraidas del arte original.
 * La animacion solo cambia la vista. El avatar sigue guardandose con su clave original.
 */
(()=>{
  'use strict';
  const picker=document.getElementById('profileAvatarPicker');
  const input=document.getElementById('profileAvatarInput');
  const scene=document.getElementById('profileScene');
  const img=document.getElementById('profileCharacter');
  const nameLabel=document.getElementById('profileCharacterName');
  const poseLabel=document.getElementById('profilePoseLabel');
  const action=document.getElementById('profileAnimate');
  if(!picker||!input||!scene||!img||!nameLabel)return;

  const buttons=[...picker.querySelectorAll('button[data-avatar]')];
  const poses=['hero','front','idle','move','attack'];
  const poseNames={hero:'PERSONAJE ACTIVO',front:'SALUDANDO',idle:'EN REPOSO',move:'EN MOVIMIENTO',attack:'ATAQUE / HABILIDAD'};
  const base='assets/img/avatars-motion/';
  const reduce=window.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches||false;
  let current=null;
  let cycle=1;
  let reactions=0;
  let timers=[];
  let idleTimer=0;
  let selectionToken=0;
  const prepared=new Set();

  const source=(key,pose)=>`${base}${key}/${pose}.webp`;
  function preload(key){
    if(prepared.has(key))return;
    prepared.add(key);
    poses.forEach(pose=>{const pic=new Image();pic.src=source(key,pose);});
  }
  function clearReaction(){
    timers.forEach(id=>window.clearTimeout(id));
    timers=[];
    scene.classList.remove('is-action');
  }
  function clearAutoplay(){
    if(idleTimer){window.clearTimeout(idleTimer);idleTimer=0;}
  }
  function setPose(pose){
    if(!current)return;
    const next=poses.includes(pose)?pose:'hero';
    scene.dataset.pose=next;
    if(poseLabel)poseLabel.textContent=poseNames[next]||poseNames.hero;
    const src=source(current.dataset.avatar,next);
    // src will already be in the browser cache for the selected avatar.
    if(img.getAttribute('src')!==src)img.src=src;
    img.dataset.pose=next;
    img.alt=`${current.dataset.avatarName} - ${poseNames[next].toLowerCase()}`;
    img.setAttribute('aria-label',`Animar ${current.dataset.avatarName}. Posicion actual: ${poseNames[next].toLowerCase()}`);
  }
  function startIdle(){
    clearAutoplay();
    if(reduce||document.hidden||!current)return;
    const idlePoses=['hero','idle','front','idle','move','idle','hero','attack','hero'];
    const lengths=[2800,1900,1500,2100,920,1900,2600,1050,2900];
    const index=cycle++%idlePoses.length;
    idleTimer=window.setTimeout(()=>{
      setPose(idlePoses[index]);
      startIdle();
    },lengths[index]);
  }
  function select(button){
    if(!button)return;
    clearAutoplay();clearReaction();
    selectionToken+=1;
    cycle=1;
    current=button;
    buttons.forEach(btn=>{
      const selected=btn===button;
      btn.classList.toggle('is-selected',selected);
      btn.setAttribute('aria-pressed',selected?'true':'false');
    });
    const key=button.dataset.avatar;
    input.value=key;
    nameLabel.textContent=button.dataset.avatarName;
    scene.style.setProperty('--character-accent',button.dataset.avatarAccent||'#12d9f5');
    scene.dataset.motion=String(buttons.indexOf(button)%4);
    scene.classList.remove('is-changing');
    void scene.offsetWidth;
    scene.classList.add('is-changing');
    preload(key);
    setPose('hero');
    const token=selectionToken;
    timers.push(window.setTimeout(()=>{
      if(token===selectionToken)scene.classList.remove('is-changing');
    },240));
    startIdle();
  }

  function react(){
    if(!current)return;
    clearAutoplay();clearReaction();
    selectionToken+=1;
    const token=selectionToken;
    // Every click reveals another real posture from the supplied sprite sheets.
    const sequences=[
      [['front',0],['idle',550],['hero',1380]],
      [['move',0],['idle',610],['hero',1480]],
      [['attack',0],['move',650],['hero',1580]],
      [['idle',0],['front',420],['attack',880],['hero',1720]],
      [['move',0],['attack',620],['front',1280],['hero',1940]]
    ];
    const pattern=sequences[reactions++%sequences.length];
    scene.classList.add('is-action');
    pattern.forEach(([pose,delay])=>{
      if(delay===0)setPose(pose);
      else timers.push(window.setTimeout(()=>{
        if(token===selectionToken)setPose(pose);
      },delay));
    });
    const total=pattern[pattern.length-1][1];
    timers.push(window.setTimeout(()=>{
      if(token!==selectionToken)return;
      scene.classList.remove('is-action');
      startIdle();
    },total+420));
  }

  buttons.forEach(button=>button.addEventListener('click',()=>select(button)));
  if(action)action.addEventListener('click',react);
  img.addEventListener('click',react);
  img.addEventListener('keydown',event=>{
    if(event.key==='Enter'||event.key===' '){event.preventDefault();react();}
  });
  // Fallback only for a failed asset, without disturbing the selected avatar.
  img.addEventListener('error',()=>{
    if(!current)return;
    const fallback=current.dataset.avatarPortrait;
    if(fallback && img.getAttribute('src')!==fallback)img.src=fallback;
  });
  document.addEventListener('visibilitychange',()=>{
    if(document.hidden){clearAutoplay();clearReaction();}
    else if(current){setPose('hero');startIdle();}
  });

  const initial=buttons.find(button=>button.dataset.avatar===input.value)||buttons[0];
  if(initial)select(initial);
})();
