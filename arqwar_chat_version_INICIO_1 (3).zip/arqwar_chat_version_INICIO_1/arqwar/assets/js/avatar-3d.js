/* ARQWAR · Selector 3D. Mantiene el input y la acción de guardado originales. */
(()=>{
  'use strict';
  const picker=document.getElementById('avatarPicker');
  const avatarInput=document.getElementById('avatarEmojiInput');
  const previewButton=document.getElementById('avatar3dPreviewButton');
  const dialog=document.getElementById('avatar3dDialog');
  const closeButton=document.getElementById('avatar3dClose');
  const viewer=document.getElementById('avatar3dViewer');
  const dialogTitle=document.getElementById('avatar3dDialogTitle');
  if(!picker||!avatarInput||!previewButton||!dialog||!closeButton||!viewer)return;
  const buttons=[...picker.querySelectorAll('.avatar-option[data-avatar]')];
  const reducedMotion=window.matchMedia('(prefers-reduced-motion: reduce)');
  function selectAvatar(btn){
    if(!btn)return;
    for(const b of buttons){
      const chosen=(b===btn);
      b.classList.toggle('active',chosen);
      b.setAttribute('aria-pressed',chosen?'true':'false');
    }
    // Same POST field and values as before, with no new DB tables or changes.
    avatarInput.value=btn.dataset.avatar||'cyber_skull';
    previewButton.textContent='⟳ Explorar '+(btn.dataset.avatarName||'avatar')+' en 3D';
  }
  buttons.forEach((btn,index)=>{
    btn.style.setProperty('--avatar-delay',String(index));
    btn.addEventListener('click',()=>selectAvatar(btn));
    btn.addEventListener('pointermove',e=>{
      if(reducedMotion.matches||e.pointerType==='touch')return;
      const rect=btn.getBoundingClientRect();
      const x=(e.clientX-rect.left)/rect.width-.5;
      const y=(e.clientY-rect.top)/rect.height-.5;
      btn.style.setProperty('--tilt-x',(-y*7).toFixed(2)+'deg');
      btn.style.setProperty('--tilt-y',(x*9).toFixed(2)+'deg');
    });
    btn.addEventListener('pointerleave',()=>{
      btn.style.removeProperty('--tilt-x');
      btn.style.removeProperty('--tilt-y');
    });
  });
  selectAvatar(buttons.find(b=>b.dataset.avatar===avatarInput.value)||buttons[0]);
  previewButton.addEventListener('click',()=>{
    const btn=buttons.find(b=>b.dataset.avatar===avatarInput.value)||buttons[0];
    if(!btn)return;
    dialogTitle.textContent=btn.dataset.avatarName||'Avatar ARQWAR';
    const params=new URLSearchParams({embed:'1',avatar:btn.dataset.avatar});
    viewer.src='assets/avatars-3d/visor_3d.html?'+params.toString();
    if(typeof dialog.showModal==='function')dialog.showModal();
    else dialog.setAttribute('open','');
  });
  function closeDialog(){
    if(typeof dialog.close==='function')dialog.close();
    else {dialog.removeAttribute('open');viewer.removeAttribute('src');}
  }
  closeButton.addEventListener('click',closeDialog);
  dialog.addEventListener('click',e=>{if(e.target===dialog)closeDialog();});
  dialog.addEventListener('close',()=>viewer.removeAttribute('src'));
})();
