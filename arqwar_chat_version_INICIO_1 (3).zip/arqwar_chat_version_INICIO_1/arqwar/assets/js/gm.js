const A = window.ARQWAR || {};
const esc = s => String(s ?? '').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
const pct = n => Math.max(0,Math.min(100,Number(n)||0));
const metricLabels={security:'Seguridad',availability:'Disponibilidad',scalability:'Escalabilidad',performance:'Performance',reliability:'Resiliencia',devops:'DevOps'};
const shortLabels={security:'SEC',availability:'AVL',scalability:'SCL',performance:'PER',reliability:'REL',devops:'DEV'};
let selectedCard=null;
let latestState=null;
let activeDiceTeam=null;
let lastGameStatus=null;
let winnerShown=false;

function serviceLogo(card){
  const name=String(card?.name||'').toLowerCase();
  const provider=String(card?.provider||'').toLowerCase();
  const palette=[
    ['power bi',['BI','brand-microsoft']],['power automate',['PA','brand-microsoft']],['azure',['AZ','brand-azure']],
    ['aws',['AWS','brand-aws']],['google',['G','brand-google']],['gcp',['G','brand-google']],['oracle',['OR','brand-oracle']],
    ['dell',['DE','brand-dell']],['informatica',['IN','brand-informatica']],['snowflake',['SF','brand-snowflake']],
    ['databricks',['DB','brand-databricks']],['docker',['DK','brand-docker']],['kubernetes',['K8','brand-kubernetes']],
    ['cloudflare',['CF','brand-cloudflare']],['microsoft',['MS','brand-microsoft']],['agnostic',['AG','brand-generic']]
  ];
  for(const [key,val] of palette){ if(name.includes(key)||provider.includes(key)) return `<span class="brand-mark ${val[1]}">${esc(val[0])}</span>`; }
  const raw=String(card?.name||card?.provider||'AR').replace(/[^a-z0-9]/ig,'').toUpperCase();
  return `<span class="brand-mark brand-generic">${esc((raw.slice(0,2)||'AR'))}</span>`;
}

function updateDeployReady(){const btn=document.getElementById('deployCardBtn');if(!btn)return;const participant=!!document.getElementById('responderSelect')?.value;const pron=!!document.querySelector('input[name="pronunciation_correct"]:checked');btn.disabled=!(selectedCard&&participant&&pron);}

async function postForm(formData){
  const r = await fetch('api/action.php',{method:'POST',body:formData});
  const j = await r.json().catch(()=>({ok:false,error:'Respuesta inválida'}));
  if(!r.ok || !j.ok) throw new Error(j.error || 'Error');
  return j;
}
function toast(msg,type='success'){
  const el=document.getElementById('toastArea'); if(!el) return;
  el.innerHTML=`<div class="alert alert-${type} py-2">${esc(msg)}</div>`; setTimeout(()=>el.innerHTML='',3600);
}
function money(n){return '$'+Number(n||0).toLocaleString(undefined,{maximumFractionDigits:0})}
function signed(n){n=Number(n)||0;return n>0?`+${n}`:`${n}`}

// --- Creación y controles generales ---
document.getElementById('createGameForm')?.addEventListener('submit',async e=>{
  e.preventDefault();
  const fd=new FormData(e.target);
  const mode=fd.get('game_mode')||'teams';
  const teams=fd.getAll('team_profile_ids[]').filter(Boolean);
  if(!fd.get('scenario_id')){toast('Selecciona primero un área y una casuística.','warning');return;}
  if(mode==='teams' && teams.length<2){toast('Selecciona al menos 2 equipos.','warning');return;}
  if(mode==='teams' && teams.length>8){toast('El máximo es 8 equipos por partida.','warning');return;}
  if(mode==='individual') fd.delete('team_profile_ids[]');
  try{const j=await postForm(fd); location.href='game-master.php?game_id='+j.game_id;}catch(err){toast(err.message,'danger')}
});
document.getElementById('incidentForm')?.addEventListener('submit',async e=>{
  e.preventDefault(); try{await postForm(new FormData(e.target));toast('Incidente activado');await loadState();}catch(err){toast(err.message,'danger')}
});
document.querySelectorAll('.js-action').forEach(btn=>btn.addEventListener('click',async()=>{
  if(btn.dataset.action==='finish_game' && !confirm('¿Finalizar la partida y guardar el ranking definitivo?')) return;
  const fd=new FormData();fd.set('action',btn.dataset.action);fd.set('game_id',A.gameId);fd.set('csrf',A.csrf);
  try{
    const j=await postForm(fd);
    if(btn.dataset.action==='start_game'){
      showStartIntro();
      toast('Partida iniciada');
    }else if(j.finished && j.final_summary){
      showWinnerCelebration(j.final_summary);
    }else{
      toast('Acción aplicada');
    }
    await loadState();
  }catch(err){toast(err.message,'danger')}
}));

// --- Buscador y selector de cartas ---
function cardSearchText(c){ return [c.name,c.code,c.category,c.provider,c.description,c.lifecycle_note].join(' ').toLowerCase(); }
function cardStatChips(c){return Object.keys(metricLabels).filter(k=>Number(c[k])>0).map(k=>`<span>${shortLabels[k]} +${Number(c[k])}</span>`).join('')}
function renderCardPicker(query=''){
  const list=document.getElementById('cardPickerList'); if(!list) return;
  const q=query.trim().toLowerCase();
  const tokens=q.split(/\s+/).filter(Boolean).map(x=>x==='scaling'?'autoscal':x); const matches=(A.cards||[]).filter(c=>{const txt=cardSearchText(c);return !q || tokens.every(t=>txt.includes(t)|| (t==='autoscal' && (txt.includes('scaling')||txt.includes('scale'))));});
  if(!matches.length){list.innerHTML='<div class="empty-zone">No encontré cartas con ese término.</div>';return;}
  let lastCat=''; let html='';
  for(const c of matches){
    if(c.category!==lastCat){lastCat=c.category;html+=`<div class="card-picker-category">${esc(lastCat)}</div>`;}
    const active=selectedCard && Number(selectedCard.id)===Number(c.id) ? ' selected' : '';
    const life=c.lifecycle_note?'<span class="lifecycle-flag">CICLO DE VIDA</span>':'';
    html+=`<button type="button" class="card-picker-item${active}" data-card-id="${c.id}"><div class="card-picker-main"><div class="card-picker-head">${serviceLogo(c)}<div><b>${esc(c.name)} ${life}</b><small>${esc(c.provider)} · ${esc(c.code)}</small></div></div><div class="picker-stats">${cardStatChips(c)}</div></div><div class="card-picker-cost">${money(c.monthly_cost)}</div></button>`;
  }
  list.innerHTML=html;
  list.querySelectorAll('.card-picker-item').forEach(btn=>btn.addEventListener('click',()=>selectCard(Number(btn.dataset.cardId))));
}
function selectCard(id){
  selectedCard=(A.cards||[]).find(c=>Number(c.id)===Number(id))||null;
  const idInput=document.getElementById('selectedCardId'); const deploy=document.getElementById('deployCardBtn');
  if(idInput) idInput.value=selectedCard?selectedCard.id:''; if(deploy) deploy.disabled=true; const pq=document.getElementById('pronunciationQuestion');if(pq)pq.classList.add('d-none');document.querySelectorAll('input[name="pronunciation_correct"]').forEach(x=>{x.checked=false;x.disabled=true});
  renderCardPicker(document.getElementById('cardSearch')?.value||''); renderSelectedCard();
}
function renderSelectedCard(){
  const box=document.getElementById('selectedCardPreview'); if(!box) return;
  if(!selectedCard){box.innerHTML='<div class="empty-zone">Busca y selecciona una carta. Aquí verás su costo, atributos, ciclo de vida y descripción antes de desplegarla.</div>';return;}
  const c=selectedCard; const speak=document.getElementById('speakCardBtn'); if(speak)speak.disabled=false;
  const lifecycle=c.lifecycle_note?`<div class="lifecycle-note"><b>⚠ Ciclo de vida</b><span>${esc(c.lifecycle_note)}</span></div>`:'';
  box.innerHTML=`<div class="selected-card-head"><div class="selected-card-brand">${serviceLogo(c)}<div><span class="eyebrow">CARTA SELECCIONADA</span><h3>${esc(c.name)}</h3><small>${esc(c.category)} · ${esc(c.provider)}</small></div></div><strong>${money(c.monthly_cost)}<small>/mes simulado</small></strong></div><p>${esc(c.description)}</p>${lifecycle}<div class="selected-card-stats">${Object.keys(metricLabels).map(k=>`<div><span>${shortLabels[k]}</span><b class="${Number(c[k])>0?'text-success':''}">${signed(c[k])}</b></div>`).join('')}</div><div class="complexity-line"><span>Complejidad</span><b>${Number(c.complexity)}/10</b></div><div class="preview-note">ARQWAR evaluará la carta contra el área, la casuística, las brechas, el incidente, el costo y los combos. Puede sumar, dar 0 o quitar puntos.</div>`;
}
function resetCardPicker(){
  selectedCard=null; const speak=document.getElementById('speakCardBtn'); if(speak)speak.disabled=true; const search=document.getElementById('cardSearch'); if(search) search.value='';
  const idInput=document.getElementById('selectedCardId'); if(idInput) idInput.value=''; const deploy=document.getElementById('deployCardBtn'); if(deploy) deploy.disabled=true;
  renderCardPicker(''); renderSelectedCard(); updateDeployReady();
}
document.getElementById('cardSearch')?.addEventListener('input',e=>renderCardPicker(e.target.value));
document.getElementById('playCardModal')?.addEventListener('shown.bs.modal',()=>document.getElementById('cardSearch')?.focus());
function speakSelectedCard(){if(!selectedCard)return;const q=document.getElementById('pronunciationQuestion');if(q){q.classList.remove('d-none');q.querySelectorAll('input').forEach(x=>x.disabled=false);}updateDeployReady();if(!('speechSynthesis' in window)){toast('Este navegador no ofrece síntesis de voz; evalúa la pronunciación manualmente.','warning');return;}window.speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(selectedCard.name);u.lang='en-US';u.rate=.82;u.pitch=1;window.speechSynthesis.speak(u);}
document.getElementById('speakCardBtn')?.addEventListener('click',speakSelectedCard);
document.getElementById('responderSelect')?.addEventListener('change',updateDeployReady);document.querySelectorAll('input[name="pronunciation_correct"]').forEach(x=>x.addEventListener('change',updateDeployReady));

// --- Feedback posterior a una carta ---
function feedbackClass(level){return {excellent:'feedback-excellent',good:'feedback-good',neutral:'feedback-neutral',poor:'feedback-poor'}[level]||'feedback-neutral'}
function showFeedback(feedback,teamName){
  const body=document.getElementById('feedbackBody'); if(!body||!feedback) return;
  const deltas=Object.entries(feedback.metric_deltas||{}).filter(([,v])=>Number(v)!==0).map(([k,v])=>`<span>${shortLabels[k]||k.toUpperCase()} <b>${signed(v)}</b></span>`).join('')||'<span>Sin cambios directos de métricas</span>';
  const benefits=(feedback.benefits||[]).map(x=>`<li>${esc(x)}</li>`).join('')||'<li>No generó un beneficio prioritario inmediato.</li>';
  const warnings=(feedback.warnings||[]).map(x=>`<li>${esc(x)}</li>`).join('');
  body.innerHTML=`<div class="feedback-summary ${feedbackClass(feedback.level)}"><div><span class="eyebrow">${esc(teamName||'EQUIPO')} · ${esc(feedback.card?.name||'CARTA')}</span><h2>${esc(feedback.rating)}</h2><p>${esc(feedback.reason)}</p></div><div class="feedback-points"><span>IMPACTO EN PUNTOS</span><strong>${signed(feedback.score_delta)}</strong><small>${feedback.score_before} → ${feedback.score_after} / 1000</small></div></div><div class="feedback-context-grid"><div><span>RELEVANCIA CON LA PROBLEMÁTICA</span><b>${Number(feedback.relevance_score||0)}/100</b></div><div><span>GANANCIA TÉCNICA BRUTA</span><b>${signed(feedback.raw_score_delta||0)}</b></div><div class="${Number(feedback.decision_adjustment||0)<0?'penalty':''}"><span>AJUSTE POR DECISIÓN</span><b>${signed(feedback.decision_adjustment||0)}</b></div></div><div class="feedback-deltas">${deltas}</div><div class="row g-3 mt-1"><div class="col-md-6"><div class="feedback-list good"><h3>✓ Beneficio para el equipo</h3><ul>${benefits}</ul></div></div><div class="col-md-6"><div class="feedback-list warn"><h3>⚠ Trade-offs / advertencias</h3>${warnings?`<ul>${warnings}</ul>`:'<p class="mb-0">No se detectaron advertencias importantes.</p>'}</div></div></div>${feedback.participant?`<div class="participant-feedback mt-3"><div><span>RESPONDIÓ</span><b>${esc(feedback.participant.alias)}</b></div><div><span>XP POR DECISIÓN</span><b>${signed(feedback.participant.card_points)}</b></div><div><span>PRONUNCIACIÓN</span><b>${feedback.participant.pronunciation_correct?'✓ Correcta +'+feedback.participant.pronunciation_bonus+' XP':'Sin bonus'}</b></div><div><span>XP TOTAL JUGADA</span><b>${signed(feedback.participant.total_points)}</b></div></div>`:''}<div class="feedback-cost mt-3"><span>Costo antes <b>${money(feedback.cost_before)}</b></span><span>Costo después <b>${money(feedback.cost_after)}</b></span><span>Impacto <b>${feedback.cost_delta>=0?'+':''}${money(feedback.cost_delta).replace('$-','-$')}</b></span></div>`;
  bootstrap.Modal.getOrCreateInstance(document.getElementById('feedbackModal')).show();
}
document.getElementById('playCardForm')?.addEventListener('submit',async e=>{
  e.preventDefault(); if(!selectedCard){toast('Selecciona una carta primero.','warning');return;}
  try{const j=await postForm(new FormData(e.target));bootstrap.Modal.getInstance(document.getElementById('playCardModal'))?.hide();resetCardPicker();await loadState();showFeedback(j.feedback,j.team_name);}catch(err){toast(err.message,'danger')}
});

// --- Dado 3D con número de suerte por lanzamiento ---
const diceFaces=['⚀','⚁','⚂','⚃','⚄','⚅'];
function diceCubeMarkup(){return `<div class="dice-roll-floor"><div class="dice-cube rolling-3d" id="diceCube"><div class="dice-side d1">⚀</div><div class="dice-side d2">⚁</div><div class="dice-side d3">⚂</div><div class="dice-side d4">⚃</div><div class="dice-side d5">⚄</div><div class="dice-side d6">⚅</div></div></div>`}
function rollDie(teamId,teamName){
  activeDiceTeam={id:teamId,name:teamName}; const body=document.getElementById('diceBody');
  body.innerHTML=`<div class="lucky-picker"><div class="eyebrow">${esc(teamName)}</div><h3>Elige tu número de suerte</h3><p class="text-secondary">Puedes cambiarlo en cada ronda, justo antes de tirar.</p><div class="lucky-number-grid">${[1,2,3,4,5,6].map(n=>`<button type="button" class="lucky-number-btn" data-lucky="${n}">${n}</button>`).join('')}</div><button type="button" class="btn btn-warning btn-lg mt-3" id="confirmDiceRoll" disabled>🎲 Lanzar dado</button></div>`;
  const modal=bootstrap.Modal.getOrCreateInstance(document.getElementById('diceModal'));modal.show();let lucky=0;
  body.querySelectorAll('.lucky-number-btn').forEach(b=>b.addEventListener('click',()=>{lucky=Number(b.dataset.lucky);body.querySelectorAll('.lucky-number-btn').forEach(x=>x.classList.toggle('selected',x===b));document.getElementById('confirmDiceRoll').disabled=false;}));
  document.getElementById('confirmDiceRoll').addEventListener('click',()=>executeDiceRoll(teamId,teamName,lucky));
}
async function executeDiceRoll(teamId,teamName,lucky){
  const body=document.getElementById('diceBody');body.innerHTML=`<div class="dice-stage">${diceCubeMarkup()}<h3>Rodando para ${esc(teamName)}...</h3><p>Número de suerte elegido: <b>${lucky}</b>. El dado gira y rebota antes de revelar el resultado.</p></div>`;
  const fd=new FormData();fd.set('action','roll_die');fd.set('game_id',A.gameId);fd.set('team_id',teamId);fd.set('lucky_number',lucky);fd.set('csrf',A.csrf);const started=Date.now();
  try{const j=await postForm(fd);const remaining=Math.max(0,1900-(Date.now()-started));await new Promise(r=>setTimeout(r,remaining));body.innerHTML=`<div class="dice-stage ${j.won_extra_card?'dice-win':'dice-miss'}"><div class="dice-result-pop">${diceFaces[j.result-1]}</div><div class="dice-numbers">Resultado <b>${j.result}</b> · Tu suerte <b>${j.lucky_number}</b></div><h2>${j.won_extra_card?'¡BONUS DESBLOQUEADO!':'No hubo bonus esta vez'}</h2><p>${j.won_extra_card?'Ganas 1 despliegue extra durante esta ronda.':'Mantienes tus 2 despliegues normales.'}</p></div>`;await loadState();}catch(e){body.innerHTML=`<div class="alert alert-danger mb-0">${esc(e.message)}</div>`;}
}

function metricRow(label,value,min){const ok=Number(value)>=Number(min);return `<div class="metric-line"><div><span>${label}</span><small>mín ${min}</small></div><div class="metric-track"><i style="width:${pct(value)}%"></i></div><b class="${ok?'text-success':'text-danger'}">${value}</b></div>`}
function scoreBreakdown(t){const b=t.score_breakdown||{};return `<div class="score-breakdown"><span>SEC <b>${b.security||0}/150</b></span><span>AVL <b>${b.availability||0}/150</b></span><span>SCL <b>${b.scalability||0}/150</b></span><span>PER <b>${b.performance||0}/150</b></span><span>REL <b>${b.reliability||0}/150</b></span><span>DEV <b>${b.devops||0}/100</b></span><span>FIN <b>${b.finops||0}/100</b></span><span>COMP <b>${b.compliance||0}/50</b></span><span class="${Number(b.decision||0)<0?'text-danger':''}">DEC <b>${signed(b.decision||0)}</b></span></div>`}
function ordinal(rank){return `#${Number(rank)||'-'}`}
function individualColor(theme){
  const map={
    blue:'#00eaff',red:'#ff365c',gold:'#ffc400',green:'#19d38b',purple:'#8b4dff',orange:'#ff8a2a',
    cyan:'#18d9ff',pink:'#ff3f9e',indigo:'#586cff',teal:'#12bfc1',lime:'#8ddd16',slate:'#71839d'
  };
  return map[String(theme||'blue')]||'#00eaff';
}
function teamCard(t,g){
  const team=t.team,s=t.stats,playerRoom=A.roomMode&&A.roomRole==='player';const individual=!!A.individualMode;const own=individual?Number(team.id)===Number(A.myTeamId):(!playerRoom||Number(team.id)===Number(A.myTeamId));
  const neon=individual?individualColor(team.theme_key):'';
  const style=individual?` style="--team-neon:${neon}"`:'';
  const competitorLabel=individual?'JUGADOR':'EQUIPO';
  const ownLabel=individual?'Tu jugador':'Tu equipo';
  const combos=(t.combos||[]).map(c=>`<span class="combo-pill">⚡ ${esc(c.name)}</span>`).join('')||'<span class="text-secondary small">Sin combos activos</span>';
  const cards=(t.cards||[]).map(c=>`<div class="deployed-chip"><div><b>${esc(c.name)}</b><small>${esc(c.category)} · ${esc(c.provider)}${c.responder_alias?` · respondió ${esc(c.responder_alias)}`:''}${Number(c.decision_points||0)<0?` · <span class="text-danger">${signed(c.decision_points)} decisión</span>`:''}</small></div>${own?`<button class="btn btn-sm btn-outline-danger remove-card" data-id="${c.placement_id}">×</button>`:''}</div>`).join('')||'<div class="empty-zone">Sin cartas desplegadas</div>';
  const dice=t.dice_roll;
  const diceView=dice?`<div class="team-dice-result ${Number(dice.won_extra_card)===1?'won':''}"><span class="mini-die">${diceFaces[Number(dice.result)-1]}</span><div><b>Dado: ${dice.result}</b><small>Suerte ${dice.lucky_number} · ${Number(dice.won_extra_card)===1?'BONUS +1 carta':'Sin bonus'}</small></div></div>`:`<button class="btn btn-outline-info btn-sm roll-die" data-team="${team.id}" data-name="${esc(team.name)}" ${g.status!=='running'||!own?'disabled':''}>${!own?'🔒 '+(individual?'Solo su jugador':'Solo su equipo'):'🎲 Lanzar dado'}</button>`;
  const canPlay=g.status==='running'&&Number(t.deployments_remaining)>0&&own;
  const members=(t.members||[]).map(m=>`<span class="member-name-pill">${esc(m.name)}<small>${esc(m.role||'Participante')}</small></span>`).join('')||'<span class="text-secondary small">Sin participante asignado</span>';
  const quotaClass=Number(t.deployments_remaining)>0?'text-success':'text-danger';
  return `<div class="col-xxl-6"><section class="panel team-panel ${((individual||playerRoom)&&!own)?'team-readonly':''}${individual?' individual-player-panel':''}" data-slot="${team.slot_no}" data-player="${individual?'1':'0'}"${style}>
    <div class="team-scoreboard"><div class="d-flex gap-3 align-items-start"><div class="rank-badge">${ordinal(t.current_rank)}</div><div><div class="eyebrow">POSICIÓN ${team.slot_no} · ${competitorLabel}</div><div class="score-title">${esc(team.name)}</div><div class="score-total">${t.score}<small>/1000</small></div></div></div><div class="text-end"><div class="rep">REP ${team.reputation}</div><div class="sla">SLA ${Number(team.sla).toFixed(3)}%</div></div></div>
    ${individual?`<div class="individual-player-badge"><span class="theme-dot theme-${esc(team.theme_key)}"></span><b>${own?'TU CASILLA':'CASILLA DEL JUGADOR'}</b><small>${esc(team.name)}</small></div>`:''}
    ${scoreBreakdown(t)}
    <div class="round-actions"><div><span>DESPLIEGUES RONDA</span><strong class="${quotaClass}">${t.plays_this_round} / ${t.deployment_limit}</strong><small>${t.deployments_remaining} disponible(s)</small></div><div><span>DADO</span><strong>1 intento</strong><small>${own?'Elige suerte antes de lanzar':(individual?'Solo el jugador puede lanzarlo':'Solo el equipo puede lanzarlo')}</small></div>${diceView}</div>
    <div class="team-members-strip mb-3"><div class="eyebrow mb-2">${individual?'USUARIO':'PARTICIPANTES'}</div><div class="d-flex flex-wrap gap-2">${members}</div></div>
    <div class="metrics mt-3">${metricRow('Security',s.security,g.min_security)}${metricRow('Availability',s.availability,g.min_availability)}${metricRow('Scalability',s.scalability,g.min_scalability)}${metricRow('Performance',s.performance,g.min_performance)}${metricRow('Reliability',s.reliability,g.min_reliability)}${metricRow('DevOps',s.devops,g.min_devops)}</div>
    <div class="budget-box mt-3"><div><span>Costo mensual</span><b>${money(t.cost)}</b></div><div><span>Presupuesto</span><b>${money(t.budget)}</b></div><div><span>FinOps</span><b>${t.finops}</b></div></div>
    <div class="mt-3"><div class="eyebrow mb-2">COMBOS</div><div class="d-flex flex-wrap gap-1">${combos}</div></div>
    <div class="d-flex justify-content-between align-items-center mt-3 gap-2 flex-wrap"><div><div class="eyebrow">CARTAS EN MESA (${(t.cards||[]).length})</div>${!canPlay&&!dice&&own?'<small class="text-warning">Sin cupos normales: prueba el dado para intentar ganar 1 extra.</small>':''}${playerRoom&&!own?`<small class="text-secondary">Solo puedes modificar ${individual?'tu propia casilla':'las cartas de tu equipo'}.</small>`:''}</div><button class="btn btn-warning btn-sm play-card" data-team="${team.id}" data-name="${esc(team.name)}" ${canPlay?'':'disabled'}>${own?'+ Registrar carta física':'🔒 '+(individual?'Solo tu jugador':'Solo tu equipo')}</button></div>
    <div class="deployed-list mt-2">${cards}</div>${(!individual&&!playerRoom)?`<button class="btn btn-sm btn-outline-secondary mt-3 reset-team" data-team="${team.id}">Reiniciar equipo</button>`:(individual&&own?`<button class="btn btn-sm btn-outline-secondary mt-3 reset-team" data-team="${team.id}">Reiniciar jugador</button>`:'')}
  </section></div>`;
}

// Mesa virtual — generación automática por estado (nueva partida / nuevo jugador).
// Se reutilizan los botones .roll-die, .play-card y .remove-card ya existentes.
const MESA_SIDES=['south','north','west','east'];
function mesaSeat(t,g){
  const team=t.team||{};
  const cards=t.cards||[];
  const id=Number(team.id)||0;
  const roomPlayer=A.roomMode&&A.roomRole==='player';
  const own=A.individualMode ? id===Number(A.myTeamId) : (!roomPlayer||id===Number(A.myTeamId));
  const canPlay=own&&g.status==='running'&&Number(t.deployments_remaining)>0;
  const canDice=own&&g.status==='running'&&!t.dice_roll;
  const slot=Number(team.slot_no)||0;
  const shown=cards.slice(0,2).map(c=>`<div class="arqwar-mesa-physical" title="${esc(c.name)}"><span>▣ ${esc(c.name)}</span>${own?`<button type="button" class="remove-card" data-id="${Number(c.placement_id)}" title="Retirar carta ${esc(c.name)}" aria-label="Retirar carta ${esc(c.name)}">×</button>`:''}</div>`).join('');
  const more=cards.length>2?`<small class="arqwar-mesa-more">+${cards.length-2} carta(s) adicional(es)</small>`:'';
  const dice=t.dice_roll;
  const diceContent=dice ? `<span class="arqwar-mesa-dice-result" title="Suerte: ${Number(dice.lucky_number)}">🎲 ${Number(dice.result)} ${Number(dice.won_extra_card)?'· BONUS':''}</span>` : `<button type="button" class="arqwar-mesa-action roll-die" data-team="${id}" data-name="${esc(team.name)}" ${canDice?'':'disabled'} title="${own?'Lanzar el dado estratégico':'Solo el jugador o equipo responsable puede lanzar'}">🎲 Dado</button>`;
  return `<article class="arqwar-mesa-seat" data-seat-id="${id}" data-slot-no="${slot}">
    <div class="arqwar-mesa-seat-top">
      <span class="arqwar-mesa-seat-number">${A.individualMode?'JUGADOR':'EQUIPO'} ${slot}</span>
      <span class="arqwar-mesa-seat-score">${Number(t.score)||0}<small> / 1000</small></span>
    </div>
    <strong class="arqwar-mesa-seat-name" title="${esc(team.name)}">${esc(team.name)}</strong>
    <div class="arqwar-mesa-seat-meta"><span>▰ ${Number(t.plays_this_round)||0}/${Number(t.deployment_limit)||0} despliegues</span><span>${cards.length} carta(s)</span></div>
    <div class="arqwar-mesa-cards" aria-label="Cartas físicas desplegadas">${shown}${more||(!shown?'<span class="arqwar-mesa-empty">Casillas para cartas disponibles</span>':'')}</div>
    <div class="arqwar-mesa-seat-actions">
      ${diceContent}
      <button type="button" class="arqwar-mesa-action arqwar-mesa-add play-card" data-team="${id}" data-name="${esc(team.name)}" ${canPlay?'':'disabled'} title="${own?'Registrar una carta física':'Solo el jugador o equipo responsable puede registrar cartas'}">＋ Carta</button>
      <button type="button" class="arqwar-mesa-action arqwar-mesa-view" data-mesa-details="${slot}" title="Ver ficha completa">↗</button>
    </div>
  </article>`;
}
function renderBattleTable(teams,g){
  const container=document.getElementById('arqwarMesaPlayers');
  const info=document.getElementById('arqwarMesaInfo');
  if(!container)return;
  const seats=[...(teams||[])].sort((a,b)=>(Number(a.team?.slot_no)||0)-(Number(b.team?.slot_no)||0));
  const grouped={north:[],east:[],south:[],west:[]};
  seats.forEach((t,i)=>grouped[MESA_SIDES[i%MESA_SIDES.length]].push(t));
  const label=A.individualMode?'jugadores':'equipos';
  if(info) info.innerHTML=`<span><b>${seats.length}</b> ${label}</span><span>RONDA <b>${Number(g.current_round)||0}/${Number(g.max_rounds)||0}</b></span>`;
  const sides=['south','north','west','east'];
  container.innerHTML=sides.map(side=>{
    const list=grouped[side];
    const contents=list.length?list.map(t=>mesaSeat(t,g)).join(''):`<div class="arqwar-mesa-vacant"><span>＋</span><small>${A.individualMode?'Esperando jugador':'Casilla disponible'}</small></div>`;
    return `<div class="arqwar-mesa-side arqwar-mesa-${side}" data-side="${side}" style="--mesa-count:${Math.max(1,list.length)}">${contents}</div>`;
  }).join('');
  container.querySelectorAll('[data-mesa-details]').forEach(b=>b.addEventListener('click',()=>{
    const details=document.getElementById('arqwarTeamDetails');
    if(details)details.open=true;
    const slot=b.dataset.mesaDetails;
    const target=[...document.querySelectorAll('#gmTeams .team-panel')].find(p=>String(p.dataset.slot)===slot);
    if(target)target.scrollIntoView({behavior:'smooth',block:'start'});
  }));
}

function bindTeamActions(){
  document.querySelectorAll('.play-card').forEach(b=>b.onclick=()=>{
    if(b.disabled)return;
    resetCardPicker();
    document.getElementById('playTeamId').value=b.dataset.team;
    const ts=(latestState?.teams||[]).find(x=>Number(x.team.id)===Number(b.dataset.team));
    const sel=document.getElementById('responderSelect');
    if(sel){
      if(A.roomMode&&A.roomRole==='player'){
        sel.value=String(A.myParticipantId||'');
      }else{
        sel.innerHTML='<option value="">Selecciona participante...</option>'+((ts?.members||[]).map(m=>`<option value="${m.participant_id}">${esc((A.avatarNames||{})[m.avatar_emoji]||'Avatar')} · ${esc(m.name)} · ${esc(m.role||'Participante')}</option>`).join(''));
      }
    }
    document.querySelectorAll('input[name="pronunciation_correct"]').forEach(x=>{x.checked=false;x.disabled=true});
    const pq=document.getElementById('pronunciationQuestion');if(pq)pq.classList.add('d-none');
    document.querySelector('#playCardModal .modal-title').textContent='Registrar carta · '+b.dataset.name;
    updateDeployReady();
    bootstrap.Modal.getOrCreateInstance(document.getElementById('playCardModal')).show()
  });
  document.querySelectorAll('.roll-die').forEach(b=>b.onclick=()=>{if(!b.disabled)rollDie(b.dataset.team,b.dataset.name)});
  document.querySelectorAll('.remove-card').forEach(b=>b.onclick=async()=>{const fd=new FormData();fd.set('action','remove_card');fd.set('game_id',A.gameId);fd.set('placement_id',b.dataset.id);fd.set('csrf',A.csrf);try{await postForm(fd);loadState()}catch(e){toast(e.message,'danger')}});
  document.querySelectorAll('.reset-team').forEach(b=>b.onclick=async()=>{if(!confirm('¿Retirar todas las cartas y reiniciar reputación/SLA/dados?'))return;const fd=new FormData();fd.set('action','reset_team');fd.set('game_id',A.gameId);fd.set('team_id',b.dataset.team);fd.set('csrf',A.csrf);try{await postForm(fd);loadState()}catch(e){toast(e.message,'danger')}});
}
function incidentHTML(i){
  if(!i)return '<div class="panel p-3 text-secondary">Sin incidente activo.</div>';
  return `<div class="incident-card incident-card-detailed"><div class="incident-main"><div class="eyebrow">INCIDENTE ACTIVO · ${esc((i.incident_type||'').toUpperCase())}</div><h2>${esc(i.name)}</h2><p class="incident-summary">${esc(i.description)}</p>${i.technical_detail?`<div class="incident-detail"><b>Qué está ocurriendo técnicamente</b><span>${esc(i.technical_detail)}</span></div>`:''}${i.nontechnical_example?`<div class="incident-analogy"><b>💡 Ejemplo no técnico</b><span>${esc(i.nontechnical_example)}</span></div>`:''}${i.business_impact?`<div class="incident-impact"><b>Impacto posible</b><span>${esc(i.business_impact)}</span></div>`:''}${i.response_hint?`<div class="incident-hint"><b>Pista de respuesta</b><span>${esc(i.response_hint)}</span></div>`:''}</div><div class="incident-req">${Object.entries(i.requirements||{}).map(([k,v])=>`<span>${esc(k.toUpperCase())} ≥ ${v}</span>`).join('')}</div></div>`;
}
let introHideTimer=null;

function scheduleIntroHide(video){
  if(introHideTimer) clearTimeout(introHideTimer);
  const duration=Number.isFinite(video.duration)&&video.duration>0 ? video.duration : 3;
  introHideTimer=setTimeout(hideStartIntro,Math.ceil(duration*1000)+250);
}

function showStartIntro(game=null){
  const overlay=document.getElementById('introPartida');
  const video=document.getElementById('videoIntro');
  if(!overlay||!video)return;
  const key='arqwar_intro_seen_'+A.gameId;
  if(sessionStorage.getItem(key)==='1')return;
  sessionStorage.setItem(key,'1');

  overlay.style.display='block';
  video.muted=true;
  video.playsInline=true;

  // Los jugadores que entran unos instantes despues del GM se sincronizan
  // con el momento real en que la partida paso a estado running.
  let elapsed=0;
  if(game?.started_at){
    const started=Date.parse(String(game.started_at).replace(' ','T'));
    if(Number.isFinite(started)){
      elapsed=Math.max(0,(Date.now()-started)/1000);
    }
  }

  const duration=Number.isFinite(video.duration)&&video.duration>0 ? video.duration : 3;
  if(elapsed>=duration){
    hideStartIntro();
    return;
  }

  try{video.currentTime=elapsed;}catch(e){video.currentTime=0;}
  scheduleIntroHide(video);

  const play=video.play();
  if(play&&typeof play.catch==='function')play.catch(()=>{
    // Si el navegador bloquea la reproduccion, no dejamos la pantalla
    // congelada: la partida continua automaticamente.
    hideStartIntro();
  });
}

function hideStartIntro(){
  if(introHideTimer){clearTimeout(introHideTimer);introHideTimer=null;}
  const overlay=document.getElementById('introPartida');
  const video=document.getElementById('videoIntro');
  if(video){video.pause();try{video.currentTime=0;}catch(e){}}
  if(overlay)overlay.style.display='none';
}

const introVideo=document.getElementById('videoIntro');
introVideo?.addEventListener('ended',hideStartIntro);
introVideo?.addEventListener('loadedmetadata',()=>{
  if(document.getElementById('introPartida')?.style.display==='block') scheduleIntroHide(introVideo);
});

function handleGameLifecycle(g,d){
  const status=String(g?.status||'');
  if(lastGameStatus===null){
    lastGameStatus=status;
    if(status==='running'&&g?.started_at){
      const started=Date.parse(String(g.started_at).replace(' ','T'));
      if(Number.isFinite(started)&&Math.abs(Date.now()-started)<8000)showStartIntro(g);
    }
    if(status==='finished'&&d?.final_summary&&!winnerShown){
      winnerShown=true;
      showWinnerCelebration(d.final_summary);
    }
    return;
  }
  if(lastGameStatus==='setup'&&status==='running')showStartIntro(g);
  if(lastGameStatus!=='finished'&&status==='finished'&&d?.final_summary&&!winnerShown){
    winnerShown=true;
    showWinnerCelebration(d.final_summary);
  }
  lastGameStatus=status;
}

async function loadState(){
  if(!A.gameId) return;
  try{
    const r=await fetch(`api/state.php?game_id=${A.gameId}&t=${Date.now()}`);const j=await r.json();if(!j.ok)throw new Error(j.error);const d=j.data,g=d.game;
    handleGameLifecycle(g,d);
    latestState=d;
    document.getElementById('gmStatus').textContent=g.status;document.getElementById('gmRound').textContent=g.current_round;
    document.getElementById('gmScenario').innerHTML=`<div class="d-flex justify-content-between flex-wrap gap-3"><div><div class="eyebrow">${esc(g.scenario_area)} · MISIÓN · ${esc(g.client_name)}</div><h2 class="h4 mb-1">${esc(g.scenario_name)}</h2><p class="text-secondary mb-0">${esc(g.scenario_description)}</p></div><div class="scenario-kpis"><span>Budget <b>${money(g.scenario_budget)}</b></span><span>SLA <b>${g.sla_target}%</b></span><span>Carga <b>${esc(g.user_load)}</b></span><span>🎲 Suerte <b>se elige al lanzar</b></span></div></div><div class="req-row mt-3"><span>SEC ≥ ${g.min_security}</span><span>AVL ≥ ${g.min_availability}</span><span>SCL ≥ ${g.min_scalability}</span><span>PER ≥ ${g.min_performance}</span><span>REL ≥ ${g.min_reliability}</span><span>DEV ≥ ${g.min_devops}</span></div>`;
    document.getElementById('gmIncident').innerHTML=incidentHTML(d.incident);
    document.getElementById('gmTeams').innerHTML=d.teams.map(t=>teamCard(t,g)).join('');
    renderBattleTable(d.teams,g);bindTeamActions();
    document.getElementById('gmLogs').innerHTML=d.logs.map(l=>`<div><span>${esc(l.created_at)}</span><b>${esc(l.team_name||'SYSTEM')}</b><em>${esc(l.message)}</em></div>`).join('');
    renderChatTabs(); loadChat();
  }catch(e){toast(e.message,'danger')}
}
function showWinnerCelebration(summary){
  const body=document.getElementById('winnerBody');if(!body)return;const winners=summary.winners||[], standings=summary.standings||[];
  const names=winners.map(w=>esc(w.name)).join(' & ');body.innerHTML=`<div class="celebration-confetti" aria-hidden="true">🎉 ✨ 🏆 🎊 ⭐ 🎉</div><div class="winner-trophy">🏆</div><div class="eyebrow">PARTIDA FINALIZADA</div><h1 class="winner-title">¡${names||'Tenemos campeón'}!</h1><p class="winner-subtitle">${winners.length>1?'Empate en el primer lugar':'Campeón de la batalla'} · ${esc(summary.game?.scenario_name||'ARQWAR')}</p><div class="winner-score-big">${winners.map(w=>`<div><b>${esc(w.name)}</b><strong>${w.final_score}</strong><span>/1000 pts</span></div>`).join('')}</div><div class="final-standings-mini">${standings.map(s=>`<span class="${Number(s.is_winner)===1?'champ':''}"><b>#${s.final_rank}</b> ${esc(s.name)} <strong>${s.final_score}</strong></span>`).join('')}</div>`;bootstrap.Modal.getOrCreateInstance(document.getElementById('winnerModal')).show();
}
document.getElementById('winnerAcceptBtn')?.addEventListener('click',()=>{location.href='index.php';});
if(A.gameId){renderCardPicker('');loadState();setInterval(loadState,1000);setInterval(loadChat,2500)}

// --- Chat general y chat privado por equipo ---
let chatTeam=0;
function chatTeams(){return latestState?.teams||[];}
function renderChatTabs(){
  const box=document.getElementById('chatTabs'); if(!box)return;
  if(A.individualMode){
    chatTeam=0;
    box.innerHTML='<button type="button" class="chat-tab active" data-chat-team="0">General</button>';
    return;
  }
  const playerRoom=A.roomMode&&A.roomRole==='player';
  if(playerRoom&&chatTeam&&Number(chatTeam)!==Number(A.myTeamId))chatTeam=0;
  const teams=playerRoom?chatTeams().filter(t=>Number(t.team.id)===Number(A.myTeamId)):chatTeams();
  box.innerHTML='<button type="button" class="chat-tab '+(!chatTeam?'active':'')+'" data-chat-team="0">General</button>'+teams.map(t=>`<button type="button" class="chat-tab ${Number(t.team.id)===chatTeam?'active':''}" data-chat-team="${t.team.id}">👥 ${esc(t.team.name)}</button>`).join('');
  box.querySelectorAll('.chat-tab').forEach(b=>b.onclick=()=>{chatTeam=Number(b.dataset.chatTeam);renderChatTabs();loadChat();});
}
function chatTime(value){
  const s=String(value||'');
  const m=s.match(/\s(\d{2}:\d{2})/);
  return m?m[1]:s;
}
async function loadChat(){
  if(!A.gameId)return;
  try{
    const r=await fetch(`api/chat.php?game_id=${A.gameId}&team_id=${chatTeam}&t=${Date.now()}`);
    const j=await r.json();
    if(!j.ok)throw Error(j.error);
    const box=document.getElementById('chatMessages');
    if(!box)return;
    const nearBottom=box.scrollHeight-box.scrollTop-box.clientHeight<60;
    if(j.me){
      const identity=document.getElementById('chatIdentity');
      if(identity){
        identity.innerHTML=`<span class="chat-identity-avatar arqwar-avatar animated-avatar">${j.me.avatar_html||j.me.avatar_svg||''}</span><span>Enviando como <b>${esc(j.me.name||'Participante')}</b></span>`;
      }
    }
    box.innerHTML=j.messages.map(m=>{
      const mine=!!m.mine;
      const team=!chatTeam&&m.team_name?`<span class="chat-team-name">${esc(m.team_name)}</span>`:'';
      const avatar=m.avatar_html||m.avatar_svg||'';
      return `<div class="chat-msg ${mine?'mine':'other'}">
        <div class="chat-avatar arqwar-avatar animated-avatar">${avatar}</div>
        <div class="chat-bubble">
          <div class="chat-meta"><b>${esc(m.alias||'Participante')}</b>${team}<small>${chatTime(m.created_at)}</small></div>
          <div class="chat-text">${esc(m.message)}</div>
        </div>
      </div>`;
    }).join('')||'<div class="empty-zone">Todavía no hay mensajes.</div>';
    if(nearBottom||j.messages.length<2)box.scrollTop=box.scrollHeight;
  }catch(e){toast(e.message,'danger')}
}

document.getElementById('chatForm')?.addEventListener('submit',async e=>{
  e.preventDefault();
  const input=document.getElementById('chatInput');
  const message=input?.value.trim()||'';
  if(!message)return;
  const fd=new FormData();
  fd.set('game_id',A.gameId);fd.set('team_id',chatTeam);fd.set('message',message);fd.set('csrf',A.csrf);
  try{
    await fetch('api/chat.php',{method:'POST',body:fd}).then(async r=>{const j=await r.json();if(!r.ok||!j.ok)throw Error(j.error||'No se pudo enviar');return j});
    input.value='';
    document.getElementById('emojiPicker')?.setAttribute('hidden','');
    await loadChat();
    input.focus();
  }catch(e){toast(e.message,'danger')}
});

// Selector de caritas estilo mensajería
(()=>{
  const toggle=document.getElementById('emojiToggle'),picker=document.getElementById('emojiPicker'),input=document.getElementById('chatInput');
  if(!toggle||!picker||!input)return;
  toggle.addEventListener('click',e=>{e.stopPropagation();picker.hidden=!picker.hidden;});
  picker.querySelectorAll('.emoji-item').forEach(b=>b.addEventListener('click',()=>{
    const emoji=b.dataset.emoji||'';
    const start=input.selectionStart??input.value.length,end=input.selectionEnd??input.value.length;
    input.setRangeText(emoji,start,end,'end');
    input.focus();
  }));
  document.addEventListener('click',e=>{if(!picker.contains(e.target)&&e.target!==toggle)picker.hidden=true;});
})();
