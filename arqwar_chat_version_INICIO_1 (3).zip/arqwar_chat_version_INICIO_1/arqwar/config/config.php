<?php

return [
    'app_name' => 'ARQWAR',
    'timezone' => 'America/Lima',

    'db' => [
        'host' => '127.0.0.1',
        'port' => 3306,
        'name' => 'arqwar',
        'user' => 'root',
        'pass' => '',
        'charset' => 'utf8mb4',
    ],

    'mail' => [
        'driver' => 'smtp',
        'host' => 'smtp.gmail.com',
        'port' => 587,
        'encryption' => 'tls',

        // TU CUENTA DE GMAIL
        'username' => 'estiven.enrique.ccente.98@gmail.com
',

        // CONTRASENA DE APLICACION DE GOOGLE
        'password' => 'hrjk wrix mwhw ayqt',

        // EL MISMO GMAIL
        'from_email' => 'estiven.enrique.ccente.98@gmail.com
',

        'from_name' => 'ARQWAR · Seguridad de cuenta',
        'reply_to' => '',
        'timeout' => 20,
    ],

    'base_stats' => [
        'security' => 20,
        'availability' => 20,
        'scalability' => 20,
        'performance' => 20,
        'reliability' => 20,
        'devops' => 20,
    ],
];