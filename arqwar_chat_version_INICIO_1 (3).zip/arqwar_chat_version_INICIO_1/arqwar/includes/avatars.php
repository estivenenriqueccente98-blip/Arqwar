<?php
/**
 * Catálogo y renderizado de avatares ARQWAR.
 * Se comparte entre participantes, chat, salas y ranking.
 */
function arqwar_avatar_catalog(): array
{
    return [
        'cyber_skull' => ['tag' => '#cybe', 'name' => 'Cráneo Cyber'],
        'mecha_helmet' => ['tag' => '#mech', 'name' => 'Casco Mecha'],
        'plasma_lion' => ['tag' => '#plas', 'name' => 'León de Plasma'],
        'neon_phoenix' => ['tag' => '#cybe', 'name' => 'Fénix Neón'],
        'electric_dragon' => ['tag' => '#mech', 'name' => 'Dragón Eléctrico'],
        'cosmic_gem' => ['tag' => '#cosm', 'name' => 'Gema Cósmica'],
        'cyber_shinobi' => ['tag' => '#cybe', 'name' => 'Shinobi Cyber'],
        'ia_core' => ['tag' => '#aic', 'name' => 'Núcleo IA'],
        'alpha_wolf' => ['tag' => '#wolf', 'name' => 'Lobo Alfa'],
        'wise_owl' => ['tag' => '#mech', 'name' => 'Búho Sabio Cyber'],
        'assault_droid' => ['tag' => '#cybe', 'name' => 'Droide Asalto'],
        'cyber_valkyrie' => ['tag' => '#valk', 'name' => 'Valquiria Cyber'],
        'cyber_kitsune' => ['tag' => '#beast', 'name' => 'Ciber Kitsune'],
        'hydra_ai' => ['tag' => '#aic', 'name' => 'Hydra AI'],
        'quantum_kraken' => ['tag' => '#beast', 'name' => 'Kraken Quantum'],
        'spectre_v' => ['tag' => '#spec', 'name' => 'Spectre V'],
        'plasma_panther' => ['tag' => '#plas', 'name' => 'Pantera Plasma'],
        'cyber_mantis' => ['tag' => '#mech', 'name' => 'Ciber Mantis'],
        'titan_lightning' => ['tag' => '#titan', 'name' => 'Titán Relámpago'],
        'holo_gladiator' => ['tag' => '#glad', 'name' => 'Gladiador Holo'],
        'cyber_scorpion' => ['tag' => '#beast', 'name' => 'Ciber Escorpión'],
        'cubic_fox' => ['tag' => '#cosm', 'name' => 'Zorro Cúbico'],
        'neon_serpent' => ['tag' => '#beast', 'name' => 'Serpiente Neón'],
        'holo_trophy' => ['tag' => '#rank', 'name' => 'Trofeo Holográfico'],
    ];
}

function arqwar_avatar_legacy_map(): array
{
    return [
        '👤' => 'cyber_skull',
        '🧑' => 'mecha_helmet',
        '👨' => 'plasma_lion',
        '👩' => 'neon_phoenix',
        '🧑‍💻' => 'electric_dragon',
        '👨‍💻' => 'cosmic_gem',
        '👩‍💻' => 'cyber_shinobi',
        '🧠' => 'ia_core',
        '🚀' => 'alpha_wolf',
        '⚡' => 'wise_owl',
        '🔥' => 'assault_droid',
        '🛡️' => 'cyber_valkyrie',
        '🐉' => 'cyber_kitsune',
        '🦊' => 'hydra_ai',
        '🦁' => 'quantum_kraken',
        '🐺' => 'spectre_v',
        '🦅' => 'plasma_panther',
        '🦉' => 'cyber_mantis',
        '🐼' => 'titan_lightning',
        '🤖' => 'holo_gladiator',
        '🎯' => 'cyber_scorpion',
        '🧩' => 'cubic_fox',
        '🎮' => 'neon_serpent',
        '🏆' => 'holo_trophy',
    ];
}

function arqwar_avatar_key(string $value): string
{
    $catalog = arqwar_avatar_catalog();
    $legacy = arqwar_avatar_legacy_map();
    $value = trim($value);

    if (isset($catalog[$value])) {
        return $value;
    }

    if (isset($legacy[$value])) {
        return $legacy[$value];
    }

    return 'cyber_skull';
}

function arqwar_avatar_meta(string $value): array
{
    $catalog = arqwar_avatar_catalog();
    $key = arqwar_avatar_key($value);
    return $catalog[$key];
}

function arqwar_avatar_svg(string $value): string
{
    $key = arqwar_avatar_key($value);

    $cyan = '#19E3FF';
    $cyan2 = '#5BF2FF';
    $gold = '#FFC928';
    $pink = '#FF3ED1';

    switch ($key) {
        case 'cyber_skull':
            return <<<SVG
<svg viewBox="0 0 64 64" aria-hidden="true">
  <g fill="none" stroke="$cyan" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
    <circle cx="32" cy="26" r="15"/>
    <path d="M22 41h20v6c0 2-2 4-4 4H26c-2 0-4-2-4-4z"/>
    <circle cx="27" cy="25" r="2.5"/>
    <circle cx="37" cy="25" r="2.5"/>
    <path d="M30 31h4M27 45v3M32 45v3M37 45v3"/>
    <path d="M20 21l-4-2M44 21l4-2M25 15l-2-4M39 15l2-4"/>
  </g>
  <circle cx="32" cy="32" r="26" fill="none" stroke="$gold" stroke-opacity=".25"/>
</svg>
SVG;

        case 'mecha_helmet':
            return <<<SVG
<svg viewBox="0 0 64 64" aria-hidden="true">
  <g fill="none" stroke="$cyan" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">
    <path d="M32 10l18 9v14c0 11-8 18-18 21-10-3-18-10-18-21V19z"/>
    <path d="M22 29h20"/>
    <path d="M24 24c2-4 6-6 8-6s6 2 8 6"/>
    <path d="M26 37c4 2 8 2 12 0"/>
    <path d="M20 20l-3-2M44 20l3-2"/>
  </g>
  <path d="M24 29h16" stroke="$gold" stroke-width="2.4" stroke-linecap="round"/>
</svg>
SVG;

        case 'plasma_lion':
            return <<<SVG
<svg viewBox="0 0 64 64" aria-hidden="true">
  <g fill="none" stroke="$cyan" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
    <path d="M32 9l5 8 10-2-1 10 8 5-8 5 1 10-10-2-5 8-5-8-10 2 1-10-8-5 8-5-1-10 10 2z"/>
    <path d="M24 30c2-5 6-8 8-8s6 3 8 8"/>
    <path d="M26 37c4 2 8 2 12 0"/>
    <path d="M30 29h4"/>
  </g>
  <path d="M32 20l4 6h-8z" fill="none" stroke="$gold" stroke-width="2.2"/>
</svg>
SVG;

        case 'neon_phoenix':
            return <<<SVG
<svg viewBox="0 0 64 64" aria-hidden="true">
  <g fill="none" stroke="$cyan" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">
    <path d="M32 13c4 4 5 9 4 13 7-2 13 1 17 7-7 1-12 4-16 9-2 2-3 5-4 9-1-4-2-7-4-9-4-5-9-8-16-9 4-6 10-9 17-7-1-4 0-9 2-13z"/>
    <path d="M32 20l-1 12"/>
    <path d="M32 21l5-3M31 21l-5-3"/>
  </g>
  <path d="M32 16l3 5-3 3-3-3z" fill="none" stroke="$pink" stroke-width="2"/>
</svg>
SVG;

        case 'electric_dragon':
            return <<<SVG
<svg viewBox="0 0 64 64" aria-hidden="true">
  <g fill="none" stroke="$cyan" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
    <path d="M13 23l12-8 12 6 14-8-8 14 8 12-14-3-10 12-2-13-13-4 10-8z"/>
    <path d="M31 21l7 6-5 3 4 7-10-4"/>
  </g>
  <path d="M33 23l5 4-4 3" stroke="$pink" stroke-width="2.4" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
SVG;

        case 'cosmic_gem':
            return <<<SVG
<svg viewBox="0 0 64 64" aria-hidden="true">
  <g fill="none" stroke="$cyan" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">
    <path d="M32 10l16 14-16 30L16 24z"/>
    <path d="M22 18h20"/>
    <path d="M24 24l8 30 8-30"/>
  </g>
  <path d="M32 10l6 8H26z" fill="none" stroke="$gold" stroke-width="2"/>
</svg>
SVG;

        case 'cyber_shinobi':
            return <<<SVG
<svg viewBox="0 0 64 64" aria-hidden="true">
  <g fill="none" stroke="$cyan" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">
    <path d="M20 15h24l9 17-9 17H20l-9-17z"/>
    <path d="M21 30h22"/>
    <path d="M24 30l4-6h8l4 6"/>
    <path d="M25 37c5 2 9 2 14 0"/>
  </g>
  <rect x="25" y="27" width="14" height="6" rx="2" fill="none" stroke="$gold" stroke-width="2"/>
</svg>
SVG;

        case 'ia_core':
            return <<<SVG
<svg viewBox="0 0 64 64" aria-hidden="true">
  <g fill="none" stroke="$cyan" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round">
    <path d="M19 16h26l10 16-10 16H19L9 32z"/>
    <circle cx="32" cy="32" r="11"/>
    <circle cx="32" cy="32" r="3"/>
    <path d="M32 9v8M55 32h-8M32 55v-8M9 32h8"/>
  </g>
  <circle cx="32" cy="32" r="6" fill="none" stroke="$gold" stroke-width="2"/>
</svg>
SVG;

        case 'alpha_wolf':
            return <<<SVG
<svg viewBox="0 0 64 64" aria-hidden="true">
  <g fill="none" stroke="$cyan" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round">
    <path d="M17 18l10 5 5-7 5 7 10-5-3 12 5 8-10 2-7 8-7-8-10-2 5-8z"/>
    <path d="M24 36l8 6 8-6"/>
    <path d="M28 30h0M36 30h0"/>
  </g>
  <path d="M32 26v8" stroke="$gold" stroke-width="2.2" stroke-linecap="round"/>
</svg>
SVG;

        case 'wise_owl':
            return <<<SVG
<svg viewBox="0 0 64 64" aria-hidden="true">
  <g fill="none" stroke="$cyan" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">
    <circle cx="25" cy="29" r="8"/>
    <circle cx="39" cy="29" r="8"/>
    <path d="M18 24V18l7 5M46 24V18l-7 5"/>
    <path d="M18 38c3 8 9 12 14 12s11-4 14-12"/>
    <path d="M29 34l3 4 3-4"/>
  </g>
  <path d="M32 33l3 2-3 3-3-3z" fill="none" stroke="$gold" stroke-width="2"/>
</svg>
SVG;

        case 'assault_droid':
            return <<<SVG
<svg viewBox="0 0 64 64" aria-hidden="true">
  <g fill="none" stroke="$cyan" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">
    <rect x="19" y="18" width="26" height="24" rx="6"/>
    <path d="M32 12v6M25 47v5M39 47v5M15 25h4M45 25h4"/>
    <path d="M23 27h18"/>
    <circle cx="27" cy="31" r="2"/>
    <circle cx="37" cy="31" r="2"/>
  </g>
  <path d="M24 24h16" stroke="$gold" stroke-width="2.2" stroke-linecap="round"/>
</svg>
SVG;

        case 'cyber_valkyrie':
            return <<<SVG
<svg viewBox="0 0 64 64" aria-hidden="true">
  <g fill="none" stroke="$cyan" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round">
    <path d="M32 12l16 8v11c0 10-6 18-16 21-10-3-16-11-16-21V20z"/>
    <path d="M22 22l-6 6M42 22l6 6"/>
    <path d="M24 33h16"/>
  </g>
  <path d="M32 19l4 5h-8z" fill="none" stroke="$gold" stroke-width="2"/>
</svg>
SVG;

        case 'cyber_kitsune':
            return <<<SVG
<svg viewBox="0 0 64 64" aria-hidden="true">
  <g fill="none" stroke="$cyan" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round">
    <path d="M20 18l8 5 4-8 4 8 8-5-2 12 7 6-10 2-7 8-7-8-10-2 7-6z"/>
    <path d="M26 34l6 5 6-5"/>
    <path d="M29 29h0M35 29h0"/>
  </g>
  <path d="M32 31l3 3h-6z" fill="none" stroke="$gold" stroke-width="2"/>
</svg>
SVG;

        case 'hydra_ai':
            return <<<SVG
<svg viewBox="0 0 64 64" aria-hidden="true">
  <g fill="none" stroke="$cyan" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
    <circle cx="32" cy="20" r="5"/>
    <path d="M32 25v14"/>
    <path d="M32 28c-7 2-11 7-12 15"/>
    <path d="M32 28c0 0 0 0 0 0"/>
    <path d="M32 28c7 2 11 7 12 15"/>
    <path d="M29 30c-4 2-6 7-6 14"/>
    <path d="M35 30c4 2 6 7 6 14"/>
    <circle cx="20" cy="47" r="2"/>
    <circle cx="26" cy="46" r="2"/>
    <circle cx="38" cy="46" r="2"/>
    <circle cx="44" cy="47" r="2"/>
  </g>
  <circle cx="32" cy="20" r="2.5" fill="none" stroke="$gold" stroke-width="2"/>
</svg>
SVG;

        case 'quantum_kraken':
            return <<<SVG
<svg viewBox="0 0 64 64" aria-hidden="true">
  <g fill="none" stroke="$cyan" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
    <circle cx="32" cy="24" r="8"/>
    <path d="M24 31c-4 2-7 6-8 12"/>
    <path d="M28 31c-3 3-4 8-4 14"/>
    <path d="M36 31c3 3 4 8 4 14"/>
    <path d="M40 31c4 2 7 6 8 12"/>
    <path d="M31 24h0M33 24h0"/>
  </g>
  <circle cx="28" cy="23" r="1.5" fill="$gold"/>
  <circle cx="36" cy="23" r="1.5" fill="$gold"/>
</svg>
SVG;

        case 'spectre_v':
            return <<<SVG
<svg viewBox="0 0 64 64" aria-hidden="true">
  <g fill="none" stroke="$cyan" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">
    <path d="M20 15h24l8 10-6 21-14 5-14-5-6-21z"/>
    <path d="M22 21h20"/>
  </g>
  <path d="M25 28l7 12 7-12" stroke="$gold" stroke-width="2.4" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
SVG;

        case 'plasma_panther':
            return <<<SVG
<svg viewBox="0 0 64 64" aria-hidden="true">
  <g fill="none" stroke="$cyan" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round">
    <path d="M20 18h24l8 14-8 14H20l-8-14z"/>
    <path d="M23 29c3-4 6-6 9-6s6 2 9 6"/>
    <path d="M25 38c5 2 9 2 14 0"/>
  </g>
  <path d="M26 32h12" stroke="$gold" stroke-width="2.2" stroke-linecap="round"/>
</svg>
SVG;

        case 'cyber_mantis':
            return <<<SVG
<svg viewBox="0 0 64 64" aria-hidden="true">
  <g fill="none" stroke="$cyan" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
    <path d="M32 18v28"/>
    <path d="M26 24l-10-8M38 24l10-8"/>
    <path d="M28 29l-12 5M36 29l12 5"/>
    <path d="M27 37l-9 11M37 37l9 11"/>
    <path d="M29 18h6"/>
  </g>
  <path d="M31 18l1-5 1 5" stroke="$gold" stroke-width="2" fill="none" stroke-linecap="round"/>
</svg>
SVG;

        case 'titan_lightning':
            return <<<SVG
<svg viewBox="0 0 64 64" aria-hidden="true">
  <g fill="none" stroke="$cyan" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">
    <path d="M20 16h24l8 16-8 16H20l-8-16z"/>
  </g>
  <path d="M35 18l-7 12h5l-4 14 11-15h-6z" fill="none" stroke="$gold" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
SVG;

        case 'holo_gladiator':
            return <<<SVG
<svg viewBox="0 0 64 64" aria-hidden="true">
  <g fill="none" stroke="$cyan" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round">
    <circle cx="32" cy="32" r="16"/>
    <path d="M32 16v32M16 32h32"/>
  </g>
  <path d="M22 32c2-5 6-8 10-8s8 3 10 8" stroke="$gold" stroke-width="2" fill="none"/>
</svg>
SVG;

        case 'cyber_scorpion':
            return <<<SVG
<svg viewBox="0 0 64 64" aria-hidden="true">
  <g fill="none" stroke="$cyan" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
    <path d="M28 40c-6-2-10-7-10-13 0-7 6-12 14-12 7 0 12 4 14 10"/>
    <path d="M43 25c6 3 8 8 6 14-1 5-6 8-11 8"/>
    <path d="M38 30l8 6"/>
    <path d="M24 40l-4 6M30 42l-1 7"/>
  </g>
  <path d="M47 17c4 2 5 7 1 10" stroke="$gold" stroke-width="2.3" fill="none" stroke-linecap="round"/>
</svg>
SVG;

        case 'cubic_fox':
            return <<<SVG
<svg viewBox="0 0 64 64" aria-hidden="true">
  <g fill="none" stroke="$cyan" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round">
    <path d="M20 18l12-6 12 6 4 14-16 18-16-18z"/>
    <path d="M24 29c2-3 5-4 8-4s6 1 8 4"/>
    <path d="M27 36c3 2 7 2 10 0"/>
  </g>
  <path d="M32 17l3 4h-6z" fill="none" stroke="$gold" stroke-width="2"/>
</svg>
SVG;

        case 'neon_serpent':
            return <<<SVG
<svg viewBox="0 0 64 64" aria-hidden="true">
  <g fill="none" stroke="$cyan" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round">
    <path d="M43 14c-7 0-12 5-12 12v8c0 4-3 7-7 7-2 0-4-1-6-2"/>
    <path d="M43 14c4 1 7 4 8 8"/>
    <path d="M18 39c-3 2-5 5-5 8 0 4 3 7 7 7 5 0 9-4 9-9"/>
  </g>
  <path d="M45 13l5 3-4 4" stroke="$gold" stroke-width="2.2" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
SVG;

        case 'holo_trophy':
            return <<<SVG
<svg viewBox="0 0 64 64" aria-hidden="true">
  <g fill="none" stroke="$gold" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round">
    <path d="M24 14h16v8c0 7-4 12-8 15-4-3-8-8-8-15z"/>
    <path d="M24 18h-6c0 5 3 9 8 10M40 18h6c0 5-3 9-8 10"/>
    <path d="M32 37v8"/>
    <path d="M24 49h16"/>
  </g>
  <path d="M20 49h24" stroke="$cyan" stroke-width="2"/>
</svg>
SVG;

        default:
            return <<<SVG
<svg viewBox="0 0 64 64" aria-hidden="true">
  <circle cx="32" cy="24" r="10" fill="none" stroke="$cyan" stroke-width="2.4"/>
  <path d="M20 50c2-8 7-14 12-14s10 6 12 14" fill="none" stroke="$cyan" stroke-width="2.4" stroke-linecap="round"/>
</svg>
SVG;
    }
}


/** Colores de acento del catálogo 3D (claves persistentes, sin modificar la BD). */
function arqwar_avatar_accent(string $value): string
{
    $colors = [
        'cyber_skull'=>'#00eaff', 'mecha_helmet'=>'#ffbb36',
        'plasma_lion'=>'#2798ff', 'neon_phoenix'=>'#f04aff',
        'electric_dragon'=>'#24aeff', 'cosmic_gem'=>'#bc5aff',
        'cyber_shinobi'=>'#00eaff', 'ia_core'=>'#34f4d5',
        'alpha_wolf'=>'#53aaff', 'wise_owl'=>'#ffcb44',
        'assault_droid'=>'#17e1ff', 'cyber_valkyrie'=>'#d39aff',
        'cyber_kitsune'=>'#ff6479', 'hydra_ai'=>'#36f9d7',
        'quantum_kraken'=>'#32a4ff', 'spectre_v'=>'#48bdff',
        'plasma_panther'=>'#278aff', 'cyber_mantis'=>'#ffc154',
        'titan_lightning'=>'#6b8fff', 'holo_gladiator'=>'#ffd15b',
        'cyber_scorpion'=>'#ff684b', 'cubic_fox'=>'#9e75ff',
        'neon_serpent'=>'#19c8ff', 'holo_trophy'=>'#ffd45b',
    ];
    return $colors[arqwar_avatar_key($value)] ?? '#00eaff';
}

/** Imágenes generadas a partir del arte 3D proporcionado por el usuario. */
function arqwar_avatar_image_url(string $value, bool $portrait = false): string
{
    $key = arqwar_avatar_key($value); // Lista blanca de claves del catálogo.
    return 'assets/img/avatars-3d/' . $key . ($portrait ? '-icon' : '') . '.webp';
}

function arqwar_avatar_image_html(string $value, bool $portrait = false): string
{
    $key = arqwar_avatar_key($value);
    $url = arqwar_avatar_image_url($key, $portrait);
    // Alt vacío: el nombre del avatar ya está en el botón, título o contenido adyacente.
    return '<img class="arqwar-avatar-image" src="' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8')
        . '" alt="" decoding="async" loading="lazy" draggable="false">';
}

/** Componente de avatar compartido por equipos, ranking y otros módulos. */
function arqwar_avatar_html(string $value, string $class = ''): string
{
    $key = arqwar_avatar_key($value);
    $meta = arqwar_avatar_meta($key);
    $safeClass = trim('arqwar-avatar animated-avatar arqwar-avatar-3d ' . $class);
    return '<span class="' . htmlspecialchars($safeClass, ENT_QUOTES, 'UTF-8')
      . '" data-avatar-key="' . htmlspecialchars($key, ENT_QUOTES, 'UTF-8')
      . '" style="--avatar-neon:' . arqwar_avatar_accent($key)
      . '" title="' . htmlspecialchars($meta['name'], ENT_QUOTES, 'UTF-8')
      . '">' . arqwar_avatar_image_html($key, true) . '</span>';
}
