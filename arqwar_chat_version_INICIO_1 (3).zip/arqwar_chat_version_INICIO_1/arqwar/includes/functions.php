<?php
function json_out(array $data, int $status = 200): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function e(?string $value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(24));
    return $_SESSION['csrf'];
}

function verify_csrf(): void {
    $token = $_POST['csrf'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!$token || !hash_equals($_SESSION['csrf'] ?? '', $token)) json_out(['ok'=>false,'error'=>'CSRF inválido'], 419);
}

function current_user(): ?array {
    return !empty($_SESSION['user']) && is_array($_SESSION['user']) ? $_SESSION['user'] : null;
}

function is_admin(): bool {
    $u = current_user();
    return $u && (($u['role'] ?? 'operator') === 'admin');
}

function admin_required_html(): void {
    login_required_html();
    if (!is_admin()) {
        http_response_code(403);
        echo '<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ARQWAR · Acceso restringido</title><link href="assets/css/bootstrap.min.css" rel="stylesheet"><link rel="stylesheet" href="assets/css/app.css"></head><body class="gm-body"><main class="container py-5" style="max-width:760px"><div class="panel p-4"><div class="eyebrow">PERMISO REQUERIDO</div><h1 class="h3">Acceso exclusivo de administrador</h1><p class="text-secondary">Tu cuenta puede jugar, crear participantes/equipos y operar partidas, pero no puede editar o eliminar registros maestros.</p><a class="btn btn-warning" href="index.php">Volver al inicio</a></div></main></body></html>';
        exit;
    }
}

function login_required_html(): void {
    if (!current_user()) {
        $next = $_SERVER['REQUEST_URI'] ?? 'game-master.php';
        header('Location: login.php?next='.urlencode($next));
        exit;
    }
}

function gm_required(): void {
    if (!current_user()) json_out(['ok'=>false,'error'=>'Sesión requerida'], 401);
}

function admin_required_json(): void {
    if (!current_user()) json_out(['ok'=>false,'error'=>'Sesión requerida'], 401);
    if (!is_admin()) json_out(['ok'=>false,'error'=>'Permiso de administrador requerido'], 403);
}


function ensure_password_recovery_schema(): void {
    static $done=false;
    if($done) return;
    if(!db_column_exists('app_users','email')) {
        db()->exec("ALTER TABLE app_users ADD COLUMN email VARCHAR(190) NULL AFTER display_name");
    }
    if(!db_column_exists('app_users','password_reset_code_hash')) {
        db()->exec("ALTER TABLE app_users ADD COLUMN password_reset_code_hash VARCHAR(64) NULL AFTER email");
    }
    if(!db_column_exists('app_users','password_reset_expires_at')) {
        db()->exec("ALTER TABLE app_users ADD COLUMN password_reset_expires_at DATETIME NULL AFTER password_reset_code_hash");
    }
    if(!db_index_exists('app_users','uq_app_users_email')) {
        // Solo se crea el indice si no existen correos duplicados no nulos.
        $duplicates=row("SELECT COUNT(*) n FROM (SELECT email FROM app_users WHERE email IS NOT NULL AND email<>'' GROUP BY email HAVING COUNT(*)>1) d");
        if((int)($duplicates['n']??0)===0) {
            try { db()->exec("ALTER TABLE app_users ADD UNIQUE KEY uq_app_users_email (email)"); } catch(Throwable $e) { /* La recuperacion sigue funcionando sin el indice unico. */ }
        }
    }
    $done=true;
}

function normalize_email(string $email): string {
    $email=trim($email);
    return function_exists('mb_strtolower') ? mb_strtolower($email,'UTF-8') : strtolower($email);
}

function smtp_read_response($socket): array {
    $lines=[];
    $code=0;
    while (($line=fgets($socket, 515)) !== false) {
        $line=rtrim($line, "\r\n");
        $lines[]=$line;
        if (preg_match('/^(\d{3})([ -])/', $line, $m)) {
            $code=(int)$m[1];
            if ($m[2] === ' ') break;
        }
    }
    return [$code, implode("\n", $lines)];
}

function smtp_expect($socket, int $expected, string $context=''): void {
    [$code,$response]=smtp_read_response($socket);
    if ($code !== $expected) {
        $detail=trim(preg_replace('/\s+/', ' ', $response));
        throw new RuntimeException('SMTP '.$context.' fallo ('.$code.'): '.$detail);
    }
}

function smtp_command($socket, string $command, int $expected, string $context=''): void {
    if (fwrite($socket, $command."\r\n") === false) throw new RuntimeException('No se pudo enviar la orden SMTP.');
    smtp_expect($socket,$expected,$context);
}

function send_arqwar_recovery_email(string $to, string $displayName, string $code): bool {
    $cfg=arqwar_config()['mail']??[];
    $driver=strtolower(trim((string)($cfg['driver']??'smtp')));
    $from=trim((string)($cfg['from_email']??''));
    $fromName=trim((string)($cfg['from_name']??'ARQWAR · Seguridad de cuenta'));
    $reply=trim((string)($cfg['reply_to']??''));
    $subject='Codigo de recuperacion - DEVIOZ ARQWAR';
    $safeName=e($displayName ?: 'jugador');
    $safeCode=e($code);

    $html='<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head><body style="margin:0;background:#eef7fb;font-family:Arial,Helvetica,sans-serif;color:#102532"><div style="max-width:680px;margin:0 auto;padding:24px 10px"><div style="background:#ffffff;border:1px solid #cde5ee;border-radius:22px;overflow:hidden;box-shadow:0 12px 40px rgba(5,32,48,.12)"><div style="padding:30px 34px;background:linear-gradient(135deg,#032b35,#07162a 62%,#17204a);color:#fff"><div style="font-size:28px;font-weight:900;letter-spacing:.13em;text-shadow:0 0 14px rgba(0,234,255,.65)">ARQWAR</div><div style="margin-top:7px;font-size:12px;font-weight:800;letter-spacing:.18em;color:#45eaff">DEVIOZ · CENTRO DE OPERACIONES</div></div><div style="padding:38px 34px"><div style="display:inline-block;padding:7px 12px;border-radius:999px;background:#e8faff;color:#007e9b;font-size:12px;font-weight:800;letter-spacing:.08em">SEGURIDAD DE CUENTA</div><h1 style="margin:18px 0 12px;font-size:28px;color:#172a3a">Recuperacion de contraseña</h1><p style="font-size:16px;line-height:1.65;color:#526777">Hola <strong style="color:#172a3a">'.$safeName.'</strong>, recibimos una solicitud para recuperar tu contraseña de ARQWAR.</p><p style="font-size:16px;line-height:1.65;color:#526777">Tu codigo de verificacion es:</p><div style="margin:28px 0;padding:25px 18px;text-align:center;background:#f4fbfe;border:2px solid #10cfe8;border-radius:18px"><span style="font-size:46px;font-weight:900;letter-spacing:.24em;color:#062f3b">'.$safeCode.'</span></div><div style="padding:16px 18px;background:#fff8df;border-left:4px solid #f4b400;border-radius:10px;color:#6f5b19;font-size:14px;line-height:1.55"><strong>Importante:</strong> este codigo es valido durante 10 minutos. Si no solicitaste recuperar tu contraseña, ignora este mensaje.</div></div><div style="padding:22px 34px;background:#f7fbfd;border-top:1px solid #e1edf2;color:#718594;font-size:12px;line-height:1.6">Mensaje automatico de seguridad de <strong>DEVIOZ ARQWAR</strong>.<br>No respondas a este mensaje si no solicitaste el cambio.</div></div></div></body></html>';

    if ($driver === 'mail') {
        $headers="MIME-Version: 1.0\r\n";
        $headers.="Content-Type: text/html; charset=UTF-8\r\n";
        $headers.="X-Mailer: DEVIOZ ARQWAR\r\n";
        if($from && filter_var($from,FILTER_VALIDATE_EMAIL)) { $encodedName='=?UTF-8?B?'.base64_encode($fromName).'?='; $headers.='From: '.$encodedName.' <'.$from.">\r\n"; }
        if($reply && filter_var($reply,FILTER_VALIDATE_EMAIL)) $headers.='Reply-To: '.$reply."\r\n";
        $encodedSubject='=?UTF-8?B?'.base64_encode('Código de recuperación - DEVIOZ ARQWAR').'?=';
        return @mail($to,$encodedSubject,$html,$headers);
    }

    if ($driver !== 'smtp') return false;

    $host=trim((string)($cfg['host']??'smtp.gmail.com'));
    $port=(int)($cfg['port']??587);
    $encryption=strtolower(trim((string)($cfg['encryption']??'tls')));
    $username=trim((string)($cfg['username']??''));
    $password=(string)($cfg['password']??'');
    $timeout=max(5,(int)($cfg['timeout']??20));

    if ($username==='' || $password==='' || str_starts_with($username,'TU_CORREO_') || str_starts_with($password,'TU_CONTRASENA_')) {
        return false;
    }
    if (!filter_var($username,FILTER_VALIDATE_EMAIL) || !filter_var($to,FILTER_VALIDATE_EMAIL)) return false;
    if (!$from || !filter_var($from,FILTER_VALIDATE_EMAIL)) $from=$username;
    if (!function_exists('stream_socket_client')) return false;

    $transport=($encryption==='ssl' ? 'ssl://' : '').$host.':'.$port;
    $errno=0; $errstr='';
    $socket=@stream_socket_client($transport,$errno,$errstr,$timeout,STREAM_CLIENT_CONNECT);
    if(!$socket) return false;
    stream_set_timeout($socket,$timeout);

    try {
        smtp_expect($socket,220,'conexion');
        smtp_command($socket,'EHLO localhost',250,'EHLO');
        if($encryption==='tls') {
            smtp_command($socket,'STARTTLS',220,'STARTTLS');
            $crypto=@stream_socket_enable_crypto($socket,true,STREAM_CRYPTO_METHOD_TLS_CLIENT);
            if($crypto!==true) throw new RuntimeException('No se pudo activar TLS.');
            smtp_command($socket,'EHLO localhost',250,'EHLO TLS');
        }
        smtp_command($socket,'AUTH LOGIN',334,'autenticacion');
        smtp_command($socket,base64_encode($username),334,'usuario');
        smtp_command($socket,base64_encode($password),235,'contraseña');
        smtp_command($socket,'MAIL FROM:<'.$from.'>',250,'MAIL FROM');
        smtp_command($socket,'RCPT TO:<'.$to.'>',250,'RCPT TO');
        if(fwrite($socket,"DATA\r\n")===false) throw new RuntimeException('No se pudo iniciar DATA.');
        smtp_expect($socket,354,'DATA');

        $encodedName='=?UTF-8?B?'.base64_encode($fromName).'?=';
        $encodedSubject='=?UTF-8?B?'.base64_encode('Código de recuperación - DEVIOZ ARQWAR').'?=';
        $headers=[];
        $headers[]='From: '.$encodedName.' <'.$from.'>';
        $headers[]='To: '.$to;
        $headers[]='Subject: '.$encodedSubject;
        $headers[]='Date: '.date(DATE_RFC2822);
        $headers[]='MIME-Version: 1.0';
        $headers[]='Content-Type: text/html; charset=UTF-8';
        $headers[]='Content-Transfer-Encoding: 8bit';
        $headers[]='X-Mailer: DEVIOZ ARQWAR';
        if($reply && filter_var($reply,FILTER_VALIDATE_EMAIL)) $headers[]='Reply-To: '.$reply;
        $body=implode("\r\n",$headers)."\r\n\r\n".$html;
        $body=str_replace(["\r\n.","\n."],["\r\n..","\n.."],$body);
        if(substr($body,-2)!=="\r\n") $body.="\r\n";
        if(fwrite($socket,$body.".\r\n")===false) throw new RuntimeException('No se pudo enviar el contenido del correo.');
        smtp_expect($socket,250,'envio');
        @fwrite($socket,"QUIT\r\n");
        @fclose($socket);
        return true;
    } catch(Throwable $e) {
        @fwrite($socket,"QUIT\r\n");
        @fclose($socket);
        return false;
    }
}

function clear_password_recovery(): void {
    unset($_SESSION['password_recovery']);
}

function attempt_login(string $username, string $password): bool {
    $user = row('SELECT * FROM app_users WHERE username=? AND is_active=1 LIMIT 1', [trim($username)]);
    if (!$user || !password_verify($password, (string)$user['password_hash'])) return false;
    session_regenerate_id(true);
    $_SESSION['user'] = [
        'id'=>(int)$user['id'], 'username'=>$user['username'], 'display_name'=>$user['display_name'],
        'email'=>$user['email'] ?? null, 'role'=>$user['role'] ?? 'operator'
    ];
    return true;
}

function logout_user(): void {
    unset($_SESSION['user'],$_SESSION['room_access'],$_SESSION['room_context']);
    session_regenerate_id(true);
}

function row(string $sql, array $params = []): ?array {
    $s = db()->prepare($sql); $s->execute($params); $r = $s->fetch(); return $r ?: null;
}
function rows(string $sql, array $params = []): array {
    $s = db()->prepare($sql); $s->execute($params); return $s->fetchAll();
}
function exec_sql(string $sql, array $params = []): bool {
    $s = db()->prepare($sql); return $s->execute($params);
}

function db_column_exists(string $table, string $column): bool {
    $r = row("SELECT COUNT(*) n FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? AND COLUMN_NAME=?", [$table,$column]);
    return (int)($r['n'] ?? 0) > 0;
}

function db_index_exists(string $table, string $index): bool {
    $r = row("SELECT COUNT(*) n FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? AND INDEX_NAME=?", [$table,$index]);
    return (int)($r['n'] ?? 0) > 0;
}

function db_constraint_exists(string $table, string $constraint): bool {
    $r = row("SELECT COUNT(*) n FROM information_schema.TABLE_CONSTRAINTS WHERE CONSTRAINT_SCHEMA=DATABASE() AND TABLE_NAME=? AND CONSTRAINT_NAME=?", [$table,$constraint]);
    return (int)($r['n'] ?? 0) > 0;
}

/**
 * Vincula cada cuenta de acceso con un unico participante ARQWAR.
 * Se conserva la tabla participants para no romper equipos, chat, puntos ni historial.
 */
function ensure_account_participant_schema(): void {
    static $done=false;
    if($done) return;

    if(!db_column_exists('participants','user_id')) {
        db()->exec("ALTER TABLE participants ADD COLUMN user_id INT NULL AFTER id");
    }

    // Vincula participantes antiguos cuyo alias coincide con el usuario.
    db()->exec("UPDATE participants p JOIN app_users u ON u.username=p.alias SET p.user_id=u.id WHERE p.user_id IS NULL");

    // Crea el participante de las cuentas activas que todavía no tengan uno.
    $users=rows("SELECT u.id,u.username,u.display_name FROM app_users u LEFT JOIN participants p ON p.user_id=u.id WHERE u.is_active=1 AND p.id IS NULL ORDER BY u.id");
    foreach($users as $u){
        $uid=(int)$u['id'];
        $alias=trim((string)$u['username']);
        $name=trim((string)$u['display_name']);
        if($alias==='') continue;
        $p=row('SELECT id,user_id FROM participants WHERE alias=? LIMIT 1',[$alias]);
        if($p){
            if($p['user_id']===null || $p['user_id']==='') {
                exec_sql('UPDATE participants SET user_id=?,full_name=? WHERE id=?',[$uid,$name ?: null,(int)$p['id']]);
            }
            continue;
        }
        exec_sql('INSERT INTO participants(user_id,alias,full_name,specialty) VALUES(?,?,?,?)',[$uid,$alias,$name ?: null,'Usuario ARQWAR']);
    }

    if(!db_index_exists('participants','uq_participant_user')) {
        db()->exec("ALTER TABLE participants ADD UNIQUE KEY uq_participant_user (user_id)");
    }
    if(!db_constraint_exists('participants','fk_participant_user')) {
        db()->exec("ALTER TABLE participants ADD CONSTRAINT fk_participant_user FOREIGN KEY (user_id) REFERENCES app_users(id) ON DELETE SET NULL");
    }
    $done=true;
}

function participant_for_user(int $userId, bool $create=true, ?array $user=null): ?array {
    if($userId<=0) return null;
    ensure_account_participant_schema();

    $p=row('SELECT * FROM participants WHERE user_id=? LIMIT 1',[$userId]);
    if($p){
        if($user && (string)($p['full_name']??'')!==(string)($user['display_name']??'')) {
            exec_sql('UPDATE participants SET full_name=? WHERE id=?',[$user['display_name']??null,(int)$p['id']]);
            $p=row('SELECT * FROM participants WHERE id=? LIMIT 1',[(int)$p['id']]);
        }
        return $p;
    }
    if(!$create) return null;

    $user=$user ?: row('SELECT id,username,display_name FROM app_users WHERE id=? AND is_active=1 LIMIT 1',[$userId]);
    if(!$user) return null;
    $alias=trim((string)$user['username']);
    $name=trim((string)$user['display_name']);
    if($alias==='') return null;

    $byAlias=row('SELECT * FROM participants WHERE alias=? LIMIT 1',[$alias]);
    if($byAlias){
        if($byAlias['user_id']===null || $byAlias['user_id']==='') {
            exec_sql('UPDATE participants SET user_id=?,full_name=? WHERE id=?',[$userId,$name ?: null,(int)$byAlias['id']]);
            return row('SELECT * FROM participants WHERE id=? LIMIT 1',[(int)$byAlias['id']]);
        }
        if((int)$byAlias['user_id']===$userId) return $byAlias;
        return null;
    }

    try {
        exec_sql('INSERT INTO participants(user_id,alias,full_name,specialty) VALUES(?,?,?,?)',[$userId,$alias,$name ?: null,'Usuario ARQWAR']);
    } catch(Throwable $e) {
        $p=row('SELECT * FROM participants WHERE user_id=? LIMIT 1',[$userId]);
        if($p) return $p;
        throw $e;
    }
    return row('SELECT * FROM participants WHERE user_id=? LIMIT 1',[$userId]);
}

function ensure_individual_schema(): void {
    ensure_account_participant_schema();
    static $done=false;
    if($done) return;

    // Modo de batalla: por equipos (actual) o individual.
    if(!db_column_exists('games','mode')) {
        db()->exec("ALTER TABLE games ADD COLUMN mode ENUM('teams','individual') NOT NULL DEFAULT 'teams' AFTER status");
    }

    // En modo individual cada fila de teams representa a un jugador.
    if(!db_column_exists('teams','owner_user_id')) {
        db()->exec("ALTER TABLE teams ADD COLUMN owner_user_id INT NULL AFTER profile_id");
    }
    if(!db_column_exists('teams','participant_id')) {
        db()->exec("ALTER TABLE teams ADD COLUMN participant_id INT NULL AFTER owner_user_id");
    }
    if(!db_index_exists('teams','uq_game_owner_user')) {
        db()->exec("ALTER TABLE teams ADD UNIQUE KEY uq_game_owner_user (game_id,owner_user_id)");
    }
    if(!db_index_exists('teams','idx_game_participant')) {
        db()->exec("ALTER TABLE teams ADD KEY idx_game_participant (game_id,participant_id)");
    }

    $done=true;
}

function game_is_individual(int $gameId): bool {
    ensure_individual_schema();
    $g=row('SELECT mode FROM games WHERE id=? LIMIT 1',[$gameId]);
    return ($g['mode'] ?? 'teams') === 'individual';
}

function ensure_individual_player(int $gameId, ?int $userId=null): ?array {
    ensure_individual_schema();
    $u=current_user();
    $uid=$userId ?? (int)($u['id'] ?? 0);
    if(!$uid) return null;
    if(!game_is_individual($gameId)) return null;

    $existing=row('SELECT * FROM teams WHERE game_id=? AND owner_user_id=? LIMIT 1',[$gameId,$uid]);
    if($existing) return $existing;

    $user=$u && (int)($u['id']??0)===$uid ? $u : row('SELECT id,username,display_name FROM app_users WHERE id=? AND is_active=1 LIMIT 1',[$uid]);
    if(!$user) return null;
    $participant=current_participant(true);
    if(!$participant) return null;

    $max=row('SELECT COALESCE(MAX(slot_no),0) n FROM teams WHERE game_id=?',[$gameId]);
    $slot=(int)($max['n']??0)+1;
    $themes=['blue','red','gold','green','purple','orange','cyan','pink','indigo','teal','lime','slate'];
    $theme=$themes[($slot-1)%count($themes)];
    $name=trim((string)($user['display_name']??$user['username']??$participant['full_name']??$participant['alias']));
    if($name==='') $name=(string)$participant['alias'];

    try {
        exec_sql('INSERT INTO teams(game_id,profile_id,owner_user_id,participant_id,name,theme_key,slot_no) VALUES(?,NULL,?,?,?,?,?)',[$gameId,$uid,(int)$participant['id'],$name,$theme,$slot]);
    } catch(Throwable $e) {
        // Otro request pudo crear al jugador exactamente al mismo tiempo.
        $existing=row('SELECT * FROM teams WHERE game_id=? AND owner_user_id=? LIMIT 1',[$gameId,$uid]);
        if($existing) return $existing;
        throw $e;
    }
    $player=row('SELECT * FROM teams WHERE game_id=? AND owner_user_id=? LIMIT 1',[$gameId,$uid]);
    if($player) log_game($gameId,'player_joined',$name.' se incorporó a la batalla individual',(int)$player['id'],['user_id'=>$uid,'participant_id'=>(int)$participant['id']]);
    return $player;
}

function current_participant(bool $create = true): ?array {
    $u=current_user();
    if(!$u || empty($u['id'])) return null;
    return participant_for_user((int)$u['id'],$create,$u);
}

function ensure_room_schema(): void {
    ensure_individual_schema();
    static $done=false;
    if($done) return;
    db()->exec("CREATE TABLE IF NOT EXISTS game_rooms (
        id INT AUTO_INCREMENT PRIMARY KEY,
        game_id INT NOT NULL UNIQUE,
        name VARCHAR(120) NOT NULL,
        password_hash VARCHAR(255) NULL,
        is_private TINYINT(1) NOT NULL DEFAULT 0,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        created_by INT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (game_id) REFERENCES games(id) ON DELETE CASCADE,
        FOREIGN KEY (created_by) REFERENCES app_users(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    db()->exec("CREATE TABLE IF NOT EXISTS room_players (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        room_id INT NOT NULL,
        app_user_id INT NOT NULL,
        participant_id INT NULL,
        joined_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        last_seen DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_room_user (room_id,app_user_id),
        INDEX idx_room_seen (room_id,last_seen),
        FOREIGN KEY (room_id) REFERENCES game_rooms(id) ON DELETE CASCADE,
        FOREIGN KEY (app_user_id) REFERENCES app_users(id) ON DELETE CASCADE,
        FOREIGN KEY (participant_id) REFERENCES participants(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $done=true;
}

function get_room(int $gameId): ?array {
    ensure_room_schema();
    return row("SELECT r.*,g.name game_name,g.status game_status,g.max_rounds,g.current_round,u.display_name gm_name
        FROM game_rooms r JOIN games g ON g.id=r.game_id
        LEFT JOIN app_users u ON u.id=r.created_by
        WHERE r.game_id=? AND r.is_active=1 LIMIT 1",[$gameId]);
}

function user_game_team(int $gameId): ?array {
    $p=current_participant(false);
    if(!$p) return null;
    return row("SELECT t.*,tm.participant_id FROM teams t JOIN team_members tm ON tm.team_profile_id=t.profile_id
        WHERE t.game_id=? AND tm.participant_id=? ORDER BY t.slot_no LIMIT 1",[$gameId,(int)$p['id']]);
}

function room_can_enter(int $gameId): bool {
    if(is_admin()) return true;
    $room=get_room($gameId);
    if(!$room) return false;
    if((int)$room['created_by']===(int)(current_user()['id']??0)) return true;
    if(game_is_individual($gameId)) return true;
    return (bool)user_game_team($gameId);
}

function room_session_open(int $roomId): bool {
    $u=current_user();
    return $u && !empty($_SESSION['room_access'][$roomId]);
}

function room_grant_access(int $roomId, string $role='player'): void {
    $_SESSION['room_access'][$roomId]=['role'=>$role,'at'=>time()];
}

function room_access_role(int $roomId): ?string {
    return $_SESSION['room_access'][$roomId]['role']??null;
}

function room_access_for_game(int $gameId): ?array {
    $room=get_room($gameId);
    if(!$room || !room_session_open((int)$room['id'])) return null;
    return ['room'=>$room,'role'=>room_access_role((int)$room['id'])??'player'];
}

function room_player_team_id(int $gameId): ?int {
    if(game_is_individual($gameId)) {
        $player=ensure_individual_player($gameId);
        return $player ? (int)$player['id'] : null;
    }
    $team=user_game_team($gameId);
    return $team ? (int)$team['id'] : null;
}

function game_creator_required(int $gameId): void {
    $u=current_user();
    if(!$u) throw new RuntimeException('Sesión requerida.');
    ensure_room_schema();
    $room=row('SELECT created_by FROM game_rooms WHERE game_id=? AND is_active=1 LIMIT 1',[$gameId]);
    if(!$room || !(int)($room['created_by']??0) || (int)$room['created_by']!==(int)$u['id']) {
        throw new RuntimeException('Solo el creador de la partida puede iniciar o finalizarla.');
    }
}

function room_restrict_action(int $gameId, string $action, ?int $teamId=null): void {
    if(is_admin()) return;

    $u=current_user();
    $ctx=room_access_for_game($gameId);
    $room=$ctx['room']??get_room($gameId);
    $individual=game_is_individual($gameId);
    $isCreator=$room && (int)($room['created_by']??0)===(int)($u['id']??0);

    if($individual){
        // En batalla individual cada usuario solo puede operar su propia casilla.
        // El creador conserva permisos de Game Master para iniciar/finalizar,
        // pero no puede lanzar dados ni gestionar cartas de otros jugadores.
        if(in_array($action,['play_card','roll_die','remove_card','reset_team'],true)){
            if(!$ctx && !$isCreator){
                throw new RuntimeException('Debes ingresar a la sala para operar tu casilla.');
            }
            $own=ensure_individual_player($gameId,(int)($u['id']??0));
            if(!$own || ($teamId!==null && (int)$own['id']!==$teamId)){
                throw new RuntimeException('Solo puedes operar tu propia casilla.');
            }
            return;
        }

        if($ctx && ($ctx['role']??'')==='player'){
            throw new RuntimeException('Esta accion solo puede ejecutarla el Game Master.');
        }
        return;
    }

    if(is_array($ctx) && ($ctx['role']??'')==='player'){
        if(!in_array($action,['play_card','roll_die','remove_card'],true)){
            throw new RuntimeException('Esta accion solo puede ejecutarla el Game Master.');
        }
        $own=room_player_team_id($gameId);
        if(!$own || ($teamId!==null && $own!==$teamId)){
            throw new RuntimeException('Solo puedes operar el equipo al que perteneces.');
        }
    }
}

function room_mark_player(int $roomId): void {
    $u=current_user();
    if(!$u) return;
    $room=row('SELECT * FROM game_rooms WHERE id=? AND is_active=1 LIMIT 1',[$roomId]);
    if(!$room) return;
    // En batalla individual tambien se registra al creador como jugador,
    // para que tenga su propia casilla sin perder sus permisos de Game Master.
    $p=current_participant(false);
    if(game_is_individual((int)$room['game_id'])) {
        $p=current_participant(true);
        ensure_individual_player((int)$room['game_id'],(int)$u['id']);
    }
    exec_sql("INSERT INTO room_players(room_id,app_user_id,participant_id,last_seen) VALUES(?,?,?,NOW())
        ON DUPLICATE KEY UPDATE participant_id=VALUES(participant_id),last_seen=NOW()",
        [$roomId,(int)$u['id'],$p?(int)$p['id']:null]);
}

function room_active_player_count(int $roomId): int {
    ensure_room_schema();
    $r=row("SELECT COUNT(*) n FROM room_players WHERE room_id=? AND last_seen>=DATE_SUB(NOW(),INTERVAL 90 SECOND)",[$roomId]);
    return (int)($r['n']??0);
}

function log_game(int $gameId, string $type, string $message, ?int $teamId = null, array $payload = []): void {
    exec_sql('INSERT INTO game_logs(game_id,team_id,type,message,payload_json) VALUES(?,?,?,?,?)', [
        $gameId, $teamId, $type, $message, json_encode($payload, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)
    ]);
}

function get_game(int $gameId): ?array {
    return row('SELECT g.*, s.name scenario_name, s.description scenario_description, s.budget_monthly scenario_budget,
        s.min_security, s.min_availability, s.min_scalability, s.min_performance, s.min_reliability, s.min_devops,
        s.sla_target, s.client_name, s.user_load, s.requirements_json, s.area scenario_area, s.focus_json
        FROM games g JOIN scenarios s ON s.id=g.scenario_id WHERE g.id=?', [$gameId]);
}

function latest_game(): ?array {
    return row("SELECT id FROM games ORDER BY FIELD(status,'running','setup','finished'), id DESC LIMIT 1");
}

function metric_labels(): array {
    return [
        'security'=>'Seguridad', 'availability'=>'Disponibilidad', 'scalability'=>'Escalabilidad',
        'performance'=>'Performance', 'reliability'=>'Resiliencia', 'devops'=>'DevOps'
    ];
}

function scenario_focus(array $game): array {
    $focus=json_decode((string)($game['focus_json']??''),true);
    return is_array($focus) ? array_values(array_filter(array_map('strval',$focus))) : [];
}

function category_area_affinity(string $category, string $area): int {
    $map=[
        'Desarrollo'=>['App Platform','Container','Orchestration','Serverless','Network','Database','Cache','CI/CD','Artifact','Observability','Integration','Framework','Language','Testing','Source Control','Build','Package'],
        'Data'=>['Database','Storage','Messaging','Analytics','BI','Data Integration','Data Quality','Observability','Search'],
        'DevOps'=>['CI/CD','IaC','Artifact','Container','Orchestration','Observability','Security','Source Control','Build','Package','Testing'],
        'MLOps'=>['MLOps','AI','Vector DB','Storage','Data Integration','Observability','Container','Orchestration'],
        'FinOps'=>['FinOps','Observability','Compute','Storage','Orchestration','IaC'],
        'RPA'=>['RPA','Integration','AI','Identity','Messaging','Database','Observability'],
        'Cybersecurity'=>['Security','Identity','Network','Observability','Storage','CI/CD'],
        'Cloud & Infra'=>['Compute','Network','Storage','Database','App Platform','Container','Orchestration','Serverless','Security','IaC','Edge','Virtualization','Operating System'],
        'AI & GenAI'=>['AI','MLOps','Vector DB','Search','Database','Cache','Identity','Security','Observability'],
        'Observability & SRE'=>['Observability','CI/CD','Messaging','Network','FinOps','Security'],
    ];
    if(in_array($category,$map[$area]??[],true)) return 1;
    return 0;
}

function card_stats(array $card): array {
    return [
        'security'=>(int)$card['security'], 'availability'=>(int)$card['availability'],
        'scalability'=>(int)$card['scalability'], 'performance'=>(int)$card['performance'],
        'reliability'=>(int)$card['reliability'], 'devops'=>(int)$card['devops']
    ];
}

function add_stats(array &$base, array $delta): void {
    foreach (array_keys(metric_labels()) as $k) {
        $base[$k] = ($base[$k] ?? 0) + (int)($delta[$k] ?? 0);
    }
}

function combo_matches(array $requiredCodes, array $counts): bool {
    $need = array_count_values($requiredCodes);
    foreach ($need as $code=>$n) if (($counts[$code] ?? 0) < $n) return false;
    return true;
}

function score_breakdown(array $stats, int $finops, int $compliance, int $decisionAdjustment = 0): array {
    return [
        'security'=>(int)round($stats['security']*1.5),
        'availability'=>(int)round($stats['availability']*1.5),
        'scalability'=>(int)round($stats['scalability']*1.5),
        'performance'=>(int)round($stats['performance']*1.5),
        'reliability'=>(int)round($stats['reliability']*1.5),
        'devops'=>(int)$stats['devops'],
        'finops'=>$finops,
        'compliance'=>$compliance,
        'decision'=>$decisionAdjustment,
    ];
}

function calculate_team_state(int $gameId, int $teamId): array {
    $cfg = arqwar_config();
    $game = get_game($gameId);
    if (!$game) throw new RuntimeException('Partida inexistente');
    $team = row('SELECT * FROM teams WHERE id=? AND game_id=?', [$teamId,$gameId]);
    if (!$team) throw new RuntimeException('Equipo inexistente');

    $cards = rows("SELECT tgc.id placement_id, tgc.source, tgc.played_round, tgc.decision_points, tgc.pronunciation_correct, tgc.pronunciation_bonus, tgc.individual_points, tgc.played_at, c.*, p.alias responder_alias
        FROM team_game_cards tgc JOIN cards c ON c.id=tgc.card_id LEFT JOIN participants p ON p.id=tgc.responder_participant_id
        WHERE tgc.game_id=? AND tgc.team_id=? AND tgc.status='deployed' ORDER BY tgc.id", [$gameId,$teamId]);

    $stats = $cfg['base_stats'];
    $cost = 0; $counts = []; $providers = []; $decisionAdjustment = 0;
    foreach ($cards as $c) {
        add_stats($stats, card_stats($c));
        $cost += (float)$c['monthly_cost'];
        $decisionAdjustment += (int)($c['decision_points'] ?? 0);
        $counts[$c['code']] = ($counts[$c['code']] ?? 0) + 1;
        if (!empty($c['provider']) && $c['provider'] !== 'Agnostic') $providers[$c['provider']] = true;
    }

    $activeCombos = [];
    foreach (rows('SELECT * FROM combos WHERE is_active=1 ORDER BY priority DESC, id') as $combo) {
        $required = json_decode($combo['required_codes_json'], true) ?: [];
        if (!combo_matches($required, $counts)) continue;
        $bonus = json_decode($combo['bonus_json'], true) ?: [];
        add_stats($stats, $bonus);
        $cost += (float)($combo['cost_delta'] ?? 0);
        $activeCombos[] = [
            'id'=>(int)$combo['id'], 'name'=>$combo['name'], 'description'=>$combo['description'],
            'bonus'=>$bonus, 'cost_delta'=>(float)$combo['cost_delta']
        ];
    }

    if (count($providers) >= 2) {
        $stats['reliability'] += 5;
        $stats['availability'] += 3;
        $cost += 120;
        $activeCombos[] = ['id'=>0,'name'=>'MULTICLOUD','description'=>'Mayor resiliencia con sobrecosto operativo.','bonus'=>['reliability'=>5,'availability'=>3],'cost_delta'=>120];
    }

    foreach ($stats as $k=>$v) $stats[$k] = max(0, min(100, (int)$v));

    $budget = (float)$game['scenario_budget'];
    $ratio = $budget > 0 ? $cost / $budget : 1;
    if ($ratio <= .75) $finops = 100;
    elseif ($ratio <= 1) $finops = (int)round(100 - (($ratio-.75)/.25)*40);
    else $finops = max(0, (int)round(60 - (($ratio-1)*120)));

    $mins = [
        'security'=>(int)$game['min_security'], 'availability'=>(int)$game['min_availability'],
        'scalability'=>(int)$game['min_scalability'], 'performance'=>(int)$game['min_performance'],
        'reliability'=>(int)$game['min_reliability'], 'devops'=>(int)$game['min_devops'],
    ];
    $checks = [];
    foreach ($mins as $k=>$min) $checks[$k] = $stats[$k] >= $min;
    $categories = array_column($cards, 'category');
    $hasCompute = (bool)array_intersect($categories, ['Compute','Container','Orchestration','Serverless','App Platform']);
    $hasData = (bool)array_intersect($categories, ['Database','Storage','Vector DB']);
    $checks['foundation'] = $hasCompute && $hasData;
    $checks['budget'] = $cost <= $budget;
    $checks['sla'] = (float)$team['sla'] >= (float)$game['sla_target'];
    $passed = count(array_filter($checks));
    $compliance = (int)round(($passed / count($checks)) * 50);
    $breakdown = score_breakdown($stats, $finops, $compliance, $decisionAdjustment);
    $score = max(0, min(1000, array_sum($breakdown)));
    $contractOk = !in_array(false, $checks, true) && (int)$team['reputation'] > 0;

    $currentRound=(int)$game['current_round'];
    $playsRow=row('SELECT COUNT(*) n FROM team_game_cards WHERE game_id=? AND team_id=? AND played_round=?',[$gameId,$teamId,$currentRound]);
    $diceRoll=$currentRound>0 ? row('SELECT * FROM dice_rolls WHERE game_id=? AND team_id=? AND round_no=?',[$gameId,$teamId,$currentRound]) : null;
    $deploymentLimit=2 + (($diceRoll && (int)$diceRoll['won_extra_card']===1) ? 1 : 0);
    $playsThisRound=(int)($playsRow['n']??0);

    $members = [];
    if (!empty($team['profile_id'])) {
        $members = rows('SELECT tm.id,tm.participant_id,COALESCE(p.alias,tm.name) name,COALESCE(p.specialty,tm.role) role,p.full_name,p.avatar_emoji FROM team_members tm LEFT JOIN participants p ON p.id=tm.participant_id WHERE tm.team_profile_id=? ORDER BY COALESCE(p.alias,tm.name)', [(int)$team['profile_id']]);
    } elseif (!empty($team['participant_id'])) {
        $members = rows('SELECT p.id participant_id,p.alias name,p.specialty role,p.full_name,p.avatar_emoji FROM participants p WHERE p.id=? LIMIT 1',[(int)$team['participant_id']]);
    }

    return [
        'team'=>$team, 'members'=>$members, 'cards'=>$cards, 'stats'=>$stats, 'cost'=>round($cost,2), 'budget'=>$budget,
        'budget_ratio'=>$budget > 0 ? round($cost/$budget,3) : 0, 'finops'=>$finops,
        'combos'=>$activeCombos, 'checks'=>$checks, 'score'=>$score, 'score_breakdown'=>$breakdown, 'decision_adjustment'=>$decisionAdjustment,
        'contract_ok'=>$contractOk, 'providers'=>array_keys($providers),
        'plays_this_round'=>$playsThisRound, 'deployment_limit'=>$deploymentLimit,
        'deployments_remaining'=>max(0,$deploymentLimit-$playsThisRound), 'dice_roll'=>$diceRoll,
        'dice_can_roll'=>$game['status']==='running' && $currentRound>0 && !$diceRoll,
    ];
}

function get_active_incident(int $gameId): ?array {
    $r = row('SELECT i.*, g.active_incident_started_at FROM games g JOIN incidents i ON i.id=g.active_incident_id WHERE g.id=? AND g.active_incident_id IS NOT NULL', [$gameId]);
    if (!$r) return null;
    $r['requirements'] = json_decode($r['requirements_json'], true) ?: [];
    return $r;
}

function incident_team_success(array $teamState, array $incident): bool {
    foreach ($incident['requirements'] as $k=>$v) {
        if (($teamState['stats'][$k] ?? 0) < (int)$v) return false;
    }
    return true;
}

function evaluate_card_choice(array $before, array $after, array $card, array $game, ?array $incident): array {
    $labels=metric_labels();
    $metricDeltas=[]; $benefits=[]; $warnings=[]; $priorityHits=[];
    $scenarioGain=0.0; $incidentGain=0.0;

    foreach ($labels as $k=>$label) {
        $delta=(int)$after['stats'][$k]-(int)$before['stats'][$k];
        $metricDeltas[$k]=$delta;
        if ($delta>0) $benefits[]=$label.' +'.$delta;

        $min=(int)$game['min_'.$k];
        $gapBefore=max(0,$min-(int)$before['stats'][$k]);
        $gapAfter=max(0,$min-(int)$after['stats'][$k]);
        $gain=max(0,$gapBefore-$gapAfter);
        if ($gain>0) { $scenarioGain += $gain; $priorityHits[]=$label; }

        if ($incident && isset($incident['requirements'][$k])) {
            $need=(int)$incident['requirements'][$k];
            $ib=max(0,$need-(int)$before['stats'][$k]);
            $ia=max(0,$need-(int)$after['stats'][$k]);
            $ig=max(0,$ib-$ia);
            if ($ig>0) { $incidentGain += $ig; $priorityHits[]='Incidente: '.$label; }
        }
    }

    $beforeCombos=array_column($before['combos'],'name');
    $afterCombos=array_column($after['combos'],'name');
    $newCombos=array_values(array_diff($afterCombos,$beforeCombos));
    foreach($newCombos as $name) $benefits[]='Combo activado: '.$name;

    $newChecks=[];
    foreach($after['checks'] as $k=>$ok){
        if($ok && empty($before['checks'][$k])) $newChecks[]=$k;
    }
    if(in_array('foundation',$newChecks,true)) $benefits[]='Completa la base de la arquitectura (cómputo + datos)';
    if(in_array('budget',$newChecks,true)) $benefits[]='Vuelve a cumplir el presupuesto';

    $incidentBefore=$incident ? incident_team_success($before,$incident) : null;
    $incidentAfter=$incident ? incident_team_success($after,$incident) : null;
    if($incident && !$incidentBefore && $incidentAfter) $benefits[]='Resuelve el incidente activo: '.$incident['name'];
    elseif($incident && $incidentGain>0 && !$incidentAfter) $warnings[]='Ayuda contra el incidente activo, pero todavía no alcanza todos sus mínimos';

    $rawScoreDelta=(int)$after['score']-(int)$before['score'];
    $costDelta=round((float)$after['cost']-(float)$before['cost'],2);
    $budget=(float)$after['budget'];
    $budgetExceeded=(float)$after['cost']>$budget;
    if($budgetExceeded) $warnings[]='Presupuesto excedido por $'.number_format((float)$after['cost']-$budget,0,'.',',');
    elseif($after['budget_ratio']>=0.90) $warnings[]='Queda menos del 10% del presupuesto disponible';

    $cardCostShare=$budget>0 && $costDelta>0 ? $costDelta/$budget : 0;
    if($cardCostShare>=0.35) $warnings[]='Esta jugada consume aproximadamente '.round($cardCostShare*100).'% del presupuesto total del escenario';

    $scenarioText=strtolower((string)($game['scenario_name']??'').' '.(string)($game['scenario_description']??'').' '.(string)($game['requirements_json']??''));
    $simplicityScenario=str_contains($scenarioText,'simplicidad') || str_contains($scenarioText,'sobreingenier') || str_contains($scenarioText,'mvp');

    $categoryKeywords = [
        'Security'=>['seguridad','mfa','secret','credencial','ataque','auditor','cifrado'],
        'Observability'=>['observabilidad','monitor','telemetr','trazabilidad','diagnost'],
        'CI/CD'=>['ci/cd','desplieg','pipeline','automatiza'],
        'IaC'=>['infraestructura como código','terraform','automatiza'],
        'Edge'=>['cdn','contenido','tráfico','latencia','streaming'],
        'Network'=>['balance','tráfico','api','red','vpn'],
        'Cache'=>['cache','latencia','performance','tráfico','streaming'],
        'Database'=>['base de datos','datos','transaccional','replic'],
        'Storage'=>['backup','dr','recupera','contenido','storage'],
        'AI'=>['ia','modelo','asistente','inteligencia artificial'],
        'Compute'=>['cómputo','compute','servidor','legacy'],
        'Container'=>['contenedor','moderniza','cloud native'],
        'Orchestration'=>['escalabilidad','contenedor','cloud native'],
        'Serverless'=>['serverless','eventos','escalabilidad'],
        'Messaging'=>['eventos','mensaj','desacopl','cola','stream'],
        'App Platform'=>['aplicación','app','spring','paas','web','api','moderniza'],
        'Identity'=>['identidad','mfa','acceso','usuario','zero trust'],
        'Artifact'=>['artefact','registry','imagen','paquete','release'],
        'Analytics'=>['analítica','analytics','warehouse','bi','lakehouse','spark'],
        'Data Integration'=>['etl','elt','pipeline','ingesta','cdc','integración','streaming'],
        'Data Quality'=>['calidad','lineage','linaje','catálogo','schema','gobierno'],
        'BI'=>['bi','dashboard','visualización','report','analítica','looker'],
        'Framework'=>['framework','desarrollo','aplicación','backend','frontend','api'],
        'Language'=>['lenguaje','desarrollo','backend','frontend','programación'],
        'Testing'=>['prueba','testing','qa','calidad','carga','performance','seguridad'],
        'Source Control'=>['git','repositorio','versionado','código','branch'],
        'Build'=>['build','compilación','dependencia','pipeline','release'],
        'Package'=>['paquete','artefacto','dependencia','registry','release'],
        'Virtualization'=>['virtualización','vm','on-premise','infraestructura','servidor'],
        'Operating System'=>['linux','windows','servidor','sistema operativo','on-premise'],
        'MLOps'=>['mlops','modelo','reentren','drift','registry','feature'],
        'FinOps'=>['finops','costo','coste','presupuesto','rightsizing','gasto'],
        'RPA'=>['rpa','robot','automatización','desktop','backoffice'],
        'Integration'=>['integración','workflow','api','orquestación','erp'],
        'Vector DB'=>['vector','embedding','rag','semántica'],
        'Search'=>['búsqueda','search','rag','índice'],
    ];
    $keywordHit=false;
    foreach($categoryKeywords[$card['category']] ?? [] as $kw){
        if(str_contains($scenarioText,$kw)){ $keywordHit=true; break; }
    }
    if($keywordHit) $benefits[]='La categoría '.$card['category'].' tiene relación directa con la problemática descrita';

    $focus=scenario_focus($game);
    $focusHit=in_array((string)$card['category'],$focus,true);
    if($focusHit) $benefits[]='La carta pertenece a una categoría prioritaria de esta casuística: '.$card['category'];
    $areaAffinity=category_area_affinity((string)$card['category'],(string)($game['scenario_area']??''));
    if($areaAffinity) $benefits[]='Tecnología alineada con el área '.$game['scenario_area'];

    if((int)$card['complexity']>=8 && $scenarioGain<=0 && $incidentGain<=0 && !$newCombos) {
        $warnings[]='Complejidad alta ('.(int)$card['complexity'].'/10) sin cerrar una brecha prioritaria';
    }
    if($simplicityScenario && (int)$card['complexity']>=7) $warnings[]='El escenario prioriza simplicidad; esta carta aumenta mucho la complejidad operativa';

    $foundationHit=in_array('foundation',$newChecks,true);
    $directSignal=$scenarioGain>0 || $incidentGain>0 || $newCombos || $foundationHit || $keywordHit || $focusHit || $areaAffinity || ($incident && !$incidentBefore && $incidentAfter);
    if(!$directSignal) $warnings[]='La carta es demasiado genérica o no tiene relación suficiente con la problemática y las brechas actuales';

    // Relevancia contextual 0..100. No depende solo de que la carta tenga estadísticas positivas.
    $relevance = 0;
    $relevance += min(45, (int)round($scenarioGain*2.2));
    $relevance += min(30, (int)round($incidentGain*3.0));
    $relevance += min(20, count($newCombos)*20);
    if($foundationHit) $relevance += 18;
    if($keywordHit) $relevance += 16;
    if($focusHit) $relevance += 24;
    if($areaAffinity) $relevance += 10;
    if($incident && !$incidentBefore && $incidentAfter) $relevance += 25;
    $metricCheckHits=array_values(array_intersect($newChecks,array_keys($labels)));
    if(!$keywordHit && !$focusHit && !$areaAffinity && $incidentGain<=0 && !$newCombos && !$foundationHit && !$metricCheckHits){
        // Una carta que solo sube números, pero no cruza un mínimo ni responde a la problemática,
        // se considera básica y no puede obtener una relevancia alta.
        $relevance=min($relevance,24);
    }
    if($simplicityScenario && (int)$card['complexity']>=7) $relevance -= 18;
    if($budgetExceeded) $relevance -= 20;
    if($cardCostShare>=0.50) $relevance -= 15;
    $relevance=max(0,min(100,$relevance));

    // Penalización de decisión. Una tecnología puede sumar métricas, pero si no responde al caso,
    // ARQWAR neutraliza esa ganancia o incluso quita puntos.
    $decisionAdjustment=0;
    if($relevance<=10){
        $decisionAdjustment = -max(10, $rawScoreDelta + 10);
        $warnings[]='Penalización: elección sin relación práctica con la necesidad actual';
    } elseif($relevance<=25){
        $decisionAdjustment = -max(0, $rawScoreDelta);
        $warnings[]='Penalización: elección demasiado básica; su ganancia técnica se neutraliza';
    } elseif($relevance<=40 && ((int)$card['complexity']>=7 || $cardCostShare>=0.25)){
        $decisionAdjustment = -min(15, max(5, (int)round(max(0,$rawScoreDelta)*0.45)));
        $warnings[]='Penalización parcial por costo/complejidad frente al beneficio contextual';
    }
    if(!$areaAffinity && !$focusHit && !$keywordHit && $scenarioGain<=0 && $incidentGain<=0 && !$newCombos && !$foundationHit){
        $decisionAdjustment -= 8;
        $warnings[]='La carta no está alineada con el área ni con las categorías prioritarias de esta casuística';
    }
    if($budgetExceeded) $decisionAdjustment -= 8;
    if($simplicityScenario && (int)$card['complexity']>=8 && !$newCombos) $decisionAdjustment -= 8;
    $decisionAdjustment=max(-250,min(0,$decisionAdjustment));

    $projectedDelta=$rawScoreDelta+$decisionAdjustment;
    if($projectedDelta<0) $warnings[]='Esta elección reducirá el puntaje acumulado del equipo';
    elseif($projectedDelta===0) $warnings[]='Esta elección no otorgará puntos netos';

    $excellentSignal=($incident && !$incidentBefore && $incidentAfter) || count($newCombos)>0 || count($newChecks)>=2;
    if($relevance<=10 || $projectedDelta<0) { $rating='Elección sin relación'; $level='poor'; }
    elseif($relevance<=25 || $projectedDelta===0) { $rating='Elección demasiado básica'; $level='poor'; }
    elseif($relevance>=70 && $excellentSignal && !$budgetExceeded) { $rating='Excelente elección'; $level='excellent'; }
    elseif($relevance>=45 && !$budgetExceeded) { $rating='Buena elección'; $level='good'; }
    else { $rating='Elección situacional'; $level='neutral'; }

    $reasonParts=[];
    if($relevance<=10) $reasonParts[]='La tecnología elegida no ataca una brecha importante, no resuelve el incidente y no habilita un combo relevante.';
    elseif($relevance<=25) $reasonParts[]='La tecnología aporta algo técnicamente, pero es demasiado básica frente a la problemática actual.';
    if($priorityHits) $reasonParts[]='Ataca prioridades: '.implode(', ',array_values(array_unique($priorityHits))).'.';
    if($newCombos) $reasonParts[]='Desbloquea '.implode(', ',$newCombos).'.';
    if($incident && !$incidentBefore && $incidentAfter) $reasonParts[]='Con esta jugada el equipo ya cumple el incidente activo.';
    if($focusHit) $reasonParts[]='Coincide con una categoría prioritaria definida para la casuística.';
    elseif($areaAffinity) $reasonParts[]='Es coherente con el área tecnológica seleccionada, pero su valor depende de las brechas actuales.';
    elseif($keywordHit && !$priorityHits) $reasonParts[]='La categoría está alineada con la misión, aunque todavía no cierre una brecha mínima.';
    if(!empty($card['lifecycle_note'])) { $warnings[]='Ciclo de vida: '.$card['lifecycle_note']; }

    if(!$reasonParts) $reasonParts[]='El beneficio existe, pero debe compararse con costo, complejidad y prioridades pendientes.';

    return [
        'rating'=>$rating, 'level'=>$level, 'reason'=>implode(' ',$reasonParts),
        'relevance_score'=>$relevance, 'decision_adjustment'=>$decisionAdjustment,
        'raw_score_delta'=>$rawScoreDelta,
        'score_before'=>(int)$before['score'], 'score_after'=>(int)$after['score'], 'score_delta'=>$projectedDelta,
        'cost_before'=>(float)$before['cost'], 'cost_after'=>(float)$after['cost'], 'cost_delta'=>$costDelta,
        'metric_deltas'=>$metricDeltas, 'benefits'=>$benefits, 'warnings'=>$warnings,
        'new_combos'=>$newCombos, 'new_checks'=>$newChecks,
        'incident_name'=>$incident['name']??null, 'incident_before'=>$incidentBefore, 'incident_after'=>$incidentAfter,
        'card'=>['id'=>(int)$card['id'],'code'=>$card['code'],'name'=>$card['name'],'category'=>$card['category'],'provider'=>$card['provider'],'description'=>$card['description'],'lifecycle_note'=>$card['lifecycle_note']??null],
        'round'=>(int)$game['current_round'],
    ];
}

function resolve_active_incident(int $gameId): array {
    $incident = get_active_incident($gameId);
    if (!$incident) return [];
    $results=[];
    foreach (rows('SELECT id FROM teams WHERE game_id=? ORDER BY id',[$gameId]) as $t) {
        $state = calculate_team_state($gameId,(int)$t['id']);
        $success = incident_team_success($state,$incident);
        if ($success) {
            exec_sql('UPDATE teams SET reputation=LEAST(100,reputation+?) WHERE id=?', [(int)$incident['success_rep_bonus'],(int)$t['id']]);
            log_game($gameId,'incident_success',$state['team']['name'].' superó '.$incident['name'],(int)$t['id'],['incident_id'=>$incident['id']]);
        } else {
            exec_sql('UPDATE teams SET reputation=GREATEST(0,reputation-?), sla=GREATEST(0,sla-?) WHERE id=?', [
                (int)$incident['fail_rep_penalty'], (float)$incident['sla_penalty'], (int)$t['id']
            ]);
            log_game($gameId,'incident_fail',$state['team']['name'].' no superó '.$incident['name'],(int)$t['id'],['incident_id'=>$incident['id']]);
        }
        $results[]=['team_id'=>(int)$t['id'],'success'=>$success];
    }
    return $results;
}

function random_incident_id(?string $area = null): ?int {
    $map=[
        'Desarrollo'=>['traffic','performance','devops','integration','availability'],
        'Data'=>['data','messaging','storage','observability','finops'],
        'DevOps'=>['devops','observability','security','availability'],
        'MLOps'=>['mlops','ai','data','finops','observability'],
        'FinOps'=>['finops','availability','performance'],
        'RPA'=>['rpa','integration','security','availability'],
        'Cybersecurity'=>['security','governance','availability','network'],
        'Cloud & Infra'=>['availability','network','storage','traffic','database','security'],
        'AI & GenAI'=>['ai','mlops','finops','security','performance'],
        'Observability & SRE'=>['observability','performance','availability','devops','network'],
    ];
    $types=$map[$area??'']??[];
    if($types){
        $ph=implode(',',array_fill(0,count($types),'?'));
        $r=row("SELECT id FROM incidents WHERE is_active=1 AND incident_type IN ($ph) ORDER BY RAND() LIMIT 1",$types);
        if($r) return (int)$r['id'];
    }
    $r = row('SELECT id FROM incidents WHERE is_active=1 ORDER BY RAND() LIMIT 1');
    return $r ? (int)$r['id'] : null;
}

function latest_card_feedback(int $gameId, int $currentRound): ?array {
    $log=row("SELECT gl.*, t.name team_name FROM game_logs gl LEFT JOIN teams t ON t.id=gl.team_id WHERE gl.game_id=? AND gl.type='card_played' ORDER BY gl.id DESC LIMIT 1",[$gameId]);
    if(!$log) return null;
    $payload=json_decode($log['payload_json']??'',true)?:[];
    $feedback=$payload['feedback']??null;
    if(!$feedback || (int)($feedback['round']??-1)!==$currentRound) return null;
    return ['team_name'=>$log['team_name'],'created_at'=>$log['created_at'],'feedback'=>$feedback];
}

function latest_dice_roll(int $gameId, int $currentRound): ?array {
    return row('SELECT dr.*, t.name team_name FROM dice_rolls dr JOIN teams t ON t.id=dr.team_id WHERE dr.game_id=? AND dr.round_no=? ORDER BY dr.id DESC LIMIT 1',[$gameId,$currentRound]);
}

function game_state(int $gameId): array {
    $game = get_game($gameId);
    if (!$game) throw new RuntimeException('Partida inexistente');
    $teams=[];
    foreach(rows('SELECT id FROM teams WHERE game_id=? ORDER BY slot_no,id',[$gameId]) as $t) $teams[] = calculate_team_state($gameId,(int)$t['id']);

    // El orden visual es fijo por slot. El ranking cambia mediante una insignia, no moviendo paneles.
    $ranking=$teams;
    usort($ranking,function($a,$b){
        $cmp=(int)$b['score']<=>(int)$a['score'];
        if($cmp!==0) return $cmp;
        $cmp=(int)$b['team']['reputation']<=>(int)$a['team']['reputation'];
        if($cmp!==0) return $cmp;
        return (int)$a['team']['slot_no']<=>(int)$b['team']['slot_no'];
    });
    $rankById=[];$lastScore=null;$rank=0;$seen=0;
    foreach($ranking as $rt){
        $seen++; $score=(int)$rt['score'];
        if($lastScore===null || $score!==$lastScore) $rank=$seen;
        $rankById[(int)$rt['team']['id']]=$rank; $lastScore=$score;
    }
    foreach($teams as &$t) $t['current_rank']=$rankById[(int)$t['team']['id']]??0;
    unset($t);

    $logs = rows('SELECT gl.*, t.name team_name FROM game_logs gl LEFT JOIN teams t ON t.id=gl.team_id WHERE gl.game_id=? ORDER BY gl.id DESC LIMIT 12',[$gameId]);
    $round=(int)$game['current_round'];
    return [
        'game'=>$game,'teams'=>$teams,'incident'=>get_active_incident($gameId),'logs'=>$logs,
        'last_feedback'=>latest_card_feedback($gameId,$round),'latest_dice'=>latest_dice_roll($gameId,$round),
        'final_summary'=>$game['status']==='finished'?game_final_summary($gameId):null,
        'server_time'=>date('c')
    ];
}

function finalize_game_results(int $gameId): void {
    $teams=[];
    foreach(rows('SELECT id FROM teams WHERE game_id=? ORDER BY slot_no,id',[$gameId]) as $t){
        $state=calculate_team_state($gameId,(int)$t['id']);
        $teams[]=['id'=>(int)$t['id'],'score'=>(int)$state['score'],'rep'=>(int)$state['team']['reputation'],'slot'=>(int)$state['team']['slot_no']];
    }
    usort($teams,function($a,$b){
        $cmp=$b['score']<=>$a['score']; if($cmp!==0)return $cmp;
        $cmp=$b['rep']<=>$a['rep']; if($cmp!==0)return $cmp;
        return $a['slot']<=>$b['slot'];
    });
    $lastScore=null;$rank=0;$seen=0;$topScore=$teams[0]['score']??null;
    foreach($teams as $t){
        $seen++; if($lastScore===null || $t['score']!==$lastScore)$rank=$seen;
        $winner=($topScore!==null && $t['score']===$topScore)?1:0;
        exec_sql('UPDATE teams SET final_score=?, final_rank=?, is_winner=? WHERE id=?',[$t['score'],$rank,$winner,$t['id']]);
        $lastScore=$t['score'];
    }
}

function ensure_finished_results_backfilled(): void {
    foreach(rows("SELECT DISTINCT g.id FROM games g JOIN teams t ON t.game_id=g.id WHERE g.status='finished' AND t.final_score IS NULL") as $g){
        finalize_game_results((int)$g['id']);
    }
}

function leaderboard_rows(?string $area = null): array {
    ensure_finished_results_backfilled();
    $where="g.status='finished' AND t.final_score IS NOT NULL"; $params=[];
    if($area!==null && $area!==''){ $where.=' AND s.area=?'; $params[]=$area; }
    return rows("SELECT tp.id,tp.alias,tp.theme_key,
        COUNT(t.id) games_played,
        SUM(CASE WHEN t.is_winner=1 THEN 1 ELSE 0 END) wins,
        ROUND(AVG(t.final_score),1) avg_score,
        MAX(t.final_score) best_score,
        SUM(t.final_score) total_score
      FROM team_profiles tp
      JOIN teams t ON t.profile_id=tp.id
      JOIN games g ON g.id=t.game_id
      JOIN scenarios s ON s.id=g.scenario_id
      WHERE $where
      GROUP BY tp.id,tp.alias,tp.theme_key
      ORDER BY wins DESC, avg_score DESC, best_score DESC, games_played DESC, tp.alias",$params);
}

function leaderboard_areas(): array {
    return array_column(rows("SELECT DISTINCT s.area FROM games g JOIN scenarios s ON s.id=g.scenario_id WHERE g.status='finished' ORDER BY s.area"),'area');
}

function winner_history_rows(): array {
    ensure_finished_results_backfilled();
    return rows("SELECT g.id game_id,g.name game_name,g.ended_at,s.area,s.name scenario_name,
        t.name team_name,t.final_score,t.final_rank,tp.id profile_id
      FROM games g
      JOIN scenarios s ON s.id=g.scenario_id
      JOIN teams t ON t.game_id=g.id AND t.is_winner=1
      LEFT JOIN team_profiles tp ON tp.id=t.profile_id
      WHERE g.status='finished'
      ORDER BY g.ended_at DESC,g.id DESC,t.slot_no");
}

function finished_game_standings(): array {
    ensure_finished_results_backfilled();
    return rows("SELECT g.id game_id,g.name game_name,g.ended_at,s.area,s.name scenario_name,
        t.name team_name,t.final_score,t.final_rank,t.is_winner,t.slot_no
      FROM games g JOIN scenarios s ON s.id=g.scenario_id JOIN teams t ON t.game_id=g.id
      WHERE g.status='finished' AND t.final_score IS NOT NULL
      ORDER BY g.ended_at DESC,g.id DESC,t.final_rank,t.slot_no");
}

/** Rangos ARQWAR por XP total; los puntos históricos de participant_points no se reinician. */
function participant_rank_catalog(): array {
    return [
        ['min'=>0,    'name'=>'Bronce',      'key'=>'bronce',      'icon'=>'🥉'],
        ['min'=>300,  'name'=>'Plata',       'key'=>'plata',       'icon'=>'🥈'],
        ['min'=>900,  'name'=>'Platino',     'key'=>'platino',     'icon'=>'🔷'],
        ['min'=>2000, 'name'=>'Diamante',    'key'=>'diamante',    'icon'=>'💎'],
        ['min'=>4000, 'name'=>'Heroico',     'key'=>'heroico',     'icon'=>'⚡'],
        ['min'=>7000, 'name'=>'Gran Maestro','key'=>'gran-maestro','icon'=>'🏆'],
    ];
}

function participant_level(int $points): array {
    $points=max(0,$points);
    $ranks=participant_rank_catalog();
    $index=0;
    foreach($ranks as $i=>$rank) {
        if($points >= $rank['min']) $index=$i;
        else break;
    }
    $current=$ranks[$index];
    $next=$ranks[$index+1]??null;
    $start=(int)$current['min'];
    $target=$next ? (int)$next['min'] : null;
    $span=$target!==null ? max(1,$target-$start) : 1;
    $pct=$target!==null ? (int)round(100*min(1,($points-$start)/$span)) : 100;
    return [
        'name'=>$current['name'],'key'=>$current['key'],'icon'=>$current['icon'],
        'image'=>'assets/img/rangos/'.$current['key'].'.webp',
        'min'=>$start,'next'=>$target,'next_name'=>$next['name']??null,
        'points_to_next'=>$target!==null ? max(0,$target-$points) : 0,
        'progress_pct'=>$pct,
    ];
}

function participant_ranking_rows(): array {
    $items=rows("SELECT p.id,p.alias,p.full_name,p.specialty,p.avatar_emoji,
        COALESCE(SUM(pp.points),0) total_points,
        COUNT(DISTINCT CASE WHEN pp.game_id IS NOT NULL THEN pp.game_id END) games_played,
        SUM(CASE WHEN pp.source_type='card' THEN 1 ELSE 0 END) answers,
        SUM(CASE WHEN pp.source_type='pronunciation' AND pp.points>0 THEN 1 ELSE 0 END) pronunciation_hits
      FROM participants p LEFT JOIN participant_points pp ON pp.participant_id=p.id
      WHERE p.is_active=1
      GROUP BY p.id,p.alias,p.full_name,p.specialty,p.avatar_emoji
      ORDER BY total_points DESC, pronunciation_hits DESC, answers DESC, p.alias");
    foreach($items as &$r){ $r['level']=participant_level((int)$r['total_points']); } unset($r);
    return $items;
}

function game_final_summary(int $gameId): array {
    ensure_finished_results_backfilled();
    $game=get_game($gameId); if(!$game) return [];
    $standings=rows('SELECT id,name,final_score,final_rank,is_winner,slot_no FROM teams WHERE game_id=? ORDER BY final_rank,slot_no',[$gameId]);
    $winners=array_values(array_filter($standings,fn($t)=>(int)$t['is_winner']===1));
    return ['game'=>$game,'winners'=>$winners,'standings'=>$standings];
}

function architecture_layer(string $category): string {
    return match($category) {
        'Edge' => 'EDGE', 'Network' => 'NETWORK', 'Security' => 'SECURITY', 'Compute','Container','Orchestration','Serverless' => 'COMPUTE',
        'Database','Cache','Storage','Messaging','Vector DB','Search' => 'DATA', 'Analytics','BI','Data Integration','Data Quality' => 'DATA & ANALYTICS', 'CI/CD','IaC','Artifact','Source Control','Build','Package','Testing' => 'DEVOPS', 'Observability' => 'OBSERVABILITY', 'AI','MLOps' => 'AI / MLOPS', 'RPA','Integration' => 'AUTOMATION', 'FinOps' => 'FINOPS', 'Identity' => 'SECURITY', 'App Platform','Framework','Language' => 'APPLICATION', 'Virtualization','Operating System' => 'COMPUTE',
        default => 'OTHER'
    };
}
