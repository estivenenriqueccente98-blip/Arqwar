<?php
/** Identidad visual ARQWAR v1.6: un único logo reutilizable para los módulos. */
if (!function_exists('arqwar_brand_html')) {
    function arqwar_brand_html(string $label = '', string $variant = 'compact', string $href = 'index.php'): string {
        $variant = in_array($variant, ['compact', 'sidebar', 'arena'], true) ? $variant : 'compact';
        $text = htmlspecialchars($label, ENT_QUOTES, 'UTF-8');
        $href = htmlspecialchars($href, ENT_QUOTES, 'UTF-8');
        $anchorClass = $variant === 'compact' ? 'navbar-brand ' : '';
        $anchorClass .= 'arqwar-brand-lockup arqwar-brand-lockup--'.$variant;
        $sub = $variant === 'sidebar' ? '<small class="arqwar-brand-version">V 1.6</small>' : '<small class="arqwar-brand-context">'.($text !== '' ? $text.' · ' : '').'V 1.6</small>';
        return '<a class="'.$anchorClass.'" href="'.$href.'" aria-label="ARQWAR, navegación principal">'
            .'<img class="arqwar-brand-icon" src="assets/img/arqwar-brand.svg" alt="" width="86" height="65">'
            .'<span class="arqwar-brand-text">ARQWAR'.$sub.'</span></a>';
    }
}
if (!function_exists('arqwar_sidebar_html')) {
    function arqwar_sidebar_html(string $active = 'inicio', bool $expanded = false, int $gameId = 0, bool $roomActive = false): string {
        $profileNav = (function_exists('is_admin') && is_admin())
            ? ['participantes','Participantes','participants.php','users']
            : ['perfil','Mi perfil','mi-perfil.php','user'];
        $nav = $expanded ? [
           ['inicio','Inicio','index.php','home'],
           ['nueva','Nueva partida','game-master.php?new=1','gamepad'],
           ['salas','Salas ARQWAR','rooms.php','door'],
           ['arena','Arena TV','arena.php'.($gameId?'?game_id='.$gameId:''),'monitor'],
           $profileNav,
           ['equipos','Equipos','teams.php','shield'],
           ['individual','Ranking individual','participant-ranking.php','chart'],
           ['ranking','Ranking general','ranking.php','trophy'],
           ['ganadores','Ganadores','winners.php','medal'],
           ['gm','Game Master','game-master.php','settings'],
           ['cartas','Cartas','cards.php','cards'],
           ['cuenta','Mi cuenta','account.php','user'],
        ] : [
           ['inicio','Inicio','index.php','home'],
           ['arena','Arena TV','arena.php'.($gameId?'?game_id='.$gameId:''),'monitor'],
        ];
        if ($roomActive && $gameId > 0 && $expanded) {
            array_splice($nav, 3, 0, [['abrir-sala','Abrir sala','room.php?game_id='.$gameId,'door']]);
        }
        $paths = [
           'home'=>'<path d="m3 10 9-7 9 7v10h-6v-7H9v7H3z"/>',
           'gamepad'=>'<rect x="3" y="7" width="18" height="11" rx="4"/><path d="M8 10v5m-2.5-2.5h5M16 12h.01M18 14h.01"/>',
           'door'=>'<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M10 12h.01"/>',
           'monitor'=>'<rect x="2" y="4" width="20" height="15" rx="2"/><path d="M8 22h8M12 19v3m-2-14 5 3-5 3z"/>',
           'users'=>'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8ZM22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
           'shield'=>'<path d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11z"/>',
           'chart'=>'<path d="M3 20h18M6 16V9m6 7V4m6 12v-5"/>',
           'trophy'=>'<path d="M8 21h8m-4-5v5M7 3h10v6a5 5 0 0 1-10 0V3ZM7 5H4v3a4 4 0 0 0 4 4M17 5h3v3a4 4 0 0 1-4 4"/>',
           'medal'=>'<circle cx="12" cy="15" r="5"/><path d="m7 2 5 8 5-8M5 2l4 8M19 2l-4 8"/>',
           'settings'=>'<circle cx="12" cy="12" r="3"/><path d="M12 2v3m0 14v3M4.9 4.9 7 7m10 10 2.1 2.1M2 12h3m14 0h3M4.9 19.1 7 17M17 7l2.1-2.1"/>',
           'cards'=>'<rect x="4" y="3" width="14" height="17" rx="2"/><path d="M8 7h6M8 11h6M8 15h4M18 7h2v14a1 1 0 0 1-1 1H9"/>',
           'user'=>'<circle cx="12" cy="8" r="4"/><path d="M4 21v-2a8 8 0 0 1 16 0v2z"/>',
           'logout'=>'<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4m7 14 5-5-5-5m5 5H9"/>',
        ];
        $html = '<aside class="arqwar-global-sidebar '.($expanded?'is-expanded':'is-minimal').'" aria-label="Navegación ARQWAR">';
        $html .= arqwar_brand_html('', 'sidebar');
        $html .= '<nav class="arqwar-global-nav" aria-label="Menú principal">';
        foreach($nav as $item) {
            [$id,$label,$url,$icon] = $item;
            $label = htmlspecialchars($label, ENT_QUOTES, 'UTF-8');
            $url = htmlspecialchars($url, ENT_QUOTES, 'UTF-8');
            $attrs = $id === $active ? ' is-active" aria-current="page' : '';
            $html .= '<a class="arqwar-global-link'.$attrs.'" href="'.$url.'"'.($id==='arena'?' target="_blank" rel="noopener noreferrer"':'').'>';
            $html .= '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'.$paths[$icon].'</svg><span>'.$label.'</span></a>';
        }
        if(function_exists('current_user') && current_user()) {
            $html .= '<a class="arqwar-global-link is-logout" href="logout.php"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'.$paths['logout'].'</svg><span>Salir</span></a>';
        } else {
            $html .= '<a class="arqwar-global-link is-logout" href="login.php"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'.$paths['user'].'</svg><span>Ingresar</span></a>';
        }
        if ($expanded && function_exists('is_admin') && is_admin()) {
            $html .= '<a class="arqwar-global-link is-admin" href="admin.php"><span aria-hidden="true">⚙</span><span>Administrar CRUD</span></a>';
        }
        $html .= '</nav><div class="arqwar-sidebar-footer"><i></i> ARQWAR · V 1.6</div></aside>';
        return $html;
    }
}
