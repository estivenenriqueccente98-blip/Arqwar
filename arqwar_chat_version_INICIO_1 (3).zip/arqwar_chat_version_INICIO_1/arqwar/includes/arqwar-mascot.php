<?php
/**
 * Mascota ARQWAR: accesorio visual exclusivamente para Inicio y partidas activas.
 * No modifica autenticacion, registro, puntuacion ni chat original de las salas.
 */
if (!function_exists('arqwar_mascot_html')) {
    function arqwar_mascot_html(string $context = 'home'): string {
        $home = $context !== 'game';
        ob_start();
        ?>
        <div class="arq-bot" data-arq-bot data-context="<?= $home ? 'home' : 'game' ?>">
            <div class="arq-bot__speech" id="arqBotSpeech" role="status" aria-live="polite">
                ¡Hola! Un clic: reacción. Doble clic: chat.
            </div>
            <button type="button" class="arq-bot__mascot" id="arqBotMascot"
                    aria-label="Mascota ARQWAR. Haz clic para ver reacciones o doble clic para abrir <?= $home ? 'el asistente' : 'el chat de la partida' ?>"
                    aria-controls="<?= $home ? 'arqBotChatPanel' : 'gameChat' ?>" aria-expanded="false"
                    title="Un clic: reacción · Doble clic: <?= $home ? 'asistente' : 'chat de la partida' ?>">
                <span class="arq-bot__glow" aria-hidden="true"></span>
                <img class="arq-bot__image" id="arqBotImage" src="assets/img/mascota/idle.webp" width="384" height="424"
                     alt="" draggable="false" decoding="async">
                <span class="arq-bot__sparkle arq-bot__sparkle--one" aria-hidden="true">✧</span>
                <span class="arq-bot__sparkle arq-bot__sparkle--two" aria-hidden="true">✦</span>
                <span class="arq-bot__sparkle arq-bot__sparkle--three" aria-hidden="true">✳</span>
            </button>
            <button class="arq-bot__chat-trigger" type="button" id="arqBotOpenChat"
                    aria-controls="<?= $home ? 'arqBotChatPanel' : 'gameChat' ?>" aria-expanded="false">
                <span aria-hidden="true">◉</span> <?= $home ? 'Pregúntame' : 'Chat de partida' ?>
            </button>
        </div>
        <?php if ($home): ?>
        <section class="arq-bot__panel arq-bot__panel--home" id="arqBotChatPanel" role="dialog"
                 aria-labelledby="arqBotChatTitle" aria-modal="false" hidden>
            <header class="arq-bot__panel-header">
                <span class="arq-bot__panel-avatar" aria-hidden="true">✦</span>
                <span class="arq-bot__panel-heading">
                    <strong id="arqBotChatTitle">ARQ · Tu guía ARQWAR</strong>
                    <small><i aria-hidden="true"></i> Asistente del juego · disponible ahora</small>
                </span>
                <button type="button" class="arq-bot__close" id="arqBotCloseChat" aria-label="Cerrar asistente">×</button>
            </header>
            <div class="arq-bot__chat-log" id="arqBotChatLog" role="log" aria-live="polite" aria-relevant="additions"></div>
            <div class="arq-bot__quick-questions" aria-label="Preguntas frecuentes">
                <button type="button" data-arq-question="¿Cómo creo una partida?">Nueva partida</button>
                <button type="button" data-arq-question="¿Cómo funcionan los dados?">Dados</button>
                <button type="button" data-arq-question="¿Cómo utilizo mis cartas?">Cartas</button>
            </div>
            <form class="arq-bot__question-form" id="arqBotQuestionForm">
                <label class="visually-hidden" for="arqBotQuestion">Haz una pregunta sobre ARQWAR</label>
                <input type="text" id="arqBotQuestion" maxlength="300" autocomplete="off"
                       placeholder="Pregunta cómo jugar, puntajes, salas..." required>
                <button type="submit" aria-label="Enviar pregunta">➤</button>
            </form>
            <p class="arq-bot__disclaimer">Guía de ARQWAR con respuestas del juego; no utiliza un servicio externo de IA.</p>
        </section>
        <?php endif; ?>
        <?php
        return (string)ob_get_clean();
    }
}
