<?php
require_once __DIR__.'/../includes/bootstrap.php';
try {
    $gameId=(int)($_GET['game_id']??0);
    if(!$gameId){ $g=latest_game(); $gameId=(int)($g['id']??0); }
    if(!$gameId) json_out(['ok'=>false,'error'=>'No hay partidas'],404);
    json_out(['ok'=>true,'data'=>game_state($gameId)]);
} catch(Throwable $e){ json_out(['ok'=>false,'error'=>$e->getMessage()],500); }



