<?php
require_once __DIR__.'/../includes/bootstrap.php';
require_once __DIR__.'/../includes/avatars.php';
gm_required();

$gameId=(int)($_GET['game_id']??$_POST['game_id']??0);
$teamId=(int)($_GET['team_id']??$_POST['team_id']??0);
if(!$gameId || !get_game($gameId)) json_out(['ok'=>false,'error'=>'Partida invalida.'],404);

$participant=current_participant();
if(!$participant) json_out(['ok'=>false,'error'=>'No se pudo identificar tu cuenta.'],403);
$participantId=(int)$participant['id'];
$roomCtx=room_access_for_game($gameId);
if(!empty($_SESSION['room_context']) && (int)($_SESSION['room_context']['game_id']??0)===$gameId && !$roomCtx) json_out(['ok'=>false,'error'=>'Debes ingresar a la sala para usar el chat.'],403);
if($roomCtx && $roomCtx['role']==='player' && $teamId && room_player_team_id($gameId)!==$teamId) json_out(['ok'=>false,'error'=>'Solo puedes usar el chat de tu equipo.'],403);

if($teamId){
    $team=row('SELECT id FROM teams WHERE id=? AND game_id=?',[$teamId,$gameId]);
    if(!$team) json_out(['ok'=>false,'error'=>'Equipo invalido.'],404);
    $member=row('SELECT tm.id FROM teams t JOIN team_members tm ON tm.team_profile_id=t.profile_id WHERE t.id=? AND t.game_id=? AND tm.participant_id=?',[$teamId,$gameId,$participantId]);
    if(!$member && !is_admin()) json_out(['ok'=>false,'error'=>'Solo los integrantes de este equipo pueden acceder a su chat.'],403);
}

if($_SERVER['REQUEST_METHOD']==='POST'){
    verify_csrf();
    $message=trim($_POST['message']??'');
    if($message==='') throw new RuntimeException('Escribe un mensaje.');
    if(mb_strlen($message)>500) throw new RuntimeException('El mensaje no puede superar 500 caracteres.');
    exec_sql('INSERT INTO chat_messages(game_id,team_id,participant_id,message) VALUES(?,?,?,?)',[$gameId,$teamId?:null,$participantId,$message]);
    json_out(['ok'=>true,'name'=>($participant['full_name']?:$participant['alias'])]);
}

$scope=$teamId?'team':'general';
$messages=$teamId
 ? rows("SELECT cm.id,cm.message,cm.created_at,cm.participant_id,COALESCE(NULLIF(p.full_name,''),p.alias) alias,p.avatar_emoji,t.name team_name FROM chat_messages cm LEFT JOIN participants p ON p.id=cm.participant_id LEFT JOIN teams t ON t.id=cm.team_id WHERE cm.game_id=? AND cm.team_id=? ORDER BY cm.id DESC LIMIT 80",[$gameId,$teamId])
 : rows("SELECT cm.id,cm.message,cm.created_at,cm.participant_id,COALESCE(NULLIF(p.full_name,''),p.alias) alias,p.avatar_emoji,t.name team_name FROM chat_messages cm LEFT JOIN participants p ON p.id=cm.participant_id LEFT JOIN teams t ON t.id=cm.team_id WHERE cm.game_id=? AND cm.team_id IS NULL ORDER BY cm.id DESC LIMIT 80",[$gameId]);

foreach($messages as &$m){
    $m['mine']=((int)($m['participant_id']??0)===$participantId);
    $m['avatar_key']=arqwar_avatar_key((string)($m['avatar_emoji']??'cyber_skull'));
    $m['avatar_name']=arqwar_avatar_meta($m['avatar_key'])['name'];
    $m['avatar_svg']=arqwar_avatar_svg($m['avatar_key']);
    $m['avatar_html']=arqwar_avatar_image_html($m['avatar_key'], true);
}
unset($m);
$myAvatarKey=arqwar_avatar_key((string)($participant['avatar_emoji']??'cyber_skull'));
json_out(['ok'=>true,'scope'=>$scope,'messages'=>array_reverse($messages),'me'=>['participant_id'=>$participantId,'name'=>($participant['full_name']?:$participant['alias']),'avatar_key'=>$myAvatarKey,'avatar_name'=>arqwar_avatar_meta($myAvatarKey)['name'],'avatar_svg'=>arqwar_avatar_svg($myAvatarKey),'avatar_html'=>arqwar_avatar_image_html($myAvatarKey, true)]]);
