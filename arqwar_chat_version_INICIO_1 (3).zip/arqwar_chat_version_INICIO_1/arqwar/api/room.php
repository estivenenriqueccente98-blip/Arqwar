<?php
require_once __DIR__.'/../includes/bootstrap.php';
gm_required();
ensure_room_schema();

$action=(string)($_POST['action']??$_GET['action']??'');
try{
    if($action==='heartbeat'){
        $roomId=(int)($_POST['room_id']??0);
        $room=row('SELECT * FROM game_rooms WHERE id=? AND is_active=1',[$roomId]);
        if(!$room) json_out(['ok'=>false,'error'=>'Sala no encontrada.'],404);
        room_mark_player($roomId);
        json_out(['ok'=>true,'players'=>room_active_player_count($roomId)]);
    }

    verify_csrf();
    $u=current_user();

    if($action==='create'){
        $gameId=(int)($_POST['game_id']??0);
        $name=trim((string)($_POST['name']??''));
        $private=(int)($_POST['is_private']??0)===1;
        $password=(string)($_POST['password']??'');
        if(!$gameId || !get_game($gameId)) throw new RuntimeException('Selecciona una partida valida.');
        if(!$name || mb_strlen($name)>120) throw new RuntimeException('Ingresa un nombre de sala valido.');
        if(get_game($gameId)['status']==='finished') throw new RuntimeException('No puedes crear una sala para una partida finalizada.');
        if(row('SELECT id FROM game_rooms WHERE game_id=? AND is_active=1',[$gameId])) throw new RuntimeException('Esta partida ya tiene una sala.');
        if($private && strlen($password)<4) throw new RuntimeException('La contrasena de sala debe tener al menos 4 caracteres.');
        exec_sql('INSERT INTO game_rooms(game_id,name,password_hash,is_private,is_active,created_by) VALUES(?,?,?,?,1,?)',[$gameId,$name,$private?password_hash($password,PASSWORD_DEFAULT):null,$private?1:0,(int)$u['id']]);
        header('Location: ../rooms.php?saved=1'); exit;
    }

    if($action==='update'){
        $roomId=(int)($_POST['room_id']??0);
        $room=row('SELECT * FROM game_rooms WHERE id=? AND is_active=1',[$roomId]);
        if(!$room) throw new RuntimeException('Sala no encontrada.');
        if(!is_admin() && (int)$room['created_by']!==(int)$u['id']) throw new RuntimeException('Solo el creador de la sala o el administrador puede modificarla.');
        $name=trim((string)($_POST['name']??$room['name']));
        $private=(int)($_POST['is_private']??0)===1;
        $password=(string)($_POST['password']??'');
        if(!$name || mb_strlen($name)>120) throw new RuntimeException('Ingresa un nombre de sala valido.');
        if($private && $password!=='' && strlen($password)<4) throw new RuntimeException('La nueva contrasena debe tener al menos 4 caracteres.');
        if($private && $password!=='') exec_sql('UPDATE game_rooms SET name=?,is_private=1,password_hash=? WHERE id=?',[$name,password_hash($password,PASSWORD_DEFAULT),$roomId]);
        elseif($private) exec_sql('UPDATE game_rooms SET name=?,is_private=1 WHERE id=?',[$name,$roomId]);
        else exec_sql('UPDATE game_rooms SET name=?,is_private=0,password_hash=NULL WHERE id=?',[$name,$roomId]);
        header('Location: ../rooms.php?saved=1'); exit;
    }

    if($action==='delete'){
        if(!is_admin()) json_out(['ok'=>false,'error'=>'Solo el administrador puede eliminar salas.'],403);
        $roomId=(int)($_POST['room_id']??0);
        $room=row('SELECT * FROM game_rooms WHERE id=?',[$roomId]);
        if(!$room) throw new RuntimeException('Sala no encontrada.');
        exec_sql('DELETE FROM game_rooms WHERE id=?',[$roomId]);
        json_out(['ok'=>true]);
    }

    json_out(['ok'=>false,'error'=>'Accion no soportada.'],400);
}catch(Throwable $e){json_out(['ok'=>false,'error'=>$e->getMessage()],400);}
