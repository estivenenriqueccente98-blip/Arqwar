<?php
require_once __DIR__.'/../includes/bootstrap.php';
gm_required(); verify_csrf();
$action=$_POST['action']??'';
$postedGameId=(int)($_POST['game_id']??0);
try {
    if($postedGameId && $action!=='create_game' && $action!=='remove_card') room_restrict_action($postedGameId,$action,(int)($_POST['team_id']??0)?:null);
    switch($action){
        case 'create_game':
            $name=trim($_POST['name']??'Partida ARQWAR');
            $roomName=trim((string)($_POST['room_name']??('Sala de '.$name)));
            $roomPrivate=((int)($_POST['room_private']??1)===1);
            $roomPassword=(string)($_POST['room_password']??'');
            $mode=((string)($_POST['game_mode']??'teams')==='individual')?'individual':'teams';
            $scenario=(int)($_POST['scenario_id']??0); $rounds=max(3,min(12,(int)($_POST['max_rounds']??8)));
            $profileIds=array_values(array_unique(array_filter(array_map('intval',$_POST['team_profile_ids']??[]))));
            if(!$scenario) throw new RuntimeException('Selecciona una casuística.');
            if($mode==='teams' && count($profileIds)<2) throw new RuntimeException('Selecciona al menos 2 equipos para una batalla por equipos.');
            if($mode==='teams' && count($profileIds)>8) throw new RuntimeException('ARQWAR admite hasta 8 equipos por partida.');
            if($mode==='individual' && $profileIds) $profileIds=[];
            if(!$roomName || mb_strlen($roomName)>120) throw new RuntimeException('Ingresa un nombre de sala válido.');
            if($roomPrivate && strlen($roomPassword)<4) throw new RuntimeException('La contraseña de sala debe tener al menos 4 caracteres.');
            $profiles=[];
            foreach($profileIds as $pid){
                $profile=row('SELECT * FROM team_profiles WHERE id=? AND is_active=1',[$pid]);
                if(!$profile) throw new RuntimeException('Uno de los equipos seleccionados ya no está disponible.');
                $profiles[]=$profile;
            }
            ensure_room_schema();
            db()->beginTransaction();
            exec_sql('INSERT INTO games(name,scenario_id,max_rounds,lucky_number,mode) VALUES(?,?,?,6,?)',[$name,$scenario,$rounds,$mode]);
            $gid=(int)db()->lastInsertId();
            $themes=['blue','red','gold','green','purple','orange','cyan','pink'];
            $aliases=[];
            foreach($profiles as $idx=>$profile){
                $slot=$idx+1; $theme=$themes[$idx%count($themes)];
                exec_sql('INSERT INTO teams(game_id,profile_id,name,theme_key,slot_no) VALUES(?,?,?,?,?)',[$gid,(int)$profile['id'],$profile['alias'],$theme,$slot]);
                $aliases[]=$profile['alias'];
            }
            $uid=(int)(current_user()['id']??0);
            exec_sql('INSERT INTO game_rooms(game_id,name,password_hash,is_private,is_active,created_by) VALUES(?,?,?,?,1,?) ON DUPLICATE KEY UPDATE name=VALUES(name),password_hash=VALUES(password_hash),is_private=VALUES(is_private),is_active=1,created_by=VALUES(created_by)',[$gid,$roomName,$roomPrivate?password_hash($roomPassword,PASSWORD_DEFAULT):null,$roomPrivate?1:0,$uid?:null]);
            if($mode==='individual') {
                log_game($gid,'game_created','Partida individual creada. Los jugadores se incorporarán al entrar a la sala.',null,['mode'=>'individual']);
            } else {
                log_game($gid,'game_created','Partida creada con '.count($profiles).' equipos: '.implode(' · ',$aliases),null,['team_profile_ids'=>$profileIds,'mode'=>'teams']);
            }
            db()->commit();
            json_out(['ok'=>true,'game_id'=>$gid,'mode'=>$mode]);

        case 'start_game':
            $gid=(int)$_POST['game_id']; game_creator_required($gid);
            $g=get_game($gid); if(!$g) throw new RuntimeException('Partida inválida');
            if($g['status']!=='setup') throw new RuntimeException('La partida ya fue iniciada o finalizada.');
            $inc=random_incident_id($g['scenario_area']??null);
            exec_sql("UPDATE games SET status='running', current_round=1, started_at=NOW(), active_incident_id=?, active_incident_started_at=NOW() WHERE id=?",[$inc,$gid]);
            log_game($gid,'start','Partida iniciada'); json_out(['ok'=>true]);

        case 'play_card':
            $gid=(int)$_POST['game_id']; $tid=(int)$_POST['team_id']; $cid=(int)$_POST['card_id'];
            $participantId=(int)($_POST['participant_id']??0);
            $roomCtx=room_access_for_game($gid);
            if($roomCtx && $roomCtx['role']==='player'){
                $self=current_participant(false);
                if(!$self) throw new RuntimeException('No se pudo identificar tu participante.');
                $participantId=(int)$self['id'];
            }
            if(!array_key_exists('pronunciation_correct',$_POST)) throw new RuntimeException('Indica si el participante pronunció correctamente el servicio.');
            $pronunciationCorrect=((string)$_POST['pronunciation_correct']==='1') ? 1 : 0;
            $g=get_game($gid); if(!$g || $g['status']!=='running') throw new RuntimeException('La partida debe estar en curso.');
            $team=row('SELECT * FROM teams WHERE id=? AND game_id=?',[$tid,$gid]); if(!$team) throw new RuntimeException('Equipo inválido');
            $stateBefore=calculate_team_state($gid,$tid);
            if((int)$stateBefore['deployments_remaining']<=0) {
                $msg='Este equipo ya utilizó sus '.$stateBefore['deployment_limit'].' despliegues de la ronda.';
                if(!$stateBefore['dice_roll']) $msg.=' Todavía puede lanzar el dado para intentar ganar una carta extra.';
                throw new RuntimeException($msg);
            }
            $card=row('SELECT * FROM cards WHERE id=? AND is_active=1',[$cid]); if(!$card) throw new RuntimeException('Carta inválida');
            if(!$participantId) throw new RuntimeException('Selecciona qué participante respondió por esta carta.');
            if(($g['mode']??'teams')==='individual') {
                $member=row('SELECT p.id participant_id,p.alias participant_alias FROM participants p WHERE p.id=? AND p.id=? LIMIT 1',[$participantId,(int)$team['participant_id']]);
            } else {
                $member=row('SELECT tm.*,p.alias participant_alias FROM team_members tm JOIN participants p ON p.id=tm.participant_id WHERE tm.team_profile_id=? AND tm.participant_id=?',[(int)$team['profile_id'],$participantId]);
            }
            if(!$member) throw new RuntimeException('El participante seleccionado no pertenece a este competidor.');
            $pronBonus=$pronunciationCorrect?5:0;
            exec_sql("INSERT INTO team_game_cards(game_id,team_id,card_id,responder_participant_id,pronunciation_correct,pronunciation_bonus,status,source,played_round,decision_points) VALUES(?,?,?,?,?,?,'deployed','physical',?,0)",[$gid,$tid,$cid,$participantId,$pronunciationCorrect,$pronBonus,(int)$g['current_round']]);
            $placementId=(int)db()->lastInsertId();
            $stateRaw=calculate_team_state($gid,$tid);
            $feedback=evaluate_card_choice($stateBefore,$stateRaw,$card,$g,get_active_incident($gid));
            $decision=(int)($feedback['decision_adjustment']??0);
            if($decision!==0) exec_sql('UPDATE team_game_cards SET decision_points=? WHERE id=?',[$decision,$placementId]);
            $stateAfter=calculate_team_state($gid,$tid);
            $feedback['score_after']=(int)$stateAfter['score'];
            $feedback['score_delta']=(int)$stateAfter['score']-(int)$stateBefore['score'];
            $feedback['decision_adjustment']=$decision;
            $individualCardPoints=(int)$feedback['score_delta'];
            $individualTotal=$individualCardPoints+$pronBonus;
            exec_sql('UPDATE team_game_cards SET individual_points=? WHERE id=?',[$individualTotal,$placementId]);
            exec_sql('INSERT INTO participant_points(participant_id,game_id,team_id,placement_id,source_type,points,description) VALUES(?,?,?,?,?,?,?)',[$participantId,$gid,$tid,$placementId,'card',$individualCardPoints,'Respuesta con '.$card['name']]);
            if($pronBonus>0) exec_sql('INSERT INTO participant_points(participant_id,game_id,team_id,placement_id,source_type,points,description) VALUES(?,?,?,?,?,?,?)',[$participantId,$gid,$tid,$placementId,'pronunciation',$pronBonus,'Pronunciación correcta de '.$card['name']]);
            $feedback['participant']=['id'=>$participantId,'alias'=>$member['participant_alias'],'card_points'=>$individualCardPoints,'pronunciation_correct'=>(bool)$pronunciationCorrect,'pronunciation_bonus'=>$pronBonus,'total_points'=>$individualTotal];
            if($feedback['score_delta']<0 && !in_array('Esta elección reduce el puntaje acumulado del equipo.', $feedback['warnings'], true)) {
                $feedback['warnings'][]='Esta elección reduce el puntaje acumulado del equipo.';
            }
            log_game($gid,'card_played',$team['name'].' desplegó '.$card['name'].' · '.(($feedback['score_delta']>=0?'+':'').$feedback['score_delta']).' pts',$tid,['card_id'=>$cid,'placement_id'=>$placementId,'feedback'=>$feedback]);
            json_out(['ok'=>true,'feedback'=>$feedback,'team_name'=>$team['name'],'state'=>$stateAfter]);

        case 'roll_die':
            $gid=(int)$_POST['game_id']; $tid=(int)$_POST['team_id'];
            $lucky=(int)($_POST['lucky_number']??0);
            if($lucky<1 || $lucky>6) throw new RuntimeException('Elige tu número de suerte antes de lanzar.');
            $g=get_game($gid); if(!$g || $g['status']!=='running') throw new RuntimeException('La partida debe estar en curso.');
            $team=row('SELECT * FROM teams WHERE id=? AND game_id=?',[$tid,$gid]); if(!$team) throw new RuntimeException('Equipo inválido');
            $round=(int)$g['current_round'];
            if(row('SELECT id FROM dice_rolls WHERE game_id=? AND team_id=? AND round_no=?',[$gid,$tid,$round])) throw new RuntimeException('Este equipo ya lanzó el dado en esta ronda.');
            $result=random_int(1,6); $won=$result===$lucky;
            exec_sql('INSERT INTO dice_rolls(game_id,team_id,round_no,lucky_number,result,won_extra_card) VALUES(?,?,?,?,?,?)',[$gid,$tid,$round,$lucky,$result,$won?1:0]);
            $message=$team['name'].' lanzó '.$result.($won?' · ¡BONUS! Gana 1 despliegue extra.':' · sin bonus.');
            log_game($gid,'dice_roll',$message,$tid,['result'=>$result,'lucky_number'=>$lucky,'won_extra_card'=>$won,'round'=>$round]);
            json_out(['ok'=>true,'result'=>$result,'lucky_number'=>$lucky,'won_extra_card'=>$won,'team_name'=>$team['name'],'round'=>$round]);

        case 'remove_card':
            $gid=(int)$_POST['game_id']; $placement=(int)$_POST['placement_id'];
            $p=row("SELECT tgc.*,c.name,t.name team_name FROM team_game_cards tgc JOIN cards c ON c.id=tgc.card_id JOIN teams t ON t.id=tgc.team_id WHERE tgc.id=? AND tgc.game_id=?",[$placement,$gid]);
            if(!$p) throw new RuntimeException('Carta no encontrada');
            room_restrict_action($gid,$action,(int)$p['team_id']);
            exec_sql("UPDATE team_game_cards SET status='discarded' WHERE id=?",[$placement]);
            exec_sql('DELETE FROM participant_points WHERE placement_id=?',[$placement]);
            log_game($gid,'card_removed',$p['team_name'].' retiró '.$p['name'],(int)$p['team_id']);
            json_out(['ok'=>true]);

        case 'trigger_incident':
            $gid=(int)$_POST['game_id']; $g=get_game($gid); if(!$g || $g['status']!=='running') throw new RuntimeException('La partida debe estar en curso.');
            $iid=(int)$_POST['incident_id']; $inc=row('SELECT name FROM incidents WHERE id=?',[$iid]); if(!$inc) throw new RuntimeException('Incidente inválido');
            exec_sql('UPDATE games SET active_incident_id=?, active_incident_started_at=NOW() WHERE id=?',[$iid,$gid]);
            log_game($gid,'incident',$inc['name']); json_out(['ok'=>true]);

        case 'next_round':
            $gid=(int)$_POST['game_id']; $g=get_game($gid); if(!$g || $g['status']!=='running') throw new RuntimeException('La partida debe estar en curso.');
            $results=resolve_active_incident($gid); $next=(int)$g['current_round']+1;
            if($next>(int)$g['max_rounds']){
                game_creator_required($gid);
                exec_sql("UPDATE games SET status='finished', ended_at=NOW(), active_incident_id=NULL, active_incident_started_at=NULL WHERE id=?",[$gid]);
                finalize_game_results($gid);
                log_game($gid,'finish','Partida finalizada automáticamente · ranking consolidado');
            }else{
                $inc=random_incident_id($g['scenario_area']??null);
                exec_sql('UPDATE games SET current_round=?, active_incident_id=?, active_incident_started_at=NOW() WHERE id=?',[$next,$inc,$gid]);
                log_game($gid,'round','Ronda '.$next.' iniciada · dado habilitado nuevamente');
            }
            json_out(['ok'=>true,'incident_results'=>$results,'finished'=>$next>(int)$g['max_rounds'],'final_summary'=>$next>(int)$g['max_rounds']?game_final_summary($gid):null]);

        case 'finish_game':
            $gid=(int)$_POST['game_id']; resolve_active_incident($gid);
            exec_sql("UPDATE games SET status='finished', ended_at=NOW(), active_incident_id=NULL, active_incident_started_at=NULL WHERE id=?",[$gid]);
            finalize_game_results($gid);
            log_game($gid,'finish','Partida finalizada por Game Master · ranking consolidado'); json_out(['ok'=>true,'finished'=>true,'final_summary'=>game_final_summary($gid)]);

        case 'reset_team':
            $gid=(int)$_POST['game_id']; $tid=(int)$_POST['team_id'];
            exec_sql('DELETE FROM participant_points WHERE game_id=? AND team_id=?',[$gid,$tid]);
            exec_sql('DELETE FROM team_game_cards WHERE game_id=? AND team_id=?',[$gid,$tid]);
            exec_sql('DELETE FROM dice_rolls WHERE game_id=? AND team_id=?',[$gid,$tid]);
            exec_sql('UPDATE teams SET reputation=100,sla=100.0000 WHERE id=?',[$tid]);
            log_game($gid,'reset','Equipo reiniciado',$tid); json_out(['ok'=>true]);

        default: throw new RuntimeException('Acción no soportada');
    }
}catch(Throwable $e){ if(db()->inTransaction()) db()->rollBack(); json_out(['ok'=>false,'error'=>$e->getMessage()],400); }
