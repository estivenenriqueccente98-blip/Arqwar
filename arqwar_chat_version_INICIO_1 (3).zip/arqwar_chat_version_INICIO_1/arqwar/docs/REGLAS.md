# Reglas de ARQWAR v1.5

## Objetivo

ARQWAR es un juego híbrido físico + digital. Cada equipo resuelve una casuística tecnológica utilizando cartas físicas de servicios y herramientas. No gana quien coloque más tecnología: gana quien responda mejor al problema, mantenga el presupuesto y sobreviva a los incidentes.

## Preparación

1. Registra primero a los participantes globales con un alias competitivo.
2. Crea equipos y asigna participantes ya registrados.
3. Crea una partida seleccionando área tecnológica, casuística y entre 2 y 8 equipos.
4. Define entre 3 y 12 rondas.
5. El número de suerte **no** se fija al crear la partida: cada equipo lo elige justo antes de cada lanzamiento del dado.

## Participantes y competencia individual

Toda carta jugada debe ser respondida por un participante del equipo. El sistema registra para ese participante el impacto de la decisión y construye un historial individual.

Antes de desplegar una carta se puede escuchar el nombre del servicio con el botón de pronunciación. Después el Game Master responde si la pronunciación fue correcta. Una pronunciación correcta entrega **+5 XP individual**; este bonus no modifica el Architecture Score del equipo.

El ranking individual usa una progresión ARQWAR inspirada en juegos competitivos clásicos, desde **Pollo** hasta **Dragón de Oro**.

## Turno y dado

Cada equipo dispone normalmente de 2 despliegues por ronda. Una carta física colocada en mesa se registra desde Game Master.

Cada equipo puede lanzar el dado una sola vez por ronda. Antes de lanzar escoge un número de suerte entre 1 y 6. Si el dado coincide con ese número, el equipo gana 1 despliegue adicional durante esa ronda. En la siguiente ronda puede escoger otro número.

## Orden visual

Los paneles de los equipos permanecen siempre en la misma posición de la pantalla. Solo cambia la insignia de puesto (#1, #2, #3, etc.). Esto evita que los jugadores pierdan de vista su panel cuando cambia el ranking.

## Feedback de carta

Después de cada carta, el motor evalúa:

- afinidad con el área tecnológica;
- relación con la casuística concreta;
- brechas todavía no cubiertas;
- relación con el incidente activo;
- activación de combos;
- cumplimiento de mínimos;
- costo, FinOps y complejidad;
- sobreingeniería o elección demasiado básica.

Una carta puede sumar puntos, quedar en 0 o quitar puntos. El popup explica la razón y separa la ganancia técnica del ajuste por calidad de decisión.

## Incidentes

Cada incidente incluye explicación técnica, impacto, pista de respuesta y ejemplo no técnico. Al avanzar de ronda se resuelve para todos los equipos según el estado real de sus métricas. El éxito puede mejorar reputación; el fracaso reduce reputación y SLA.

## Fin de partida

Al finalizar se congelan puntaje y puesto. ARQWAR muestra un popup de celebración con el campeón o campeones y la tabla final. Al aceptar, vuelve al inicio.

Los resultados alimentan:

- Ranking General de equipos, filtrable por tipo de batalla/área.
- Ganadores por partida, con tabla completa de posiciones.
- Ranking de participantes y niveles competitivos.

## Roles de operación

- **General / operador:** puede registrar participantes, crear equipos, preparar y dirigir partidas y consultar rankings.
- **Administrador:** además puede editar, desactivar y eliminar registros maestros desde la consola CRUD.
- Las acciones administrativas no forman parte de la mecánica de puntuación; son funciones de mantenimiento del sistema.
