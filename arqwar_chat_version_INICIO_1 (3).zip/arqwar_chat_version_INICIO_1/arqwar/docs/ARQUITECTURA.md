# Arquitectura técnica — ARQWAR v1.5

## Stack

- PHP 8+
- PDO para runtime
- mysqli para setup/upgrade
- MySQL/MariaDB
- HTML5 + Bootstrap local + CSS3
- JavaScript vanilla
- Web Speech API del navegador para pronunciación de nombres de servicios

## Componentes

- `index.php`: dashboard principal autenticado.
- `login.php`: autenticación.
- `participants.php`: registro persistente de jugadores.
- `participant-ranking.php`: ranking individual y niveles.
- `teams.php`: equipos persistentes y asignación de participantes.
- `game-master.php`: creación y operación de partidas.
- `arena.php`: proyección para TV.
- `ranking.php`: ranking acumulado de equipos con filtro por área.
- `winners.php`: campeones y tabla completa de cada partida.
- `cards.php`: catálogo masivo de herramientas y servicios.
- `api/action.php`: comandos de juego.
- `api/state.php`: estado serializado para Game Master y Arena.
- `includes/functions.php`: scoring, combos, feedback, incidentes y rankings.
- `sql/arqwar.sql`: instalación limpia.
- `sql/seed_v1_4.sql`: ampliación del catálogo para upgrade.

## Modelo relevante

`participants` representa jugadores persistentes. `team_members.participant_id` asigna participantes a perfiles de equipos.

`participant_points` registra XP individual por respuesta y pronunciación. `team_game_cards` conserva quién respondió, si pronunció correctamente y los puntos individuales de la jugada.

`scenarios.area` y `scenarios.focus_json` permiten filtrar casuísticas por área y alimentan el scoring contextual.

`teams.slot_no` mantiene posiciones visuales estables. `final_score`, `final_rank` e `is_winner` congelan resultados históricos.

`dice_rolls.lucky_number` guarda el número elegido por el equipo en ese lanzamiento. No existe un número de suerte fijo por partida en la experiencia v1.5.

Los incidentes incluyen `technical_detail`, `nontechnical_example`, `business_impact` y `response_hint`.

`cards.lifecycle_note` permite marcar servicios legacy/en retiro sin eliminarlos del catálogo.

## Catálogo

La instalación limpia incluye 647 códigos de cartas entre cloud y tecnologías agnósticas: cloud, bases de datos, data, BI, DevOps, CI/CD, IaC, observabilidad, ciberseguridad, redes, virtualización, sistemas operativos, lenguajes, frameworks, testing, source control, RPA, IA/MLOps, FinOps e integración.

Los costos son valores simulados de juego y no tarifas comerciales.

## Pronunciación

El botón de audio usa `speechSynthesis` si el navegador lo soporta. La evaluación de pronunciación la confirma manualmente el Game Master para evitar que el juego dependa de reconocimiento automático de voz.

## Estado y cierre

`game_state()` devuelve equipos por `slot_no`, mientras calcula `current_rank` por separado para que el puesto cambie sin mover los paneles.

`finalize_game_results()` persiste resultados históricos. `game_final_summary()` alimenta el popup de celebración. `leaderboard_rows()` admite filtro por área; `participant_ranking_rows()` calcula XP y nivel individual.

## Roles y administración v1.5

`app_users.role` separa dos perfiles: `operator` y `admin`. Las páginas operativas usan `login_required_html()`, mientras que `admin.php` usa `admin_required_html()`. El Game Master permanece accesible para ambos perfiles. La consola administrativa concentra el mantenimiento CRUD y evita que un operador general pueda borrar datos maestros.
