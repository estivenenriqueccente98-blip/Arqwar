-- ARQWAR: migracion del modo de batalla individual
-- El sistema tambien ejecuta esta estructura automaticamente desde includes/functions.php.

ALTER TABLE games ADD COLUMN mode ENUM('teams','individual') NOT NULL DEFAULT 'teams';
ALTER TABLE teams ADD COLUMN owner_user_id INT NULL;
ALTER TABLE teams ADD COLUMN participant_id INT NULL;
ALTER TABLE teams ADD UNIQUE KEY uq_game_owner_user (game_id,owner_user_id);
ALTER TABLE teams ADD KEY idx_game_participant (game_id,participant_id);
