-- ARQWAR: recuperacion de contraseña por correo
-- Para instalaciones existentes puede ejecutarse una sola vez.
ALTER TABLE app_users ADD COLUMN email VARCHAR(190) NULL AFTER display_name;
ALTER TABLE app_users ADD COLUMN password_reset_code_hash VARCHAR(64) NULL AFTER email;
ALTER TABLE app_users ADD COLUMN password_reset_expires_at DATETIME NULL AFTER password_reset_code_hash;
