-- ARQWAR: vinculacion 1 cuenta = 1 participante
-- Para instalaciones existentes se recomienda ejecutar upgrade.php.
-- Alternativa manual desde phpMyAdmin (una sola vez):
ALTER TABLE participants ADD COLUMN user_id INT NULL AFTER id;
UPDATE participants p JOIN app_users u ON u.username=p.alias SET p.user_id=u.id WHERE p.user_id IS NULL;
ALTER TABLE participants ADD UNIQUE KEY uq_participant_user (user_id);
ALTER TABLE participants ADD CONSTRAINT fk_participant_user FOREIGN KEY (user_id) REFERENCES app_users(id) ON DELETE SET NULL;
