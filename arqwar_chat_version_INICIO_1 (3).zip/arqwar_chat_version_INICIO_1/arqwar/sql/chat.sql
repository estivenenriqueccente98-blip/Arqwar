CREATE TABLE IF NOT EXISTS chat_messages (
 id BIGINT AUTO_INCREMENT PRIMARY KEY,
 game_id INT NOT NULL,
 team_id INT NULL,
 participant_id INT NULL,
 message VARCHAR(500) NOT NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_chat_game_scope (game_id,team_id,id),
 FOREIGN KEY (game_id) REFERENCES games(id) ON DELETE CASCADE,
 FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE CASCADE,
 FOREIGN KEY (participant_id) REFERENCES participants(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
